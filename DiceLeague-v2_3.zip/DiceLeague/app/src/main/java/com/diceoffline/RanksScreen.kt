package com.diceoffline

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.diceoffline.R
import com.diceoffline.game.*

private val CardBg = Color(0xFF120E18)

/** کارت یک رنک، به سبک پوستر رده‌بندی. */
@Composable
private fun RankCard(r: Rank, mine: Boolean, modifier: Modifier) {
    val c = Color(r.color)
    Surface(
        modifier, shape = RoundedCornerShape(18.dp), color = CardBg,
        border = BorderStroke(if (mine) 3.dp else 1.5.dp, c),
    ) {
        Column(
            Modifier.background(Brush.verticalGradient(listOf(c.copy(alpha = 0.22f), Color.Transparent))).padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            RankEmblem(r, 96.dp)
            Txt(r.name.uppercase().let { if (r.key == "ostad") "OsTaD" else it }, size = 16, bold = true, color = c, maxLines = 1)
            Txt(r.fa, size = 15, bold = true, color = c, maxLines = 1)
            if (r.key == "conqueror") {
                Txt(tr("رنک ویژه", "Special rank"), size = 11, color = Color.White.copy(alpha = 0.85f), align = TextAlign.Center)
                Txt(tr("ظرفیت $CONQUEROR_SLOTS نفر", "$CONQUEROR_SLOTS players max"), size = 11, color = Color.White.copy(alpha = 0.85f), align = TextAlign.Center)
            } else {
                val range = if (r.max == Int.MAX_VALUE) "${r.min}+" else "${r.min} - ${r.max}"
                Txt(range, size = 13, bold = true, color = Color.White, maxLines = 1)
            }
            if (mine) Txt(tr("◀ رنک تو", "◀ Your rank"), size = 11, bold = true, color = c)
        }
    }
}

@Composable
fun RanksScreen(game: Game, onBack: () -> Unit) {
    val p = game.p
    val me = remember(p) { p.rankOf(ME) }
    val nr = nextRank(p.points)

    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("🏅 راهنمای رنک‌ها", "🏅 Rank guide"), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GradientHeader {
                RankEmblem(me, 120.dp)
                Txt(tr(me.fa, me.name), size = 24, bold = true, color = Color(me.color))
                Txt(tr("${fmt(p.points)} امتیاز", "${fmt(p.points)} points"), size = 14)
                if (nr != null) {
                    val cur = rankFor(p.points)
                    val span = (nr.first.min - cur.min).coerceAtLeast(1)
                    LinearProgressIndicator(
                        progress = { ((p.points - cur.min).toFloat() / span).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                    )
                    Txt(
                        tr("${fmt(nr.second)} امتیاز تا ${nr.first.fa}", "${fmt(nr.second)} points to ${nr.first.name}"),
                        size = 12, color = MaterialTheme.colorScheme.muted,
                    )
                } else Txt(tr("به بالاترین رنک عمومی رسیده‌ای 🔥", "You reached the top regular rank 🔥"), size = 12, color = MaterialTheme.colorScheme.muted)
            }

            AppCard {
                CardTitle(tr("📖 رنک‌ها چطور کار می‌کنند؟", "📖 How do ranks work?"))
                Txt(
                    tr(
                        "• رنک تو فقط به امتیازت (⭐ کاپ) بستگی دارد. هر برد امتیاز می‌دهد و هر باخت کم می‌کند.\n" +
                            "• دوئل: برد +$POINTS_DUEL_WIN  /  باخت $POINTS_DUEL_LOSS\n" +
                            "• لابی: برد +۲۰ (MVP برنده +۴۰)  /  باخت −۱۵  /  مساوی: فقط MVPها +۱۰\n" +
                            "• نبرد اتحاد: برد +۲۰  /  باخت −۱۵\n" +
                            "• ۹ رنک عمومی از برنز تا افسانه وجود دارد. «فاتح» رنک ویژه است: فقط $CONQUEROR_SLOTS نفر برتر لیگ که حداقل $CONQUEROR_MIN_POINTS امتیاز دارند.\n" +
                            "• پایان هر فصل: امتیاز $SEASON_RESET_CAP و بالاتر روی $SEASON_RESET_CAP می‌ماند؛ بین $SEASON_RESET_FLOOR و $SEASON_RESET_CAP، $SEASON_RESET_DROP امتیاز کم می‌شود (حداقل $SEASON_RESET_FLOOR)؛ زیر $SEASON_RESET_FLOOR تغییری نمی‌کند.\n" +
                            "• اگر بیشتر از $SEASON_OFFLINE_DAYS روز بازی نکنی و امتیازت $SEASON_RESET_CAP یا بیشتر باشد، $SEASON_OFFLINE_PENALTY امتیاز اضافه کم می‌شود.\n" +
                            "• NPCها هم مثل تو لول و رنک می‌گیرند و بالا می‌روند؛ روی اسم هر بازیکن بزن تا پروفایلش را ببینی.",
                        "• Your rank depends only on your points (⭐). Wins add points, losses subtract them.\n" +
                            "• Duel: win +$POINTS_DUEL_WIN  /  loss $POINTS_DUEL_LOSS\n" +
                            "• Lobby: win +20 (winning MVP +40)  /  loss −15  /  tie: only the MVPs get +10\n" +
                            "• Alliance war: win +20  /  loss −15\n" +
                            "• There are 9 regular ranks from Bronze to Legend. “Conqueror” is special: only the top $CONQUEROR_SLOTS league players with at least $CONQUEROR_MIN_POINTS points.\n" +
                            "• At season end: $SEASON_RESET_CAP+ points are set to $SEASON_RESET_CAP; between $SEASON_RESET_FLOOR and $SEASON_RESET_CAP you lose $SEASON_RESET_DROP (floor $SEASON_RESET_FLOOR); below $SEASON_RESET_FLOOR nothing changes.\n" +
                            "• If you stay away for more than $SEASON_OFFLINE_DAYS days with $SEASON_RESET_CAP+ points, an extra $SEASON_OFFLINE_PENALTY points are deducted.\n" +
                            "• NPCs level up and rank up just like you; tap any player's name to see their profile.",
                    ),
                    size = 13,
                )
            }

            val all = ALL_RANKS
            all.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { r -> RankCard(r, r.key == me.key, Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            AppCard {
                CardTitle(tr("📜 توضیح هر رنک", "📜 Rank descriptions"))
                ALL_RANKS.forEach { r ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RankEmblem(r, 44.dp)
                        Column(Modifier.weight(1f)) {
                            Txt("${tr(r.fa, r.name)}  ·  ${r.name}", bold = true, color = Color(r.color))
                            Txt(tr(r.descFa, r.descEn), size = 12, color = MaterialTheme.colorScheme.muted)
                        }
                    }
                }
            }

            Image(
                painterResource(R.drawable.poster), tr("پوستر رده‌بندی", "Ranking poster"),
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth,
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}
