package com.diceoffline.game

import kotlin.math.max

enum class Role { NONE, MEMBER, DEPUTY, OWNER }

fun Game.myRole(): Role {
    val a = p.myAlly() ?: return Role.NONE
    return when {
        a.owner == ME -> Role.OWNER
        ME in a.deputies -> Role.DEPUTY
        else -> Role.MEMBER
    }
}

fun Game.isManager(): Boolean = myRole() == Role.OWNER || myRole() == Role.DEPUTY

fun Game.allianceCreate(name0: String) {
    val name = name0.trim()
    val pl = p
    when {
        pl.myAlly() != null -> { toast("اول باید از اتحاد فعلیت خارج بشی.", "Leave your current alliance first."); return }
        name.length !in 3..20 -> { toast("اسم اتحاد باید ۳ تا ۲۰ حرف باشه.", "Alliance name must be 3–20 characters."); return }
        pl.alliances.any { it.name.equals(name, ignoreCase = true) } -> { toast("این اسم قبلاً گرفته شده.", "That name is taken."); return }
        pl.coins < ALLY_CREATE_COST -> { toast("ساخت اتحاد $ALLY_CREATE_COST سکه می‌خواد.", "Creating an alliance costs $ALLY_CREATE_COST coins."); return }
    }
    var np = createAlliance(pl.copy(coins = pl.coins - ALLY_CREATE_COST), ME, name)
    val newId = np.nextAllyId - 1
    np = np.withAlly(newId) { it.copy(minLevel = 0, minPoints = 0) }   // مالک خودش شرط می‌گذارد
    commit(np)
    toast("اتحاد «$name» ساخته شد 🛡", "Alliance “$name” created 🛡")
}

fun Game.allianceJoin(aid: Int) {
    val pl = p
    val a = pl.ally(aid) ?: return
    when {
        pl.myAlly() != null -> { toast("اول باید از اتحاد فعلیت خارج بشی.", "Leave your current alliance first."); return }
        a.members.size >= ALLY_MAX_MEMBERS -> { toast("ظرفیت اتحاد پره.", "The alliance is full."); return }
        pl.levelOf(ME) < a.minLevel -> { toast("حداقل لول ${a.minLevel} لازمه.", "Minimum level ${a.minLevel} required."); return }
        pl.points < a.minPoints -> { toast("حداقل ${a.minPoints} امتیاز لازمه.", "Minimum ${a.minPoints} points required."); return }
    }
    // اتحادهای NPC: درخواست فوری تأیید میشه؛ اتحاد من: همه با شرط‌ها وارد می‌شن (قفل فقط برای NPCهاست)
    commit(addMember(pl, aid, ME))
    toast("به «${a.name}» پیوستی ✅", "You joined “${a.name}” ✅")
}

fun Game.allianceLeave() {
    val a = p.myAlly() ?: return
    if (a.owner == ME && a.members.size > 1 && a.deputies.isEmpty()) {
        toast("قبل از خروج، مالکیت رو منتقل کن یا معاون بذار.", "Transfer ownership or appoint a deputy before leaving.")
        return
    }
    commit(removeMember(p, ME))
    toast("از اتحاد خارج شدی.", "You left the alliance.")
}

fun Game.allianceKick(mid: String) {
    val a = p.myAlly() ?: return
    if (!isManager() || mid == a.owner || mid == ME) return
    if (myRole() == Role.DEPUTY && mid in a.deputies) { toast("معاون نمی‌تونه معاون دیگه رو اخراج کنه.", "A deputy can't kick another deputy."); return }
    commit(removeMember(p, mid))
    toast("${p.nameOf(mid)} اخراج شد.", "${p.nameOf(mid)} was kicked.")
}

fun Game.allianceToggleDeputy(mid: String) {
    val a = p.myAlly() ?: return
    if (myRole() != Role.OWNER || mid == ME || mid !in a.members) return
    if (mid in a.deputies) {
        commit(p.withAlly(a.id) { it.copy(deputies = it.deputies - mid) })
    } else {
        if (a.deputies.size >= ALLY_MAX_DEPUTIES) { toast("حداکثر $ALLY_MAX_DEPUTIES معاون.", "Max $ALLY_MAX_DEPUTIES deputies."); return }
        commit(p.withAlly(a.id) { it.copy(deputies = it.deputies + mid) })
    }
}

fun Game.allianceTransfer(mid: String) {
    val a = p.myAlly() ?: return
    if (myRole() != Role.OWNER || mid == ME || mid !in a.members) return
    commit(p.withAlly(a.id) { it.copy(owner = mid, deputies = (it.deputies - mid)) })
    toast("مالکیت منتقل شد.", "Ownership transferred.")
}

fun Game.allianceToggleLock() {
    val a = p.myAlly() ?: return
    if (!isManager()) return
    commit(p.withAlly(a.id) { it.copy(locked = !it.locked) })
}

fun Game.allianceSetReq(minLevel: Int, minPoints: Int) {
    val a = p.myAlly() ?: return
    if (!isManager()) return
    commit(p.withAlly(a.id) { it.copy(minLevel = max(0, minLevel), minPoints = max(0, minPoints)) })
}

fun Game.allianceRename(name0: String) {
    val a = p.myAlly() ?: return
    val name = name0.trim()
    val days = (now() - a.lastRename) / 86_400_000L
    when {
        myRole() != Role.OWNER -> return
        name.length !in 3..20 -> { toast("اسم باید ۳ تا ۲۰ حرف باشه.", "Name must be 3–20 characters."); return }
        p.alliances.any { it.id != a.id && it.name.equals(name, ignoreCase = true) } -> { toast("این اسم قبلاً گرفته شده.", "That name is taken."); return }
        a.lastRename > 0 && days < ALLY_RENAME_COOLDOWN_DAYS -> {
            toast("هر $ALLY_RENAME_COOLDOWN_DAYS روز یک‌بار می‌شه عوضش کرد.", "You can rename once every $ALLY_RENAME_COOLDOWN_DAYS days.")
            return
        }
        p.coins < ALLY_RENAME_COST -> { toast("تغییر اسم $ALLY_RENAME_COST سکه می‌خواد.", "Renaming costs $ALLY_RENAME_COST coins."); return }
    }
    commit(p.copy(coins = p.coins - ALLY_RENAME_COST).withAlly(a.id) { it.copy(name = name, lastRename = now()) })
    toast("اسم اتحاد عوض شد ✅", "Alliance renamed ✅")
}

fun Game.allianceUpgradeCost(a: Alliance): Int? = ALLY_UPGRADE_COST[a.level + 1]

fun Game.allianceUpgrade() {
    val a = p.myAlly() ?: return
    if (!isManager()) return
    val cost = allianceUpgradeCost(a) ?: run { toast("اتحاد در بالاترین سطحه.", "Already at max level."); return }
    if (a.bank < cost) { toast("بانک اتحاد $cost سکه لازم داره.", "The alliance bank needs $cost coins."); return }
    val notes = mutableListOf<String>()
    var np = p.withAlly(a.id) { it.copy(level = it.level + 1, bank = it.bank - cost) }
    if (a.level + 1 >= ALLY_MAX_LEVEL && a.owner == ME) np = addBadge(np, "maxed_unity", notes)
    commit(np)
    toast("اتحاد به لول ${a.level + 1} رسید 🎉", "Alliance reached level ${a.level + 1} 🎉")
    say(notes)
}

fun Game.allianceDeposit(amount: Int) {
    val a = p.myAlly() ?: return
    if (amount <= 0 || amount > p.coins) { toast("سکه‌ی کافی نداری.", "Not enough coins."); return }
    commit(p.copy(coins = p.coins - amount).withAlly(a.id) { it.copy(bank = it.bank + amount) })
    toast("$amount سکه به بانک اتحاد رفت.", "$amount coins added to the alliance bank.")
}

fun Game.allianceWithdraw(amount: Int) {
    val a = p.myAlly() ?: return
    if (myRole() != Role.OWNER) { toast("فقط مالک می‌تونه برداره.", "Only the owner can withdraw."); return }
    if (amount <= 0 || amount > a.bank) { toast("موجودی بانک اتحاد کافی نیست.", "Not enough in the alliance bank."); return }
    commit(p.copy(coins = p.coins + amount).withAlly(a.id) { it.copy(bank = it.bank - amount) })
}

fun Game.allianceApprove(mid: String, ok: Boolean) {
    val a = p.myAlly() ?: return
    if (!isManager() || mid !in a.requests) return
    if (!ok) { commit(p.withAlly(a.id) { it.copy(requests = it.requests - mid) }); return }
    if (a.members.size >= ALLY_MAX_MEMBERS) { toast("ظرفیت اتحاد پره.", "The alliance is full."); return }
    commit(addMember(p, a.id, mid))
}
