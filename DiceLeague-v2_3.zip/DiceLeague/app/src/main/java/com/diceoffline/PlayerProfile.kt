package com.diceoffline

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceoffline.game.*

// ------------------------------------------------------------------ ابزارهای مشترک
/** باز کردن پروفایل یک بازیکن (mid خودم = "me"). در Root مقداردهی می‌شود. */
val LocalOpenProfile = compositionLocalOf<(String) -> Unit> { { _ -> } }

private fun rankRes(key: String): Int = when (key) {
    "silver" -> R.drawable.rank_silver
    "gold" -> R.drawable.rank_gold
    "platinum" -> R.drawable.rank_platinum
    "diamond" -> R.drawable.rank_diamond
    "master" -> R.drawable.rank_master
    "ostad" -> R.drawable.rank_ostad
    "champion" -> R.drawable.rank_champion
    "legend" -> R.drawable.rank_legend
    "conqueror" -> R.drawable.rank_conqueror
    else -> R.drawable.rank_bronze
}

/** نشان تصویریِ رنک (همان تصاویر پوستر رده‌بندی). */
@Composable
fun RankEmblem(r: Rank, size: Dp) {
    Image(painterResource(rankRes(r.key)), r.name, Modifier.size(size), contentScale = ContentScale.Fit)
}

fun parseLongNum(s: String): Long {
    val t = s.map { c ->
        when (c) {
            in '۰'..'۹' -> '0' + (c - '۰')
            in '٠'..'٩' -> '0' + (c - '٠')
            else -> c
        }
    }.filter { it.isDigit() }.joinToString("")
    return t.toLongOrNull() ?: 0L
}

fun ago(ms: Long): String {
    val s = maxOf(0L, ms) / 1000
    val m = s / 60
    val h = m / 60
    val d = h / 24
    return when {
        s < 45 -> tr("همین الان", "just now")
        m < 60 -> tr("$m دقیقه پیش", "${m}m ago")
        h < 24 -> tr("$h ساعت پیش", "${h}h ago")
        else -> tr("$d روز پیش", "${d}d ago")
    }
}

@Composable
fun LevelRing(lv: Int, cur: Int, need: Int, size: Dp = 96.dp) {
    val ring = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.outline
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = 9.dp.toPx()
            drawArc(track, 0f, 360f, false, Offset(sw / 2, sw / 2), Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw))
            val f = if (need > 0) cur.toFloat() / need else 1f
            drawArc(ring, -90f, 360f * f.coerceIn(0f, 1f), false, Offset(sw / 2, sw / 2), Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt("$lv", size = 28, bold = true)
            Txt("LEVEL", size = 10, color = MaterialTheme.colorScheme.muted)
        }
    }
}

/** کارت «آخرین بازی‌ها» برای یک بازیکن (من یا NPC) بر پایه‌ی گزارش‌ها. */
@Composable
fun RecentGamesCard(p: Player, mid: String) {
    val tickNow by tickState(30_000)
    val open = LocalOpenProfile.current
    val recent = remember(p.reports, mid) {
        p.reports.filter { mid in it.mids && it.kind in setOf("duel", "lobby", "battle") }.takeLast(10).reversed()
    }
    AppCard {
        CardTitle(tr("🎲 آخرین بازی‌ها", "🎲 Recent games"))
        if (recent.isEmpty()) Txt(tr("هنوز بازی ثبت نشده.", "No games recorded yet."), color = MaterialTheme.colorScheme.muted)
        recent.forEach { r ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                    r.mids.firstOrNull { it != mid && it != "" }?.let { open(it) }
                },
                verticalArrangement = Arrangement.spacedBy(1.dp),
            ) {
                Txt(r.line(), size = 13)
                Txt(ago(tickNow - r.time), size = 10, color = MaterialTheme.colorScheme.muted)
            }
        }
    }
}

// ------------------------------------------------------------------ پروفایل NPC
@Composable
fun PlayerProfileScreen(game: Game, mid: String, onBack: () -> Unit) {
    val p = game.p
    val npc = midToNpcId(mid)?.let { p.npc(it) }
    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("پروفایل بازیکن", "Player profile"), onBack)
        if (npc == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Txt(tr("این بازیکن دیگر وجود ندارد.", "This player no longer exists."), color = MaterialTheme.colorScheme.muted)
            }
        } else {
            val (lv, cur, need) = levelProgress(npc.xp)
            val rk = p.rankOf(mid)
            val total = npc.wins + npc.losses
            val ally = p.allyOf(mid)
            val badges = p.badgesOf(mid)
            val nr = if (rk.key == "conqueror") null else nextRank(npc.points)

            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                GradientHeader {
                    RankEmblem(rk, 120.dp)
                    Txt(tr(rk.fa, rk.name), size = 22, bold = true, color = Color(rk.color))
                    Spacer(Modifier.height(2.dp))
                    LevelRing(lv, cur, need, 92.dp)
                    Text(npc.name, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Pill("${rk.emoji} ${rk.name}  ·  ⭐ ${fmt(npc.points)}", color = MaterialTheme.colorScheme.secondaryContainer)
                    if (nr != null) Txt(
                        tr("${fmt(nr.second)} امتیاز تا ${nr.first.fa}", "${fmt(nr.second)} points to ${nr.first.name}"),
                        size = 11, color = MaterialTheme.colorScheme.muted,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatBox(fmt(npc.coins), "🪙 " + tr("سکه", "Coins"), Modifier.weight(1f))
                    StatBox(fmt(npc.points), "⭐ " + tr("امتیاز", "Points"), Modifier.weight(1f))
                    StatBox("${npc.honors}", "🏅 " + tr("افتخار", "Honors"), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatBox("${npc.wins}", tr("برد", "Wins"), Modifier.weight(1f))
                    StatBox("${npc.losses}", tr("باخت", "Losses"), Modifier.weight(1f))
                    StatBox(if (total == 0) "—" else "${npc.wins * 100 / total}%", tr("درصد برد", "Win rate"), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatBox("${npc.seasonWins}", tr("برد این فصل", "Season wins"), Modifier.weight(1f))
                    StatBox(fmt(npc.xp), "XP", Modifier.weight(1f))
                    StatBox("S${p.seasonNo}", tr("فصل", "Season"), Modifier.weight(1f))
                }

                if (ally != null) AppCard {
                    CardTitle(tr("🛡 اتحاد", "🛡 Alliance"))
                    Text(ally.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Txt(
                        "Lv ${ally.level}  ·  👥 ${ally.members.size}  ·  ⭐ ${fmt(p.allyPoints(ally))}" +
                            if (ally.owner == mid) "  ·  👑 " + tr("رهبر", "Leader") else "",
                        size = 12, color = MaterialTheme.colorScheme.muted,
                    )
                }

                AppCard {
                    CardTitle(tr("🎖 نشان‌ها", "🎖 Badges"))
                    val owned = BADGES.filter { it.key in badges }
                    if (owned.isEmpty()) Txt(tr("هنوز نشانی ندارد.", "No badges yet."), color = MaterialTheme.colorScheme.muted)
                    owned.forEach { (_, b) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(b.emoji, fontSize = 22.sp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(b.name, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Txt(tr(b.fa, b.en), size = 11, color = MaterialTheme.colorScheme.muted)
                            }
                        }
                    }
                }

                TrophyShelf(npc.trophies, mine = false)

                RecentGamesCard(p, mid)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
