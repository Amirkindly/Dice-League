package com.diceoffline.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** زبان برنامه؛ هر متن با tr(فارسی، انگلیسی) نوشته می‌شود. */
object L {
    var lang by mutableStateOf("fa")
}

fun tr(fa: String, en: String): String = if (L.lang == "fa") fa else en

const val ME = "me"
fun npcMid(id: Int) = "n$id"
fun midToNpcId(mid: String): Int? = if (mid.startsWith("n")) mid.substring(1).toIntOrNull() else null

data class Npc(
    val id: Int,
    val name: String,
    val points: Int,
    val xp: Int,
    val coins: Int,
    val honors: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val seasonWins: Int = 0,
    val banned: Boolean = false,       // از رتبه‌بندی و همه‌ی بازی‌ها حذف
    val restricted: Boolean = false,   // در لابی/نبرد/اتحاد شرکت نمی‌کند
    val badges: Set<String> = emptySet(),
    val trophies: List<String> = emptyList(),   // افتخارات فصلی: conq:S, king:S, prince:S, rank:S:pos
)

/** یک گزارش: بازی (duel/lobby/battle) یا رویداد (level/rank/season). */
data class Report(
    val id: Int = 0,
    val kind: String,
    val time: Long,
    val mine: Boolean,                       // شامل خود من است
    val names: List<String> = emptyList(),
    val mids: List<String> = emptyList(),    // اولی همان کسی است که با کلیک پروفایلش باز می‌شود
    val a: Int = 0,
    val b: Int = 0,
    val n: Int = 0,
    val res: Int = -1,                       // 1 برد من، 0 باخت من، 2 مساوی، -1 مربوط به من نیست
    val text: String = "",
)

data class Alliance(
    val id: Int,
    val name: String,
    val owner: String,
    val level: Int = 1,
    val bank: Long = 0,
    val won: Int = 0,
    val lost: Int = 0,
    val locked: Boolean = false,       // قفل: ورود فقط با تأیید مالک/معاون
    val minLevel: Int = 0,             // شرط ورود: حداقل لول (۰ = بدون شرط)
    val minPoints: Int = 0,            // شرط ورود: حداقل امتیاز (۰ = بدون شرط)
    val members: List<String> = emptyList(),
    val deputies: List<String> = emptyList(),
    val requests: List<String> = emptyList(),
    val lastRename: Long = 0,
)

data class Gift(
    val code: String,
    val coins: Int,
    val xp: Int,
    val points: Int,
    val maxUses: Int,
    val uses: Int = 0,
    val expires: Long = 0,             // 0 = بدون انقضا
)

data class Player(
    // --- پروفایل ---
    val name: String = "بازیکن",
    val coins: Int = COIN_START,
    val xp: Int = 0,
    val points: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val seasonWins: Int = 0,
    val honors: Int = 0,
    val honorLog: List<String> = emptyList(),
    val dailyStreak: Int = 0,
    val lastDailyDay: Long = -1,
    val lastOpenDay: Long = -1,
    val openStreak: Int = 0,
    val chatCoinLast: Long = 0,
    // --- بانک / کازینو ---
    val bankBalance: Long = 0,
    val bankLevel: Int = 0,
    val bankLast: Long = 0,
    val casinoLast: Long = 0,
    // --- نشان / ماموریت ---
    val badges: Set<String> = emptySet(),
    val starter: Set<String> = emptySet(),
    val missionDay: Long = -1,
    val missionProg: Map<String, Int> = emptyMap(),
    val missionDone: Set<String> = emptySet(),
    val bonusGiven: Boolean = false,
    // --- فصل ---
    val seasonNo: Int = 1,
    val seasonStart: Long = 0,
    val seasonDays: Int = SEASON_DAYS,
    // --- دنیای NPC ---
    val npcs: List<Npc> = emptyList(),
    val alliances: List<Alliance> = emptyList(),
    val nextNpcId: Int = 1,
    val nextAllyId: Int = 1,
    val lastSimMs: Long = 0,
    val gifts: List<Gift> = emptyList(),
    val redeemed: Set<String> = emptySet(),
    // --- تنظیمات برنامه ---
    val lang: String = "fa",
    val theme: Int = 0,                // 0 سیستم، 1 روشن، 2 تیره
    val keepScreen: Boolean = false,
    val admin: Boolean = false,
    // --- Fake Play ---
    val fpEnabled: Boolean = true,
    val npcCount: Int = FP_DEFAULT_COUNT,
    val duelEvery: Int = 10,
    val lobbyEvery: Int = 30,
    val lobbyTimer: Int = 5,
    val llOn: Boolean = true,
    val llEvery: Int = 5,
    val llTimer: Int = 10,
    val npcWinPct: Int = 50,           // شانس برد NPC مقابل بازیکن
    val allyAuto: Boolean = true,      // ساخت/عضویت/دونیت خودکار NPCها در اتحادها
    val customNames: List<String> = emptyList(),
    // --- گزارش‌ها (فقط داخل برنامه؛ تنظیمات را ادمین عوض می‌کند) ---
    val reports: List<Report> = emptyList(),
    val nextReportId: Int = 1,
    val repNpc: Boolean = true,              // نمایش تب «بازی‌های NPC»
    val repMine: Boolean = true,             // نمایش تب «بازی‌های من»
    val repEvents: Boolean = true,           // نمایش تب «رنک و لول»
    val repMax: Int = 200,                   // حداکثر گزارش ذخیره‌شده
    // --- پروفایل و افتخارات ---
    val avatar: String = "dice",             // کلید پروفایل انتخاب‌شده (یا conq:S)
    val avatarsOpen: Boolean = false,        // ادمین: همه‌ی پروفایل‌ها باز
    val trophies: List<String> = emptyList(),
)

// ----------------------------------------------------------------- JSON
private fun JSONObject.strList(k: String): List<String> =
    optJSONArray(k)?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()

private fun npcToJ(n: Npc) = JSONObject()
    .put("i", n.id).put("n", n.name).put("p", n.points).put("x", n.xp).put("c", n.coins)
    .put("h", n.honors).put("w", n.wins).put("l", n.losses).put("sw", n.seasonWins)
    .put("b", n.banned).put("r", n.restricted).put("bd", JSONArray(n.badges.toList()))
    .put("tr", JSONArray(n.trophies))

private fun npcFromJ(o: JSONObject) = Npc(
    o.getInt("i"), o.getString("n"), o.getInt("p"), o.getInt("x"), o.optInt("c"),
    o.optInt("h"), o.optInt("w"), o.optInt("l"), o.optInt("sw"), o.optBoolean("b"), o.optBoolean("r"),
    o.strList("bd").toSet(), o.strList("tr"),
)

private fun reportToJ(r: Report) = JSONObject()
    .put("i", r.id).put("k", r.kind).put("t", r.time).put("m", r.mine)
    .put("n", JSONArray(r.names)).put("d", JSONArray(r.mids))
    .put("a", r.a).put("b", r.b).put("z", r.n).put("r", r.res).put("x", r.text)

private fun reportFromJ(o: JSONObject) = Report(
    o.optInt("i"), o.optString("k"), o.optLong("t"), o.optBoolean("m"),
    o.strList("n"), o.strList("d"), o.optInt("a"), o.optInt("b"), o.optInt("z"), o.optInt("r", -1), o.optString("x"),
)

private fun allyToJ(a: Alliance) = JSONObject()
    .put("i", a.id).put("n", a.name).put("o", a.owner).put("lv", a.level).put("bk", a.bank)
    .put("w", a.won).put("l", a.lost).put("lk", a.locked).put("ml", a.minLevel).put("mp", a.minPoints)
    .put("m", JSONArray(a.members)).put("d", JSONArray(a.deputies)).put("q", JSONArray(a.requests))
    .put("rn", a.lastRename)

private fun allyFromJ(o: JSONObject) = Alliance(
    o.getInt("i"), o.getString("n"), o.getString("o"), o.optInt("lv", 1), o.optLong("bk"),
    o.optInt("w"), o.optInt("l"), o.optBoolean("lk"), o.optInt("ml"), o.optInt("mp"),
    o.strList("m"), o.strList("d"), o.strList("q"), o.optLong("rn"),
)

private fun giftToJ(g: Gift) = JSONObject()
    .put("c", g.code).put("co", g.coins).put("x", g.xp).put("p", g.points)
    .put("mu", g.maxUses).put("u", g.uses).put("e", g.expires)

private fun giftFromJ(o: JSONObject) = Gift(
    o.getString("c"), o.optInt("co"), o.optInt("x"), o.optInt("p"), o.optInt("mu", 1), o.optInt("u"), o.optLong("e"),
)

fun playerToJson(x: Player): JSONObject = JSONObject().apply {
    put("name", x.name); put("coins", x.coins); put("xp", x.xp); put("points", x.points)
    put("wins", x.wins); put("losses", x.losses); put("seasonWins", x.seasonWins)
    put("honors", x.honors); put("honorLog", JSONArray(x.honorLog))
    put("dailyStreak", x.dailyStreak); put("lastDailyDay", x.lastDailyDay)
    put("lastOpenDay", x.lastOpenDay); put("openStreak", x.openStreak); put("chatCoinLast", x.chatCoinLast)
    put("bankBalance", x.bankBalance); put("bankLevel", x.bankLevel); put("bankLast", x.bankLast)
    put("casinoLast", x.casinoLast)
    put("badges", JSONArray(x.badges.toList())); put("starter", JSONArray(x.starter.toList()))
    put("missionDay", x.missionDay); put("missionProg", JSONObject(x.missionProg))
    put("missionDone", JSONArray(x.missionDone.toList())); put("bonusGiven", x.bonusGiven)
    put("seasonNo", x.seasonNo); put("seasonStart", x.seasonStart); put("seasonDays", x.seasonDays)
    put("npcs", JSONArray().also { a -> x.npcs.forEach { a.put(npcToJ(it)) } })
    put("alliances", JSONArray().also { a -> x.alliances.forEach { a.put(allyToJ(it)) } })
    put("nextNpcId", x.nextNpcId); put("nextAllyId", x.nextAllyId); put("lastSimMs", x.lastSimMs)
    put("gifts", JSONArray().also { a -> x.gifts.forEach { a.put(giftToJ(it)) } })
    put("redeemed", JSONArray(x.redeemed.toList()))
    put("lang", x.lang); put("theme", x.theme); put("keepScreen", x.keepScreen); put("admin", x.admin)
    put("fpEnabled", x.fpEnabled); put("npcCount", x.npcCount); put("duelEvery", x.duelEvery)
    put("lobbyEvery", x.lobbyEvery); put("lobbyTimer", x.lobbyTimer); put("llOn", x.llOn)
    put("llEvery", x.llEvery); put("llTimer", x.llTimer); put("npcWinPct", x.npcWinPct)
    put("allyAuto", x.allyAuto); put("customNames", JSONArray(x.customNames))
    put("reports", JSONArray().also { a -> x.reports.forEach { a.put(reportToJ(it)) } })
    put("nextReportId", x.nextReportId)
    put("repNpc", x.repNpc); put("repMine", x.repMine); put("repEvents", x.repEvents); put("repMax", x.repMax)
    put("avatar", x.avatar); put("avatarsOpen", x.avatarsOpen); put("trophies", JSONArray(x.trophies))
}

fun playerFromJson(o: JSONObject): Player {
    val prog = mutableMapOf<String, Int>()
    o.optJSONObject("missionProg")?.let { mp -> mp.keys().forEach { k -> prog[k] = mp.optInt(k) } }
    val d = Player()
    fun <T> arr(k: String, f: (JSONObject) -> T): List<T> =
        o.optJSONArray(k)?.let { a -> (0 until a.length()).map { f(a.getJSONObject(it)) } } ?: emptyList()
    return Player(
        name = o.optString("name", d.name), coins = o.optInt("coins", COIN_START), xp = o.optInt("xp"),
        points = o.optInt("points"), wins = o.optInt("wins"), losses = o.optInt("losses"),
        seasonWins = o.optInt("seasonWins"), honors = o.optInt("honors"), honorLog = o.strList("honorLog"),
        dailyStreak = o.optInt("dailyStreak"), lastDailyDay = o.optLong("lastDailyDay", -1),
        lastOpenDay = o.optLong("lastOpenDay", -1), openStreak = o.optInt("openStreak"),
        chatCoinLast = o.optLong("chatCoinLast"),
        bankBalance = o.optLong("bankBalance"), bankLevel = o.optInt("bankLevel"), bankLast = o.optLong("bankLast"),
        casinoLast = o.optLong("casinoLast"),
        badges = o.strList("badges").toSet(), starter = o.strList("starter").toSet(),
        missionDay = o.optLong("missionDay", -1), missionProg = prog,
        missionDone = o.strList("missionDone").toSet(), bonusGiven = o.optBoolean("bonusGiven"),
        seasonNo = o.optInt("seasonNo", 1), seasonStart = o.optLong("seasonStart"),
        seasonDays = o.optInt("seasonDays", SEASON_DAYS),
        npcs = arr("npcs", ::npcFromJ), alliances = arr("alliances", ::allyFromJ),
        nextNpcId = o.optInt("nextNpcId", 1), nextAllyId = o.optInt("nextAllyId", 1),
        lastSimMs = o.optLong("lastSimMs"),
        gifts = arr("gifts", ::giftFromJ), redeemed = o.strList("redeemed").toSet(),
        lang = o.optString("lang", "fa"), theme = o.optInt("theme"), keepScreen = o.optBoolean("keepScreen"),
        admin = o.optBoolean("admin"),
        fpEnabled = o.optBoolean("fpEnabled", true), npcCount = o.optInt("npcCount", FP_DEFAULT_COUNT),
        duelEvery = o.optInt("duelEvery", 10), lobbyEvery = o.optInt("lobbyEvery", 30),
        lobbyTimer = o.optInt("lobbyTimer", 5), llOn = o.optBoolean("llOn", true),
        llEvery = o.optInt("llEvery", 5), llTimer = o.optInt("llTimer", 10),
        npcWinPct = o.optInt("npcWinPct", 50), allyAuto = o.optBoolean("allyAuto", true),
        customNames = o.strList("customNames"),
        reports = arr("reports", ::reportFromJ), nextReportId = o.optInt("nextReportId", 1),
        repNpc = o.optBoolean("repNpc", true), repMine = o.optBoolean("repMine", true),
        repEvents = o.optBoolean("repEvents", true), repMax = o.optInt("repMax", 200).coerceIn(20, 1000),
        avatar = o.optString("avatar", "dice"), avatarsOpen = o.optBoolean("avatarsOpen"),
        trophies = if (o.has("trophies")) o.strList("trophies") else trophiesFromHonorLog(o.strList("honorLog")),
    )
}

// ----------------------------------------------------------------- نتیجه‌ها (فقط برای UI)
data class DuelRoll(val opponent: Npc, val mine: Int, val theirs: Int) {
    val won: Boolean get() = mine > theirs
}

data class SlotResult(val value: Int, val bet: Int, val mult: Double) {
    val payout: Int get() = Math.round(bet * mult).toInt()
    val net: Int get() = payout - bet
}

data class Roller(val mid: String, val name: String, val dice: Int)

/** نتیجه‌ی تیمی (لابی یا نبرد اتحاد): تیم A و B */
data class TeamRoll(
    val title: String,
    val teamA: List<Roller>,
    val teamB: List<Roller>,
    val nameA: String,
    val nameB: String,
    val allyA: Int = 0,     // برای نبرد اتحاد؛ ۰ یعنی لابی
    val allyB: Int = 0,
) {
    val sumA: Int get() = teamA.sumOf { it.dice }
    val sumB: Int get() = teamB.sumOf { it.dice }
    val mvpA: Roller? get() = teamA.maxByOrNull { it.dice }
    val mvpB: Roller? get() = teamB.maxByOrNull { it.dice }
}

data class LobbyCard(val id: Int, val host: String, val size: Int, val filled: Int, val endsAt: Long)

data class BoardEntry(
    val rank: Int, val name: String, val level: Int, val points: Int, val honors: Int, val xp: Int, val me: Boolean,
    val mid: String = "", val rk: String = "bronze",
)
