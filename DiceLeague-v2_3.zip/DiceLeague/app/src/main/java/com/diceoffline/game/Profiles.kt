package com.diceoffline.game

// =================================================================== پروفایل‌ها (تصویر بازیکن)
/** یک پروفایل قابل انتخاب. level = لولی که پروفایل در آن باز می‌شود (۱ یعنی از اول باز است). */
data class AvatarDef(
    val key: String, val emoji: String, val fa: String, val en: String, val level: Int,
    val c1: Long, val c2: Long, val ring: Long,
)

/** ۱۰ پروفایل: ۳ تای اول رایگان‌اند، ۷ تای بعدی با بالا رفتن لول باز می‌شوند. */
val AVATARS = listOf(
    AvatarDef("dice", "🎲", "تاس‌باز", "Dice Roller", 1, 0xFF7A1F3D, 0xFF2B0A16, 0xFFFF7FA8),
    AvatarDef("clover", "🍀", "شانس", "Lucky Charm", 1, 0xFF1E7A4A, 0xFF07281A, 0xFF6BF0A6),
    AvatarDef("fox", "🦊", "روباه زیرک", "Sly Fox", 1, 0xFFB5521B, 0xFF3A1606, 0xFFFFB27A),
    AvatarDef("wolf", "🐺", "گرگ شب", "Night Wolf", 5, 0xFF2D4A8A, 0xFF0A1230, 0xFF8FB4FF),
    AvatarDef("eagle", "🦅", "شکارچی آسمان", "Sky Hunter", 10, 0xFF8A6A1E, 0xFF2E2106, 0xFFFFD86B),
    AvatarDef("lion", "🦁", "شیر میدان", "Arena Lion", 20, 0xFFC27A12, 0xFF4A2A02, 0xFFFFC04D),
    AvatarDef("ninja", "🥷", "سایه", "Shadow", 30, 0xFF5A2A8A, 0xFF150726, 0xFFC79BFF),
    AvatarDef("bolt", "⚡", "رعد", "Thunder", 45, 0xFF1F6FB5, 0xFF04152B, 0xFF5CE1FF),
    AvatarDef("dragon", "🐉", "اژدهای آتشین", "Dragon Lord", 60, 0xFFB5121F, 0xFF2E0408, 0xFFFF6B4D),
    AvatarDef("crown", "👑", "امپراتور", "Emperor", 80, 0xFFB58A12, 0xFF2B1C02, 0xFFFFE27A),
)

const val CONQ_ART_MAX = 20   // تعداد تصویرهای آماده‌ی فصلی (S1..S20)

fun avatarOf(key: String): AvatarDef = AVATARS.firstOrNull { it.key == key } ?: AVATARS[0]

fun isConqKey(key: String) = key.startsWith("conq:")
fun conqSeasonOf(key: String): Int = key.removePrefix("conq:").toIntOrNull() ?: 0

fun Player.avatarUnlocked(a: AvatarDef): Boolean = avatarsOpen || a.level <= 1 || levelFromXp(xp) >= a.level

/** پروفایل انتخاب‌شده معتبر است؟ (پروفایل Conquer فقط برای کسی که آن فصل را برده) */
fun Player.avatarValid(key: String): Boolean =
    if (isConqKey(key)) key in trophies else AVATARS.firstOrNull { it.key == key }?.let { avatarUnlocked(it) } == true

fun Game.setAvatar(key: String) {
    if (!p.avatarValid(key)) {
        val need = AVATARS.firstOrNull { it.key == key }?.level
        if (need != null) toast("این پروفایل از لول $need باز می‌شود.", "This profile unlocks at level $need.")
        return
    }
    commit(p.copy(avatar = key))
}

/** پروفایل‌هایی که با رسیدن از لول قبلی به لول جدید تازه باز می‌شوند. */
fun newAvatarsBetween(oldLv: Int, newLv: Int): List<AvatarDef> =
    AVATARS.filter { it.level in (oldLv + 1)..newLv }

// =================================================================== افتخارات فصلی (مثل ربات)
// کلیدها:  conq:S  = Conquer فصل S   |  king:S = King of level   |  prince:S = Prince of Dice
//          rank:S:P = رتبه‌ی P لیگ در پایان فصل S (P = 1..3)

fun List<String>.seasons(kind: String): List<Int> =
    filter { it.startsWith("$kind:") }.mapNotNull { it.split(":").getOrNull(1)?.toIntOrNull() }.distinct().sorted()

/** رتبه‌های پایان فصل: (فصل، جایگاه) */
fun List<String>.rankHonors(): List<Pair<Int, Int>> =
    filter { it.startsWith("rank:") }.mapNotNull {
        val x = it.split(":")
        val s = x.getOrNull(1)?.toIntOrNull(); val pos = x.getOrNull(2)?.toIntOrNull()
        if (s != null && pos != null) s to pos else null
    }.distinct().sortedWith(compareBy({ it.first }, { it.second }))

fun Player.trophiesOf(mid: String): List<String> =
    if (mid == ME) trophies else midToNpcId(mid)?.let { npc(it) }?.trophies ?: emptyList()

/** قالب نمایش دقیقاً مثل ربات. */
fun conquerLabel(seasons: List<Int>): String = when {
    seasons.isEmpty() -> ""
    seasons.size == 1 -> "🐉 Conquer (1) -S${seasons[0]}-"
    else -> "🐉 Conquer (${seasons.size}) " + seasons.joinToString("") { "(S$it)" }
}

fun kingLabel(seasons: List<Int>) = "👑 King of level " + seasons.joinToString("") { "(S$it)" }
fun princeLabel(seasons: List<Int>) = "🎲 Prince of Dice " + seasons.joinToString(" ") { "(S$it)" }

fun rankHonorLabel(season: Int, pos: Int): String {
    val medal = when (pos) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "🏅" }
    val word = when (pos) { 1 -> "1st"; 2 -> "2nd"; 3 -> "3rd"; else -> "${pos}th" }
    return "$medal Ranking $word (S$season)"
}

/** برای ذخیره‌های قدیمی که فقط honorLog داشتند: S3:league:1 / S3:level:1 / S3:prince */
fun trophiesFromHonorLog(log: List<String>): List<String> = log.mapNotNull { s ->
    val x = s.split(":")
    val season = x.getOrNull(0)?.removePrefix("S")?.toIntOrNull() ?: return@mapNotNull null
    when (x.getOrNull(1)) {
        "league" -> x.getOrNull(2)?.toIntOrNull()?.let { "rank:$season:$it" }
        "level" -> if (x.getOrNull(2) == "1") "king:$season" else null
        "prince" -> "prince:$season"
        else -> null
    }
}.distinct()

fun Game.adminToggleTrophy(t: String) {
    commit(p.copy(trophies = if (t in p.trophies) p.trophies - t else p.trophies + t))
}
