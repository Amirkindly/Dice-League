package com.diceoffline.game

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.security.MessageDigest
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class Game(ctx: Context) {
    internal val appCtx: Context = ctx.applicationContext
    internal val prefs = ctx.getSharedPreferences("game", Context.MODE_PRIVATE)

    var p by mutableStateOf(load())
        internal set
    var message by mutableStateOf<String?>(null)
    var lobbies by mutableStateOf<List<LobbyCard>>(emptyList())
        internal set
    internal var lobbySeq = 1

    init {
        L.lang = p.lang
        onOpen()
    }

    // ------------------------------------------------------------ زمان
    internal fun now() = System.currentTimeMillis()
    fun today(): Long = (now() + TimeZone.getDefault().getOffset(now())) / 86_400_000L

    // ------------------------------------------------------------ ذخیره
    private fun load(): Player {
        val raw = prefs.getString("player", null) ?: return Player()
        return try {
            playerFromJson(JSONObject(raw))
        } catch (e: Exception) {
            Player()
        }
    }

    /** هر کس همین الان Conquer باشد، نشان همین فصلش همان لحظه ثبت می‌شود (در هر فصل فقط یک‌بار). */
    private fun withConquerHonors(pl: Player): Player {
        val con = pl.conquerors()
        if (con.isEmpty()) return pl
        val key = "conq:${pl.seasonNo}"
        var out = pl
        if (ME in con && key !in pl.trophies) {
            out = out.copy(trophies = out.trophies + key)
            message = tr("🐉 Conquer شدی! نشان و پروفایل ویژه‌ی فصل S${pl.seasonNo} برایت باز شد.",
                "🐉 You are a Conqueror! The S${pl.seasonNo} badge and profile are unlocked.")
        }
        if (out.npcs.any { npcMid(it.id) in con && key !in it.trophies }) {
            out = out.copy(npcs = out.npcs.map { if (npcMid(it.id) in con && key !in it.trophies) it.copy(trophies = it.trophies + key) else it })
        }
        return out
    }

    internal fun commit(np0: Player) {
        val np = withConquerHonors(np0)
        p = np
        L.lang = np.lang
        prefs.edit().putString("player", playerToJson(np).toString()).apply()
    }

    fun toast(fa: String, en: String) {
        message = tr(fa, en)
    }

    // ------------------------------------------------------------ پاداش
    internal fun grant(pl: Player, coins: Int, xp: Int, pts: Int, notes: MutableList<String>): Player {
        val ev = ArrayList<Report>(2)
        val t = now()
        val oldLv = levelFromXp(pl.xp)
        val nxp = max(0, pl.xp + xp)
        val newLv = levelFromXp(nxp)
        if (newLv > oldLv) {
            notes.add(tr("⬆️ لول $newLv شدی!", "⬆️ Level $newLv reached!"))
            ev.add(mkLevel(t, ME, pl.name, newLv))
            newAvatarsBetween(oldLv, newLv).forEach {
                notes.add(tr("🖼 پروفایل جدید باز شد: ${it.emoji} ${it.fa}", "🖼 New profile unlocked: ${it.emoji} ${it.en}"))
            }
        }
        val oldRank = rankFor(pl.points)
        val npts = max(0, pl.points + pts)
        val newRank = rankFor(npts)
        if (newRank.min > oldRank.min) {
            notes.add(tr("${newRank.emoji} رنک جدید: ${newRank.fa}", "${newRank.emoji} New rank: ${newRank.name}"))
            ev.add(mkRank(t, ME, pl.name, newRank.key))
        }
        return emit(pl.copy(coins = max(0, pl.coins + coins), xp = nxp, points = npts), ev)
    }

    internal fun starterTrack(pl: Player, task: String, notes: MutableList<String>): Player {
        val t = STARTER_TASKS.firstOrNull { it.key == task } ?: return pl
        if (task in pl.starter) return pl
        var np = grant(pl.copy(starter = pl.starter + task), t.coins, 0, 0, notes)
        notes.add(tr("🎓 مسیر مبتدی: «${t.fa}» ✅  +${t.coins} 🪙", "🎓 Starter path: “${t.en}” ✅  +${t.coins} 🪙"))
        if (STARTER_TASKS.all { it.key in np.starter } && "_all" !in np.starter) {
            np = grant(np.copy(starter = np.starter + "_all"), STARTER_ALL_COINS, 0, 0, notes)
            notes.add(tr("🎓 مسیر مبتدی کامل شد! +$STARTER_ALL_COINS 🪙", "🎓 Starter path complete! +$STARTER_ALL_COINS 🪙"))
        }
        return np
    }

    internal fun ensureDay(pl: Player): Player {
        val d = today()
        return if (pl.missionDay == d) pl
        else pl.copy(missionDay = d, missionProg = emptyMap(), missionDone = emptySet(), bonusGiven = false)
    }

    internal fun missionTrack(pl0: Player, key: String, notes: MutableList<String>): Player {
        var pl = ensureDay(pl0)
        val m = DAILY_MISSIONS.firstOrNull { it.key == key } ?: return pl
        if (key in pl.missionDone) return pl
        val prog = (pl.missionProg[key] ?: 0) + 1
        pl = pl.copy(missionProg = pl.missionProg + (key to prog))
        if (prog >= m.target) {
            pl = grant(pl.copy(missionDone = pl.missionDone + key), m.coins, m.xp, 0, notes)
            notes.add(tr("📋 ماموریت «${m.fa}» کامل شد  +${m.coins} 🪙 +${m.xp} XP", "📋 Mission “${m.en}” done  +${m.coins} 🪙 +${m.xp} XP"))
            pl = starterTrack(pl, "mission", notes)
            if (!pl.bonusGiven && pl.missionDone.size >= MISSION_BONUS_NEEDED) {
                pl = grant(pl.copy(bonusGiven = true), MISSION_BONUS_COINS, MISSION_BONUS_XP, 0, notes)
                notes.add(tr("🎉 جایزه‌ی ویژه‌ی ماموریت‌ها  +$MISSION_BONUS_COINS 🪙", "🎉 Mission bonus  +$MISSION_BONUS_COINS 🪙"))
            }
        }
        return pl
    }

    internal fun addBadge(pl: Player, key: String, notes: MutableList<String>): Player {
        if (key in pl.badges) return pl
        val b = BADGES[key] ?: return pl
        notes.add(tr("🎖 نشان جدید: ${b.emoji} ${b.name}", "🎖 New badge: ${b.emoji} ${b.name}"))
        return pl.copy(badges = pl.badges + key)
    }

    /** با ۱۰۰ برد در یک فصل، نشان Prince of Dice همان فصل ثبت می‌شود (هر فصل یک‌بار). */
    internal fun princeCheck(pl: Player, notes: MutableList<String>): Player {
        val key = "prince:${pl.seasonNo}"
        if (pl.seasonWins < PRINCE_OF_DICE_WINS || key in pl.trophies) return pl
        notes.add(tr("🎲 نشان Prince of Dice فصل S${pl.seasonNo} گرفتی!", "🎲 You earned Prince of Dice for S${pl.seasonNo}!"))
        return pl.copy(trophies = pl.trophies + key)
    }

    internal fun say(notes: List<String>) {
        if (notes.isNotEmpty()) message = notes.joinToString("\n")
    }

    // ------------------------------------------------------------ ورود به برنامه
    private fun onOpen() {
        val notes = mutableListOf<String>()
        var pl = p
        val t = now()
        val day = today()
        if (pl.seasonStart == 0L) pl = pl.copy(seasonStart = t)
        pl = ensureWorld(pl)

        val prevOpen = pl.lastOpenDay
        val gap = if (prevOpen < 0) 0 else (day - prevOpen).toInt()
        if (prevOpen != day) {
            val streak = if (prevOpen == day - 1) pl.openStreak + 1 else 1
            pl = pl.copy(openStreak = streak, lastOpenDay = day)
            if (streak >= ACTIVITY_STAR_DAYS) pl = addBadge(pl, "activity_star", notes)
        }

        val minutes = if (pl.lastSimMs == 0L) 0.0 else min(1440.0, (t - pl.lastSimMs) / 60000.0)
        pl = runSim(pl, minutes, t)
        pl = checkSeason(pl, gap > SEASON_OFFLINE_DAYS, notes)
        pl = ensureDay(pl)
        commit(pl)
        say(notes)
        refreshLobbies()
    }

    /** هر ~۱۵ ثانیه از UI صدا زده می‌شود تا NPCها زنده بمانند. */
    fun liveTick() {
        val t = now()
        val notes = mutableListOf<String>()
        var pl = runSim(p, max(0.0, (t - p.lastSimMs) / 60000.0), t)
        pl = checkSeason(pl, false, notes)
        commit(pl)
        say(notes)
        refreshLobbies()
    }

    /** شبیه‌سازی NPCها؛ گزارش‌های تازه داخل برنامه ذخیره می‌شوند. */
    internal fun runSim(pl: Player, minutes: Double, t: Long): Player = simulate(pl, minutes, t)

    // ------------------------------------------------------------ فصل
    fun seasonTimeLeftMs(): Long = max(0L, p.seasonStart + p.seasonDays * 86_400_000L - now())

    internal fun checkSeason(pl: Player, offline: Boolean, notes: MutableList<String>): Player {
        if (now() < pl.seasonStart + pl.seasonDays * 86_400_000L) return pl
        return endSeason(pl, offline, notes)
    }

    internal fun endSeason(pl: Player, offline: Boolean, notes: MutableList<String>): Player {
        val no = pl.seasonNo
        val honorAdd = HashMap<String, Int>()
        val log = ArrayList<String>()
        fun add(mid: String, v: Int) { honorAdd[mid] = (honorAdd[mid] ?: 0) + v }

        val mids = listOf(ME) + pl.npcs.filter { !it.banned }.map { npcMid(it.id) }
        fun pts(m: String) = pl.pointsOf(m)
        fun xpOf(m: String) = if (m == ME) pl.xp else pl.npc(midToNpcId(m) ?: -1)?.xp ?: 0
        val league = mids.sortedByDescending { pts(it) }
        val levels = mids.sortedByDescending { xpOf(it) }
        var coins = 0

        // افتخارات فصلی مثل ربات: Conquer، King of level، Prince of Dice، Ranking 1/2/3
        val tro = HashMap<String, MutableList<String>>()
        fun trophy(mid: String, t: String) { tro.getOrPut(mid) { ArrayList() }.add(t) }
        pl.conquerors().forEach { trophy(it, "conq:$no") }
        league.take(3).forEachIndexed { i, m -> trophy(m, "rank:$no:${i + 1}") }
        levels.firstOrNull()?.let { trophy(it, "king:$no") }
        if (pl.seasonWins >= PRINCE_OF_DICE_WINS) trophy(ME, "prince:$no")
        pl.npcs.filter { it.seasonWins >= PRINCE_OF_DICE_WINS && !it.banned }.forEach { trophy(npcMid(it.id), "prince:$no") }
        tro[ME]?.forEach { t ->
            when (t.substringBefore(":")) {
                "conq" -> notes.add(tr("🐉 نشان Conquer فصل S$no گرفتی!", "🐉 You earned the Conquer badge for S$no!"))
                "king" -> notes.add(tr("👑 نشان King of level فصل S$no گرفتی!", "👑 You earned King of level for S$no!"))
                "prince" -> if (t !in pl.trophies) notes.add(tr("🎲 نشان Prince of Dice فصل S$no گرفتی!", "🎲 You earned Prince of Dice for S$no!"))
            }
        }

        league.take(3).forEachIndexed { i, m ->
            add(m, HONOR_LEAGUE[i + 1] ?: 0)
            if (m == ME) { coins += SEASON_USER_REWARDS[i + 1] ?: 0; log.add("S$no:league:${i + 1}") }
        }
        levels.take(3).forEachIndexed { i, m ->
            add(m, HONOR_LEVEL[i + 1] ?: 0)
            if (m == ME) { coins += LEVEL_SEASON_REWARDS[i + 1] ?: 0; log.add("S$no:level:${i + 1}") }
        }
        if (pl.seasonWins >= PRINCE_OF_DICE_WINS) { add(ME, HONOR_PRINCE); log.add("S$no:prince") }
        pl.npcs.filter { it.seasonWins >= PRINCE_OF_DICE_WINS && !it.banned }.forEach { add(npcMid(it.id), HONOR_PRINCE) }

        // اتحادها: رتبه‌ی ۱ تا ۳ جایزه‌ی بانک؛ اعضای اتحاد اول افتخار می‌گیرند
        val allyRank = pl.alliances.sortedByDescending { pl.allyPoints(it) }
        var alliances = pl.alliances
        allyRank.take(3).forEachIndexed { i, a ->
            alliances = alliances.map { x -> if (x.id == a.id) x.copy(bank = x.bank + (ALLY_SEASON_REWARDS[i + 1] ?: 0)) else x }
            if (i == 0) a.members.forEach { add(it, HONOR_ALLY_TOP) }
            if (ME in a.members) log.add("S$no:ally:${i + 1}")
        }

        val myRankL = league.indexOf(ME) + 1
        notes.add(tr("🏁 فصل S$no تموم شد! رتبه‌ی لیگ: $myRankL" + if (coins > 0) "  +${fmt(coins)} 🪙" else "",
            "🏁 Season S$no ended! League rank: $myRankL" + if (coins > 0) "  +${fmt(coins)} 🪙" else ""))
        val penalty = offline && pl.points >= SEASON_RESET_CAP
        if (penalty) notes.add(tr("😴 چون چند روز آفلاین بودی، $SEASON_OFFLINE_PENALTY امتیاز اضافه کم شد.",
            "😴 You were away for days: extra $SEASON_OFFLINE_PENALTY points deducted."))

        val top3 = league.take(3)
        val seasonRep = Report(
            kind = "season", time = now(), mine = false,
            names = top3.map { pl.nameOf(it) }, mids = top3, a = no,
        )
        val out = pl.copy(
            points = seasonReset(pl.points, penalty),
            coins = pl.coins + coins,
            honors = pl.honors + (honorAdd[ME] ?: 0),
            honorLog = (pl.honorLog + log).takeLast(60),
            trophies = (pl.trophies + (tro[ME] ?: emptyList<String>())).distinct(),
            seasonNo = no + 1, seasonStart = now(), seasonWins = 0,
            alliances = alliances,
            npcs = pl.npcs.map {
                it.copy(
                    points = seasonReset(it.points, false), seasonWins = 0,
                    honors = it.honors + (honorAdd[npcMid(it.id)] ?: 0),
                    trophies = (it.trophies + (tro[npcMid(it.id)] ?: emptyList<String>())).distinct(),
                )
            },
        )
        return emit(out, listOf(seasonRep))
    }

    // ------------------------------------------------------------ اعمال نتیجه روی یک عضو (من یا NPC)
    internal fun applyMember(pl: Player, mid: String, coins: Int, xp: Int, pts: Int, won: Boolean?, notes: MutableList<String>): Player {
        if (mid == ME) {
            var np = grant(pl, coins, xp, pts, notes)
            if (won == true) np = np.copy(wins = np.wins + 1, seasonWins = np.seasonWins + 1)
            if (won == false) np = np.copy(losses = np.losses + 1)
            return np
        }
        val id = midToNpcId(mid) ?: return pl
        val old = pl.npc(id) ?: return pl
        val upd = old.copy(
            points = (old.points + pts).coerceIn(0, FP_NPC_POINTS_CAP), coins = max(0, old.coins + coins), xp = old.xp + xp,
            wins = old.wins + if (won == true) 1 else 0, losses = old.losses + if (won == false) 1 else 0,
            seasonWins = old.seasonWins + if (won == true) 1 else 0,
        )
        return emit(pl.withNpc(id) { upd }, npcEvents(old, upd, now()))
    }

    // ------------------------------------------------------------ دوئل ۱v۱
    fun rollDuel(): DuelRoll? {
        if (p.coins < DUEL_MIN_COINS) {
            toast("حداقل $DUEL_MIN_COINS سکه لازمه. جایزه‌ی روزانه یا ماموریت‌ها رو بگیر.", "You need at least $DUEL_MIN_COINS coins. Claim the daily reward or missions.")
            return null
        }
        val pool = p.npcs.filter { p.isActiveNpc(it) }
        if (pool.isEmpty()) { toast("حریفی در دسترس نیست.", "No opponent available."); return null }
        val opp = pool.sortedBy { abs(it.points - p.points) }.take(8).random()
        val a = Random.nextInt(1, 7)
        var b: Int
        do { b = Random.nextInt(1, 7) } while (b == a)
        val npcWins = Random.nextInt(100) < p.npcWinPct
        val swap = (a > b) == npcWins        // اگر نتیجه با نتیجه‌ی خواسته نمی‌خواند، تاس‌ها جابه‌جا می‌شوند
        return if (swap) DuelRoll(opp, b, a) else DuelRoll(opp, a, b)
    }

    fun finishDuel(r: DuelRoll) {
        val notes = mutableListOf<String>()
        val won = r.won
        var pl = applyMember(
            p, ME,
            if (won) COIN_DUEL_WIN else COIN_DUEL_LOSS, if (won) XP_DUEL_WIN else XP_DUEL_LOSS,
            if (won) POINTS_DUEL_WIN else POINTS_DUEL_LOSS, won, notes,
        )
        pl = applyMember(
            pl, npcMid(r.opponent.id),
            if (won) COIN_DUEL_LOSS else COIN_DUEL_WIN, if (won) XP_DUEL_LOSS else XP_DUEL_WIN,
            if (won) POINTS_DUEL_LOSS else POINTS_DUEL_WIN, !won, mutableListOf(),
        )
        val winner = if (won) ME else npcMid(r.opponent.id)
        val loser = if (won) npcMid(r.opponent.id) else ME
        pl = emit(pl, listOf(pl.mkDuel(now(), winner, loser, if (won) r.mine else r.theirs, if (won) r.theirs else r.mine)))
        pl = missionTrack(pl, "play", notes)
        pl = starterTrack(pl, "first_game", notes)
        if (won) {
            pl = missionTrack(pl, "win", notes)
            pl = starterTrack(pl, "first_win", notes)
            pl = princeCheck(pl, notes)
        }
        commit(pl)
        say(notes)
    }

    // ------------------------------------------------------------ جایزه‌ی روزانه / سکه‌ی لابی / هدیه
    fun dailyAvailable(): Boolean = p.lastDailyDay != today()

    fun claimDaily() {
        val day = today()
        if (p.lastDailyDay == day) { toast("امروز جایزه‌ات رو گرفتی.", "You already claimed today."); return }
        val streak = if (p.lastDailyDay == day - 1) min(p.dailyStreak + 1, DAILY_MAX_STREAK) else 1
        val coins = DAILY_REWARDS[streak] ?: 10
        val notes = mutableListOf(tr("🎁 روز $streak: +$coins 🪙 +$XP_DAILY XP", "🎁 Day $streak: +$coins 🪙 +$XP_DAILY XP"))
        var pl = grant(p.copy(dailyStreak = streak, lastDailyDay = day), coins, XP_DAILY, 0, notes)
        pl = missionTrack(pl, "daily", notes)
        pl = starterTrack(pl, "daily", notes)
        commit(pl)
        say(notes)
    }

    fun chatCoinLeftMs(): Long = max(0L, COIN_CHAT_COOLDOWN_MS - (now() - p.chatCoinLast))

    fun claimChatCoin() {
        if (chatCoinLeftMs() > 0) {
            val s = chatCoinLeftMs() / 1000 + 1
            toast("$s ثانیه‌ی دیگه می‌تونی دوباره بزنی.", "Try again in $s seconds.")
            return
        }
        val c = Random.nextInt(COIN_CHAT_MIN, COIN_CHAT_MAX + 1)
        val notes = mutableListOf(tr("🪙 +$c سکه", "🪙 +$c coins"))
        var pl = grant(p.copy(chatCoinLast = now()), c, 0, 0, notes)
        pl = missionTrack(pl, "coin_word", notes)
        commit(pl)
        say(notes)
    }

    fun redeemGift(raw: String) {
        val code = raw.trim().uppercase()
        val g = p.gifts.firstOrNull { it.code == code }
        when {
            code.isEmpty() -> return
            g == null -> toast("کد نامعتبره.", "Invalid code.")
            g.expires in 1 until now() -> toast("این کد منقضی شده.", "This code has expired.")
            g.uses >= g.maxUses -> toast("ظرفیت این کد تموم شده.", "This code is fully used.")
            code in p.redeemed -> toast("قبلاً از این کد استفاده کردی.", "You already used this code.")
            else -> {
                val notes = mutableListOf(tr("🎟 کد هدیه ثبت شد: +${g.coins} 🪙 +${g.xp} XP +${g.points} امتیاز", "🎟 Gift redeemed: +${g.coins} 🪙 +${g.xp} XP +${g.points} pts"))
                val pl = grant(p, g.coins, g.xp, g.points, notes)
                    .copy(redeemed = p.redeemed + code, gifts = p.gifts.map { if (it.code == code) it.copy(uses = it.uses + 1) else it })
                commit(pl)
                say(notes)
            }
        }
    }

    fun markHelpSeen() {
        if ("help" in p.starter) return
        val notes = mutableListOf<String>()
        commit(starterTrack(p, "help", notes))
        say(notes)
    }

    fun setName(name: String) {
        val n = name.trim().take(20)
        if (n.isNotEmpty()) commit(p.copy(name = n))
    }

    // ------------------------------------------------------------ بانک
    fun openBank() {
        if (levelFromXp(p.xp) < BANK_MIN_LEVEL) { toast("بانک از لول $BANK_MIN_LEVEL باز میشه.", "The bank unlocks at level $BANK_MIN_LEVEL."); return }
        if (p.bankLevel == 0) commit(p.copy(bankLevel = 1, bankLast = now()))
    }

    private fun accrued(pl: Player): Player {
        if (pl.bankLevel == 0) return pl
        val (nb, nt, _) = bankAccrue(pl.bankBalance, pl.bankLevel, pl.bankLast, now())
        return pl.copy(bankBalance = nb, bankLast = nt)
    }

    fun refreshBank() { if (p.bankLevel > 0) commit(accrued(p)) }

    fun bankDeposit(amount: Int) {
        var pl = accrued(p)
        if (pl.bankLevel == 0) return
        if (amount <= 0 || amount > pl.coins) { toast("سکه‌ی کافی نداری.", "Not enough coins."); return }
        val cap = bankCap(pl.bankLevel)
        if (cap != null && pl.bankBalance + amount > cap) {
            val room = fmt(max(0L, cap - pl.bankBalance))
            toast("ظرفیت بانک پر میشه. جا برای $room سکه مونده.", "Bank capacity exceeded. Room left: $room.")
            return
        }
        pl = pl.copy(coins = pl.coins - amount, bankBalance = pl.bankBalance + amount)
        commit(pl)
    }

    fun bankWithdraw(amount: Int) {
        var pl = accrued(p)
        if (pl.bankLevel == 0) return
        if (amount <= 0 || amount > pl.bankBalance) { toast("موجودی بانک کافی نیست.", "Not enough in the bank."); return }
        val fee = (amount * BANK_WITHDRAW_FEE).toInt()
        pl = pl.copy(coins = pl.coins + amount - fee, bankBalance = pl.bankBalance - amount)
        commit(pl)
        toast("برداشت ${fmt(amount)} سکه (کارمزد ${fmt(fee)})", "Withdrew ${fmt(amount)} coins (fee ${fmt(fee)})")
    }

    fun bankUpgrade() {
        val pl = accrued(p)
        if (pl.bankLevel == 0 || pl.bankLevel >= BANK_MAX_LEVEL) return
        val cost = BANK_UPGRADE_COST[pl.bankLevel - 1]
        if (pl.coins < cost) { toast("برای ارتقا ${fmt(cost)} سکه لازمه.", "Upgrade costs ${fmt(cost)} coins."); return }
        commit(pl.copy(coins = pl.coins - cost, bankLevel = pl.bankLevel + 1))
        toast("بانک به سطح ${pl.bankLevel + 1} ارتقا پیدا کرد ✅", "Bank upgraded to level ${pl.bankLevel + 1} ✅")
    }

    // ------------------------------------------------------------ کازینو
    fun casinoCooldownLeft(): Long = max(0L, CASINO_COOLDOWN_MS - (now() - p.casinoLast))

    fun spinSlot(bet: Int): SlotResult? {
        val lv = levelFromXp(p.xp)
        when {
            lv < CASINO_MIN_LEVEL -> { toast("کازینو از لول $CASINO_MIN_LEVEL باز میشه.", "The casino unlocks at level $CASINO_MIN_LEVEL."); return null }
            bet < CASINO_MIN_BET || bet > casinoMaxBet(lv) -> { toast("مبلغ شرط مجاز نیست.", "Bet not allowed."); return null }
            bet > p.coins -> { toast("سکه‌ی کافی نداری.", "Not enough coins."); return null }
            casinoCooldownLeft() > 0 -> {
                val s = casinoCooldownLeft() / 1000 + 1
                toast("$s ثانیه صبر کن.", "Wait $s seconds.")
                return null
            }
        }
        val value = Random.nextInt(1, 65)
        val res = SlotResult(value, bet, slotMultiplier(value))
        commit(p.copy(coins = p.coins - bet + res.payout, casinoLast = now()))
        return res
    }

    // ------------------------------------------------------------ رتبه‌بندی‌ها
    private fun entries(): List<BoardEntry> {
        val con = p.conquerors()
        return p.npcs.filter { !it.banned }.map {
            val mid = npcMid(it.id)
            BoardEntry(0, it.name, levelFromXp(it.xp), it.points, it.honors, it.xp, false, mid, p.rankOf(mid, con).key)
        } + BoardEntry(0, p.name, levelFromXp(p.xp), p.points, p.honors, p.xp, true, ME, p.rankOf(ME, con).key)
    }

    private fun ranked(c: Comparator<BoardEntry>): List<BoardEntry> =
        entries().sortedWith(c).mapIndexed { i, e -> e.copy(rank = i + 1) }

    fun leagueBoard() = ranked(compareByDescending<BoardEntry> { it.points }.thenByDescending { it.xp })
    fun levelBoard() = ranked(compareByDescending<BoardEntry> { it.xp }.thenByDescending { it.points })
    fun honorBoard() = ranked(compareByDescending<BoardEntry> { it.honors }.thenByDescending { it.xp })

    fun allianceBoard(): List<Alliance> = p.alliances.sortedWith(
        compareByDescending<Alliance> { p.allyPoints(it) }.thenByDescending { it.level }
    )

    // ------------------------------------------------------------ ادمین
    fun adminLogin(code: String): Boolean {
        val h = MessageDigest.getInstance("SHA-256").digest(code.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val ok = h == ADMIN_CODE_SHA256
        if (ok) { commit(p.copy(admin = true)); toast("پنل ادمین فعال شد ✅", "Admin panel enabled ✅") }
        else toast("کد اشتباهه.", "Wrong code.")
        return ok
    }

    fun adminLogout() = commit(p.copy(admin = false))
}

// ------------------------------------------------------------ ذخیره و بازیابی حساب
/** متن پشتیبان کل حساب؛ با فایل یا کپی‌کردن ذخیره می‌شود و بعد از نصب دوباره برمی‌گردد. */
fun Game.exportAccount(): String =
    JSONObject().put("app", "DiceLeague").put("v", 1).put("saved", System.currentTimeMillis())
        .put("data", playerToJson(p)).toString()

fun Game.importAccount(raw: String): Boolean = try {
    val root = JSONObject(raw.trim())
    val data = if (root.optString("app") == "DiceLeague") root.getJSONObject("data") else root
    if (!data.has("coins") || !data.has("xp")) throw IllegalArgumentException("bad")
    val pl = playerFromJson(data)
    commit(pl.copy(admin = p.admin))   // دسترسی ادمین از روی فایل بازیابی نمی‌شود
    toast("حساب با موفقیت برگشت ✅", "Account restored ✅")
    true
} catch (e: Exception) {
    toast("فایل یا کد پشتیبان معتبر نیست.", "Invalid backup file or code.")
    false
}
