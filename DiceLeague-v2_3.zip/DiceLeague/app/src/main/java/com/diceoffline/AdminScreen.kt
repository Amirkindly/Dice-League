package com.diceoffline

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.diceoffline.game.*

@Composable
fun AdminScreen(game: Game, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        tr("👤 من", "👤 Me"), tr("🤖 NPC", "🤖 NPCs"), tr("🛡 اتحادها", "🛡 Alliances"),
        tr("🎟 هدیه", "🎟 Gifts"), tr("🏁 فصل", "🏁 Season"), tr("📋 گزارش/پروفایل", "📋 Reports/Profiles"), tr("⚙️ سیستم", "⚙️ System"),
    )
    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("🛡 پنل ادمین", "🛡 Admin panel"), onBack)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tabs.forEachIndexed { i, t -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Txt(t) }) }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (tab) {
                0 -> AdminMe(game)
                1 -> AdminNpcs(game)
                2 -> AdminAlliances(game)
                3 -> AdminGifts(game)
                4 -> AdminSeason(game)
                5 -> AdminReports(game)
                else -> AdminSystem(game, onBack)
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

// ------------------------------------------------------------------ من
@Composable
private fun AdminMe(game: Game) {
    val p = game.p
    var coins by remember { mutableStateOf("") }
    var xp by remember { mutableStateOf("") }
    var pts by remember { mutableStateOf("") }
    var lvl by remember { mutableStateOf("") }
    var hon by remember { mutableStateOf("") }
    AppCard {
        CardTitle(tr("افزودن / کم کردن", "Give / take"), tr("برای کم کردن عدد منفی بنویس", "Use a negative number to subtract"))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumField("🪙", coins, { coins = it }, Modifier.weight(1f))
            NumField("XP", xp, { xp = it }, Modifier.weight(1f))
            NumField("⭐", pts, { pts = it }, Modifier.weight(1f))
        }
        PBtn(tr("اعمال", "Apply"), Modifier.fillMaxWidth()) {
            game.adminGive(parseSigned(coins), parseSigned(xp), parseSigned(pts)); coins = ""; xp = ""; pts = ""
        }
    }
    AppCard {
        CardTitle(tr("تنظیم مستقیم", "Set directly"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            NumField(tr("لول (۱ تا $MAX_LEVEL)", "Level (1–$MAX_LEVEL)"), lvl, { lvl = it }, Modifier.weight(1f))
            OBtn(tr("ثبت", "Set")) { game.adminSetLevel(parseAmount(lvl)); lvl = "" }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            NumField(tr("افتخارات (الان ${p.honors})", "Honors (now ${p.honors})"), hon, { hon = it }, Modifier.weight(1f))
            OBtn(tr("ثبت", "Set")) { game.adminSetHonors(parseAmount(hon)); hon = "" }
        }
    }
    AppCard {
        CardTitle(tr("🎖 نشان‌ها", "🎖 Badges"), tr("روشن/خاموش کردن", "Toggle"))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BADGES.forEach { (k, b) ->
                FilterChip(selected = k in p.badges, onClick = { game.adminToggleBadge(k) }, label = { Text("${b.emoji} ${b.name}") })
            }
        }
    }
}

// ------------------------------------------------------------------ NPC
@Composable
private fun AdminNpcs(game: Game) {
    val p = game.p
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<Int?>(null) }
    var newName by remember { mutableStateOf("") }
    var names by remember { mutableStateOf("") }
    var confirmRegen by remember { mutableStateOf(false) }

    AppCard {
        CardTitle(tr("🎭 برنامه‌ی بازی NPCها (Fake Play)", "🎭 NPC play schedule (Fake Play)"), tr("رفتار شبیه‌سازی بازیکن‌ها", "How simulated players behave"))
        SwitchRow(tr("فعال", "Enabled"), p.fpEnabled) { v -> game.adminEdit { it.copy(fpEnabled = v) } }
        Stepper(tr("تعداد NPC", "NPC count"), p.npcCount, (FP_MIN_COUNT..FP_MAX_COUNT step 10).toList()) { game.adminSetNpcCount(it) }
        Stepper(tr("دوئل NPCها: هر … دقیقه", "NPC duel every … min"), p.duelEvery, FP_DUEL_STEPS) { v -> game.adminEdit { it.copy(duelEvery = v) } }
        Stepper(tr("لابی NPCها: هر … دقیقه", "NPC lobby every … min"), p.lobbyEvery, FP_LOBBY_STEPS) { v -> game.adminEdit { it.copy(lobbyEvery = v) } }
        Stepper(tr("تایمر لابی (دقیقه)", "Lobby timer (min)"), p.lobbyTimer, FP_LOBBY_TIMER_STEPS) { v -> game.adminEdit { it.copy(lobbyTimer = v) } }
        SwitchRow(tr("لابی‌های لیستی (باز)", "Listed open lobbies"), p.llOn) { v -> game.adminEdit { it.copy(llOn = v) } }
        Stepper(tr("ساخت لابی لیستی: هر … دقیقه", "Listed lobby every … min"), p.llEvery, FP_LL_EVERY_STEPS) { v -> game.adminEdit { it.copy(llEvery = v) } }
        Stepper(tr("عمر لابی لیستی (دقیقه)", "Listed lobby life (min)"), p.llTimer, FP_LOBBY_TIMER_STEPS) { v -> game.adminEdit { it.copy(llTimer = v) } }
        Stepper(tr("شانس برد NPC مقابل من", "NPC win chance vs me"), p.npcWinPct, (0..100 step 5).toList(), "%") { v -> game.adminEdit { it.copy(npcWinPct = v) } }
        SwitchRow(tr("اتحاد خودکار NPCها (عضویت/ساخت/دونیت)", "Auto alliance activity (join/create/donate)"), p.allyAuto) { v -> game.adminEdit { it.copy(allyAuto = v) } }
    }

    AppCard {
        CardTitle(tr("➕ افزودن NPC", "➕ Add NPC"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextF(tr("اسم", "Name"), newName, { newName = it }, Modifier.weight(1f))
            PBtn(tr("افزودن", "Add")) { game.adminNpcAdd(newName); newName = "" }
        }
        TextF(tr("اسم‌های دلخواه (با ویرگول جدا کن)", "Custom names (comma separated)"), names, { names = it }, Modifier.fillMaxWidth(), single = false)
        OBtn(tr("ذخیره‌ی اسم‌ها برای NPCهای جدید", "Save names for new NPCs"), Modifier.fillMaxWidth()) {
            val list = names.split(",", "،", "\n").map { it.trim() }.filter { it.isNotEmpty() }.distinct()
            game.adminEdit { it.copy(customNames = list) }
            names = ""
            game.toast("${list.size} اسم ذخیره شد.", "${list.size} names saved.")
        }
        OBtn(tr("🔄 ساخت دوباره‌ی همه‌ی NPCها", "🔄 Regenerate all NPCs"), Modifier.fillMaxWidth()) { confirmRegen = true }
    }

    AppCard {
        CardTitle(tr("🤖 فهرست NPCها", "🤖 NPC list"), tr("${p.npcs.size} نفر  ·  ${p.npcs.count { it.banned }} حذف‌شده از رتبه‌بندی  ·  ${p.npcs.count { it.restricted }} محدود", "${p.npcs.size} total  ·  ${p.npcs.count { it.banned }} banned  ·  ${p.npcs.count { it.restricted }} restricted"))
        TextF(tr("جستجو", "Search"), q, { q = it }, Modifier.fillMaxWidth())
        val shown = p.npcs.filter { q.isBlank() || it.name.contains(q.trim(), true) }.sortedByDescending { it.points }.take(40)
        shown.forEach { n ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((if (n.banned) "🚫 " else if (n.restricted) "⛔ " else "") + n.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Txt("Lv ${levelFromXp(n.xp)} · ⭐ ${n.points} · 🪙 ${n.coins} · ${n.wins}W/${n.losses}L", size = 11, color = MaterialTheme.colorScheme.muted, maxLines = 1)
                }
                TextButton({ sel = n.id }) { Txt(tr("مدیریت", "Manage")) }
            }
        }
        if (p.npcs.size > shown.size && q.isBlank()) Txt(tr("فقط ۴۰ NPC برتر نشان داده میشه؛ برای بقیه جستجو کن.", "Showing the top 40; search for others."), size = 11, color = MaterialTheme.colorScheme.muted)
    }

    val id = sel
    val n = id?.let { p.npc(it) }
    if (n != null) NpcDialog(game, n) { sel = null }
    if (confirmRegen) Confirm(tr("همه‌ی NPCها و اتحادها از نو ساخته میشن. مطمئنی؟", "All NPCs and alliances will be rebuilt. Sure?"), { confirmRegen = false; game.adminRegenNpcs() }, { confirmRegen = false })
}

@Composable
private fun NpcDialog(game: Game, n: Npc, onClose: () -> Unit) {
    var confirmDel by remember { mutableStateOf(false) }
    var coins by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(n.name, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Txt("Lv ${levelFromXp(n.xp)} · ⭐ ${n.points} · 🏅 ${n.honors} · 🪙 ${n.coins}", size = 12, color = MaterialTheme.colorScheme.muted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-200, -50, 50, 200).forEach { dlt -> OutlinedButton({ game.adminNpcPoints(n.id, dlt) }, Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Txt(if (dlt > 0) "+$dlt⭐" else "$dlt⭐", size = 11) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-5, -1, 1, 5).forEach { dlt -> OutlinedButton({ game.adminNpcLevel(n.id, dlt) }, Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Txt(if (dlt > 0) "+$dlt Lv" else "$dlt Lv", size = 11) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    NumField("🪙", coins, { coins = it }, Modifier.weight(1f))
                    OBtn(tr("افزودن", "Add")) { val c = parseSigned(coins); game.adminNpc(n.id) { it.copy(coins = maxOf(0, it.coins + c)) }; coins = "" }
                }
                val openProfile = LocalOpenProfile.current
                OBtn(tr("👁 دیدن پروفایل", "👁 View profile"), Modifier.fillMaxWidth()) { openProfile(npcMid(n.id)); onClose() }
                Txt(tr("🎖 نشان‌ها", "🎖 Badges"), bold = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BADGES.forEach { (k, b) ->
                        FilterChip(selected = k in n.badges, onClick = { game.adminNpcBadge(n.id, k) }, label = { Text("${b.emoji} ${b.name}") })
                    }
                }
                SwitchRow(tr("🚫 حذف از رتبه‌بندی و بازی‌ها", "🚫 Ban (hide everywhere)"), n.banned) { v -> game.adminNpc(n.id) { it.copy(banned = v) } }
                SwitchRow(tr("⛔ محدود (بدون لابی/نبرد/اتحاد)", "⛔ Restrict (no lobby/war/alliance)"), n.restricted) { v -> game.adminNpc(n.id) { it.copy(restricted = v) } }
                OBtn(tr("🗑 حذف کامل NPC", "🗑 Delete NPC"), Modifier.fillMaxWidth()) { confirmDel = true }
            }
        },
        confirmButton = { TextButton(onClose) { Txt(tr("بستن", "Close"), bold = true) } },
    )
    if (confirmDel) Confirm(tr("NPC برای همیشه حذف میشه.", "This NPC will be deleted permanently."), { confirmDel = false; game.adminNpcDelete(n.id); onClose() }, { confirmDel = false })
}

// ------------------------------------------------------------------ اتحادها
@Composable
private fun AdminAlliances(game: Game) {
    val p = game.p
    var name by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<Int?>(null) }
    AppCard {
        CardTitle(tr("➕ ساخت اتحاد NPC", "➕ Create an NPC alliance"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextF(tr("اسم اتحاد", "Alliance name"), name, { name = it }, Modifier.weight(1f))
            PBtn(tr("بساز", "Create")) { game.adminAllyCreate(name); name = "" }
        }
    }
    AppCard {
        CardTitle(tr("🛡 همه‌ی اتحادها (${p.alliances.size})", "🛡 All alliances (${p.alliances.size})"))
        game.allianceBoard().forEach { a ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((if (ME in a.members) "⭐ " else "") + a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Txt("Lv ${a.level} · 👥 ${a.members.size} · 🪙 ${fmt(a.bank)} · ${tr("رهبر", "leader")}: ${p.nameOf(a.owner)}", size = 11, color = MaterialTheme.colorScheme.muted, maxLines = 1)
                }
                TextButton({ sel = a.id }) { Txt(tr("مدیریت", "Manage")) }
            }
        }
    }
    val a = sel?.let { p.ally(it) }
    if (a != null) AllyDialog(game, a) { sel = null }
}

@Composable
private fun AllyDialog(game: Game, a: Alliance, onClose: () -> Unit) {
    val p = game.p
    var confirmDel by remember { mutableStateOf(false) }
    var bank by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(a.name, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Stepper(tr("لول اتحاد", "Alliance level"), a.level, (1..ALLY_MAX_LEVEL).toList()) { v -> game.adminAlly(a.id) { it.copy(level = v) } }
                Stepper(tr("حداقل لول ورود", "Min level"), a.minLevel, ALLY_MIN_LEVEL_STEPS) { v -> game.adminAlly(a.id) { it.copy(minLevel = v) } }
                Stepper(tr("حداقل امتیاز ورود", "Min points"), a.minPoints, ALLY_MIN_POINTS_STEPS) { v -> game.adminAlly(a.id) { it.copy(minPoints = v) } }
                SwitchRow(tr("قفل", "Locked"), a.locked) { v -> game.adminAlly(a.id) { it.copy(locked = v) } }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    NumField(tr("بانک 🪙 (${fmt(a.bank)})", "Bank 🪙 (${fmt(a.bank)})"), bank, { bank = it }, Modifier.weight(1f))
                    OBtn(tr("افزودن", "Add")) { val c = parseSigned(bank).toLong(); game.adminAlly(a.id) { it.copy(bank = maxOf(0L, it.bank + c)) }; bank = "" }
                }
                OBtn(tr("➕ افزودن یک NPC آزاد", "➕ Add a free NPC"), Modifier.fillMaxWidth()) {
                    val free = p.npcs.filter { p.isActiveNpc(it) && p.allyOf(npcMid(it.id)) == null }
                    if (free.isEmpty()) game.toast("NPC آزاد نیست.", "No free NPC.") else game.adminAllyAddNpc(a.id, free.random().id)
                }
                Txt(tr("اعضا:", "Members:"), bold = true)
                a.members.forEach { m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text((if (m == a.owner) "👑 " else "") + p.nameOf(m), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        TextButton({ game.adminAllyRemove(m) }) { Txt(tr("حذف", "Remove"), color = MaterialTheme.colorScheme.bad) }
                    }
                }
                OBtn(tr("🗑 انحلال اتحاد", "🗑 Disband alliance"), Modifier.fillMaxWidth()) { confirmDel = true }
            }
        },
        confirmButton = { TextButton(onClose) { Txt(tr("بستن", "Close"), bold = true) } },
    )
    if (confirmDel) Confirm(tr("اتحاد منحل میشه.", "The alliance will be disbanded."), { confirmDel = false; game.adminAllyDelete(a.id); onClose() }, { confirmDel = false })
}

// ------------------------------------------------------------------ کد هدیه
@Composable
private fun AdminGifts(game: Game) {
    val p = game.p
    var code by remember { mutableStateOf("") }
    var coins by remember { mutableStateOf("") }
    var xp by remember { mutableStateOf("") }
    var pts by remember { mutableStateOf("") }
    var uses by remember { mutableStateOf("1") }
    var days by remember { mutableStateOf("0") }
    AppCard {
        CardTitle(tr("🎟 ساخت کد هدیه", "🎟 Create gift code"))
        TextF(tr("کد", "Code"), code, { code = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumField("🪙", coins, { coins = it }, Modifier.weight(1f))
            NumField("XP", xp, { xp = it }, Modifier.weight(1f))
            NumField("⭐", pts, { pts = it }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumField(tr("ظرفیت", "Max uses"), uses, { uses = it }, Modifier.weight(1f))
            NumField(tr("انقضا (روز، ۰=ندارد)", "Expiry (days, 0=none)"), days, { days = it }, Modifier.weight(1f))
        }
        PBtn(tr("ساخت", "Create"), Modifier.fillMaxWidth()) {
            game.adminGiftCreate(code, parseAmount(coins), parseAmount(xp), parseAmount(pts), parseAmount(uses), parseAmount(days))
            code = ""
        }
    }
    AppCard {
        CardTitle(tr("کدهای فعال (${p.gifts.size})", "Active codes (${p.gifts.size})"))
        p.gifts.forEach { g ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(g.code, fontWeight = FontWeight.Bold)
                    Txt("🪙${g.coins} XP${g.xp} ⭐${g.points} · ${g.uses}/${g.maxUses}", size = 11, color = MaterialTheme.colorScheme.muted)
                }
                TextButton({ game.adminGiftDelete(g.code) }) { Txt(tr("حذف", "Delete"), color = MaterialTheme.colorScheme.bad) }
            }
        }
    }
}

// ------------------------------------------------------------------ فصل
@Composable
private fun AdminSeason(game: Game) {
    val p = game.p
    var xpAll by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("") }
    var confirmEnd by remember { mutableStateOf(false) }
    AppCard {
        CardTitle(tr("🏁 فصل ${p.seasonNo}", "🏁 Season ${p.seasonNo}"), tr("${dur(game.seasonTimeLeftMs())} مانده", "${dur(game.seasonTimeLeftMs())} left"))
        Stepper(tr("طول فصل (روز)", "Season length (days)"), p.seasonDays, listOf(1, 2, 3, 5, 7, 10, 14, 15, 20, 30, 45, 60, 90)) { v -> game.adminSetSeasonDays(v) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            NumField(tr("مدت دلخواه (۱ تا ۳۶۵ روز)", "Custom length (1–365 days)"), days, { days = it }, Modifier.weight(1f))
            OBtn(tr("ثبت", "Set")) { if (parseAmount(days) > 0) game.adminSetSeasonDays(parseAmount(days)); days = "" }
        }
        OBtn(tr("🔄 شروع دوباره‌ی زمان فصل از همین الان", "🔄 Restart the season timer now"), Modifier.fillMaxWidth()) { game.adminRestartSeasonTimer() }
        OBtn(tr("⏭ پایان فوری فصل", "⏭ End season now"), Modifier.fillMaxWidth()) { confirmEnd = true }
    }
    AppCard {
        CardTitle(tr("✨ XP همگانی", "✨ XP for everyone"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            NumField("XP", xpAll, { xpAll = it }, Modifier.weight(1f))
            PBtn(tr("بده", "Give")) { game.adminXpAll(parseSigned(xpAll)); xpAll = "" }
        }
    }
    AppCard {
        CardTitle(tr("⏩ شبیه‌سازی دستی", "⏩ Manual simulation"), tr("NPCها چند دقیقه بازی می‌کنند", "NPCs play for some minutes"))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(30, 120, 600, 1440).forEach { m ->
                OutlinedButton({ game.adminSimulate(m.toDouble()) }, Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Txt(if (m < 60) "${m}m" else "${m / 60}h", size = 12) }
            }
        }
    }
    if (confirmEnd) Confirm(tr("فصل همین الان تموم میشه و جایزه‌ها داده میشن.", "The season ends now and rewards are paid."), { confirmEnd = false; game.adminEndSeasonNow() }, { confirmEnd = false })
}

// ------------------------------------------------------------------ گزارش‌ها و پروفایل‌ها
@Composable
private fun AdminReports(game: Game) {
    val p = game.p
    var confirmClear by remember { mutableStateOf(false) }

    AppCard {
        CardTitle(tr("📋 منوی گزارش‌ها", "📋 Reports menu"), tr("گزارش‌ها فقط داخل برنامه نشان داده می‌شوند؛ این‌جا تعیین کن چه چیزی دیده شود", "Reports live inside the app only; choose what players can see"))
        SwitchRow(tr("🤖 تب بازی‌های NPCها", "🤖 NPC games tab"), p.repNpc) { v -> game.adminEdit { it.copy(repNpc = v) } }
        SwitchRow(tr("👤 تب بازی‌های من", "👤 My games tab"), p.repMine) { v -> game.adminEdit { it.copy(repMine = v) } }
        SwitchRow(tr("🏅 تب رنک و لول و پایان فصل", "🏅 Ranks, levels & season-end tab"), p.repEvents) { v -> game.adminEdit { it.copy(repEvents = v) } }
        Stepper(tr("حداکثر گزارش ذخیره‌شده", "Max stored reports"), p.repMax, listOf(50, 100, 200, 300, 500)) { v ->
            game.adminEdit { it.copy(repMax = v, reports = it.reports.takeLast(v)) }
        }
        Txt(tr("${p.reports.size} گزارش ذخیره شده است.", "${p.reports.size} reports stored."), size = 11, color = MaterialTheme.colorScheme.muted)
        OBtn(tr("🧹 پاک کردن همه‌ی گزارش‌ها", "🧹 Clear all reports"), Modifier.fillMaxWidth()) { confirmClear = true }
    }

    AppCard {
        CardTitle(tr("🖼 پروفایل‌ها", "🖼 Profiles"), tr("۳ پروفایل رایگان‌اند و ۷ تا با لول باز می‌شوند", "3 are free, 7 unlock with level"))
        SwitchRow(tr("همه‌ی پروفایل‌ها باز باشند", "Unlock every profile"), p.avatarsOpen) { v -> game.adminEdit { it.copy(avatarsOpen = v) } }
        AVATARS.forEach { a ->
            Txt("${a.emoji} ${tr(a.fa, a.en)} — " + if (a.level <= 1) tr("رایگان", "Free") else "Lv ${a.level}", size = 12, color = MaterialTheme.colorScheme.muted)
        }
    }

    AppCard {
        CardTitle(tr("🏆 اهدای افتخار فصلی به خودم", "🏆 Give myself a season honor"), tr("روی هر مورد بزن تا اضافه/حذف شود", "Tap to add / remove"))
        var season by remember { mutableStateOf(p.seasonNo.toString()) }
        NumField(tr("شماره‌ی فصل", "Season number"), season, { season = it }, Modifier.fillMaxWidth())
        val s = parseAmount(season).coerceAtLeast(1)
        val opts = listOf(
            "conq:$s" to "🐉 Conquer", "king:$s" to "👑 King of level", "prince:$s" to "🎲 Prince of Dice",
            "rank:$s:1" to "🥇 1st", "rank:$s:2" to "🥈 2nd", "rank:$s:3" to "🥉 3rd",
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            opts.forEach { (key, label) ->
                FilterChip(selected = key in p.trophies, onClick = { game.adminToggleTrophy(key) }, label = { Text("$label S$s") })
            }
        }
    }
    if (confirmClear) Confirm(tr("همه‌ی گزارش‌ها پاک میشن. مطمئنی؟", "All reports will be deleted. Sure?"), { confirmClear = false; game.adminClearReports() }, { confirmClear = false })
}

// ------------------------------------------------------------------ سیستم
@Composable
private fun AdminSystem(game: Game, onBack: () -> Unit) {
    val p = game.p
    val clip = LocalClipboardManager.current
    var raw by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    AppCard {
        CardTitle(tr("📊 آمار", "📊 Stats"))
        Txt(tr("NPC: ${p.npcs.size}  ·  اتحاد: ${p.alliances.size}  ·  لابی باز: ${game.lobbies.size}\nلول من: ${levelFromXp(p.xp)}  ·  سکه: ${fmt(p.coins)}  ·  فصل: ${p.seasonNo}",
            "NPCs: ${p.npcs.size}  ·  Alliances: ${p.alliances.size}  ·  Open lobbies: ${game.lobbies.size}\nMy level: ${levelFromXp(p.xp)}  ·  Coins: ${fmt(p.coins)}  ·  Season: ${p.seasonNo}"), size = 13)
    }
    AppCard {
        CardTitle(tr("💾 بکاپ", "💾 Backup"))
        OBtn(tr("کپی بکاپ در کلیپ‌بورد", "Copy backup to clipboard"), Modifier.fillMaxWidth()) {
            clip.setText(AnnotatedString(game.adminExport()))
            game.toast("بکاپ کپی شد.", "Backup copied.")
        }
        TextF(tr("متن بکاپ", "Backup text"), raw, { raw = it }, Modifier.fillMaxWidth(), single = false)
        PBtn(tr("بازیابی", "Restore"), Modifier.fillMaxWidth()) { if (game.adminImport(raw)) raw = "" }
    }
    AppCard {
        CardTitle(tr("⚠️ خطرناک", "⚠️ Danger zone"))
        OBtn(tr("🧨 ریست کامل بازی", "🧨 Reset everything"), Modifier.fillMaxWidth()) { confirmReset = true }
        OBtn(tr("🚪 خروج از پنل ادمین", "🚪 Leave admin mode"), Modifier.fillMaxWidth()) { game.adminLogout(); onBack() }
    }
    if (confirmReset) Confirm(tr("همه‌ی پیشرفت پاک میشه. مطمئنی؟", "All progress will be erased. Sure?"), { confirmReset = false; game.adminResetAll() }, { confirmReset = false })
}
