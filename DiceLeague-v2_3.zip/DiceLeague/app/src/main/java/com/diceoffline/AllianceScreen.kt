package com.diceoffline

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.diceoffline.game.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AllianceScreen(game: Game) {
    val p = game.p
    val mine = p.myAlly()
    val scope = rememberCoroutineScope()
    var battle by remember { mutableStateOf<TeamRoll?>(null) }
    var rolling by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        battle?.let { TeamResultCard(it, rolling, tr("⚔️ نبرد اتحادها", "⚔️ Alliance war")) }
        if (mine == null) NoAlliance(game) else MyAlliance(game, mine, rolling) {
            val r = game.rollBattle() ?: return@MyAlliance
            battle = r
            rolling = true
            scope.launch {
                delay(1700)
                game.finishBattle(r)
                rolling = false
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ReqChips(a: Alliance) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Pill(if (a.minLevel > 0) tr("لول ≥ ${a.minLevel}", "Lv ≥ ${a.minLevel}") else tr("بدون شرط لول", "No level req"))
        Pill(if (a.minPoints > 0) tr("امتیاز ≥ ${a.minPoints}", "Pts ≥ ${a.minPoints}") else tr("بدون شرط امتیاز", "No points req"))
    }
}

@Composable
private fun NoAlliance(game: Game) {
    val p = game.p
    var name by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    AppCard {
        CardTitle(tr("🛡 ساخت اتحاد", "🛡 Create an alliance"), tr("هزینه: ${fmt(ALLY_CREATE_COST)} 🪙", "Cost: ${fmt(ALLY_CREATE_COST)} 🪙"))
        TextF(tr("اسم اتحاد (۳ تا ۲۰ حرف)", "Alliance name (3–20)"), name, { name = it }, Modifier.fillMaxWidth())
        PBtn(tr("بساز", "Create"), Modifier.fillMaxWidth()) { game.allianceCreate(name); name = "" }
    }
    Txt(tr("🌐 اتحادهای موجود", "🌐 Available alliances"), size = 17, bold = true)
    TextF(tr("جستجو", "Search"), q, { q = it }, Modifier.fillMaxWidth())
    val list = game.allianceBoard().filter { q.isBlank() || it.name.contains(q.trim(), true) }
    if (list.isEmpty()) Txt(tr("اتحادی پیدا نشد.", "No alliances found."), color = MaterialTheme.colorScheme.muted)
    list.forEach { a ->
        val okLv = p.levelOf(ME) >= a.minLevel
        val okPts = p.points >= a.minPoints
        val full = a.members.size >= ALLY_MAX_MEMBERS
        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(a.name, 40.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Txt("Lv ${a.level}  ·  👥 ${a.members.size}/$ALLY_MAX_MEMBERS  ·  ⭐ ${fmt(p.allyPoints(a))}", size = 12, color = MaterialTheme.colorScheme.muted)
                    Txt(tr("رهبر: ", "Leader: ") + p.nameOf(a.owner), size = 11, color = MaterialTheme.colorScheme.muted, maxLines = 1)
                }
                PBtn(if (full) tr("پر", "Full") else tr("عضویت", "Join"), enabled = !full && okLv && okPts) { game.allianceJoin(a.id) }
            }
            ReqChips(a)
            if (!okLv || !okPts) Txt(tr("شرایط ورود رو نداری.", "You don't meet the requirements."), size = 11, color = MaterialTheme.colorScheme.bad)
        }
    }
}

@Composable
private fun MyAlliance(game: Game, a: Alliance, rolling: Boolean, onBattle: () -> Unit) {
    val p = game.p
    val role = game.myRole()
    val mgr = game.isManager()
    var amount by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var confirmLeave by remember { mutableStateOf(false) }

    GradientHeader {
        Avatar(a.name, 56.dp)
        Text(a.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
        Txt(
            when (role) { Role.OWNER -> tr("👑 رهبر", "👑 Leader"); Role.DEPUTY -> tr("🛡 معاون", "🛡 Deputy"); else -> tr("عضو", "Member") },
            size = 12, color = MaterialTheme.colorScheme.primary,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("${a.level}", tr("لول", "Level"), Modifier.weight(1f))
            StatBox("${a.members.size}/$ALLY_MAX_MEMBERS", tr("اعضا", "Members"), Modifier.weight(1f))
            StatBox(fmt(p.allyPoints(a)), tr("امتیاز", "Points"), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("${a.won}", tr("برد", "Wins"), Modifier.weight(1f))
            StatBox("${a.lost}", tr("باخت", "Losses"), Modifier.weight(1f))
            StatBox(fmt(a.bank), tr("بانک 🪙", "Bank 🪙"), Modifier.weight(1f))
        }
    }

    AppCard {
        CardTitle(tr("⚔️ نبرد اتحاد", "⚔️ Alliance war"), tr("با یک اتحاد دیگه رو‌در‌رو شو؛ برد = ${ALLY_BATTLE_REWARD} 🪙 برای بانک اتحاد", "Face another alliance — a win gives $ALLY_BATTLE_REWARD 🪙 to the bank"))
        PBtn(tr("⚔️ جستجوی حریف", "⚔️ Find an opponent"), Modifier.fillMaxWidth(), enabled = !rolling) { onBattle() }
    }

    // درخواست‌های عضویت
    if (a.requests.isNotEmpty() && mgr) AppCard {
        CardTitle(tr("📨 درخواست‌های عضویت", "📨 Join requests"))
        a.requests.forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.nameOf(m), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Txt("Lv ${p.levelOf(m)}  ·  ⭐ ${fmt(p.pointsOf(m))}", size = 11, color = MaterialTheme.colorScheme.muted)
                }
                TextButton({ game.allianceApprove(m, true) }) { Text("✅") }
                TextButton({ game.allianceApprove(m, false) }) { Text("❌") }
            }
        }
    }

    // بانک
    AppCard {
        CardTitle(tr("🏦 بانک اتحاد", "🏦 Alliance bank"), tr("موجودی: ${fmt(a.bank)} 🪙", "Balance: ${fmt(a.bank)} 🪙"))
        NumField(tr("مقدار", "Amount"), amount, { amount = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PBtn(tr("🪙 دونیت", "🪙 Donate"), Modifier.weight(1f)) { game.allianceDeposit(parseAmount(amount)); amount = "" }
            if (role == Role.OWNER) OBtn(tr("برداشت", "Withdraw"), Modifier.weight(1f)) { game.allianceWithdraw(parseAmount(amount)); amount = "" }
        }
        if (mgr) {
            val cost = game.allianceUpgradeCost(a)
            OBtn(
                if (cost == null) tr("اتحاد در بالاترین لول ✅", "Max level ✅") else tr("⬆️ ارتقا به لول ${a.level + 1}  (${fmt(cost)} 🪙)", "⬆️ Upgrade to level ${a.level + 1}  (${fmt(cost)} 🪙)"),
                Modifier.fillMaxWidth(), enabled = cost != null,
            ) { game.allianceUpgrade() }
        }
    }

    // شرایط ورود
    AppCard {
        CardTitle(tr("🚪 شرایط ورود", "🚪 Entry requirements"), if (mgr) tr("رهبر و معاون‌ها می‌تونن تغییر بدن", "Leader and deputies can edit") else null)
        if (mgr) {
            Stepper(tr("حداقل لول", "Min level"), a.minLevel, ALLY_MIN_LEVEL_STEPS) { game.allianceSetReq(it, a.minPoints) }
            Stepper(tr("حداقل امتیاز", "Min points"), a.minPoints, ALLY_MIN_POINTS_STEPS) { game.allianceSetReq(a.minLevel, it) }
            SwitchRow(tr("قفل (ورود فقط با تأیید تو)", "Lock (join needs approval)"), a.locked) { game.allianceToggleLock() }
        } else ReqChips(a)
    }

    // اعضا
    AppCard {
        CardTitle(tr("👥 اعضا", "👥 Members"))
        val openProfile = LocalOpenProfile.current
        a.members.sortedByDescending { p.pointsOf(it) }.forEach { m ->
            var menu by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().clickable { openProfile(m) }, verticalAlignment = Alignment.CenterVertically) {
                Avatar(p.nameOf(m), 32.dp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (m == a.owner) "👑 " else if (m in a.deputies) "🛡 " else "") + p.nameOf(m),
                        fontWeight = if (m == ME) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (m == ME) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Unspecified,
                    )
                    Txt("Lv ${p.levelOf(m)}  ·  ⭐ ${fmt(p.pointsOf(m))}", size = 11, color = MaterialTheme.colorScheme.muted)
                }
                if (mgr && m != ME && m != a.owner) {
                    Box {
                        TextButton({ menu = true }) { Text("⋮") }
                        DropdownMenu(menu, { menu = false }) {
                            if (role == Role.OWNER) {
                                DropdownMenuItem(text = { Txt(if (m in a.deputies) tr("برکناری از معاونت", "Remove deputy") else tr("ارتقا به معاون", "Make deputy")) }, onClick = { menu = false; game.allianceToggleDeputy(m) })
                                DropdownMenuItem(text = { Txt(tr("انتقال رهبری", "Transfer leadership")) }, onClick = { menu = false; game.allianceTransfer(m) })
                            }
                            DropdownMenuItem(text = { Txt(tr("اخراج", "Kick"), color = MaterialTheme.colorScheme.bad) }, onClick = { menu = false; game.allianceKick(m) })
                        }
                    }
                }
            }
        }
    }

    if (role == Role.OWNER) AppCard {
        CardTitle(tr("✏️ تغییر اسم", "✏️ Rename"), tr("${fmt(ALLY_RENAME_COST)} 🪙 — هر $ALLY_RENAME_COOLDOWN_DAYS روز یک‌بار", "${fmt(ALLY_RENAME_COST)} 🪙 — once every $ALLY_RENAME_COOLDOWN_DAYS days"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextF(tr("اسم جدید", "New name"), newName, { newName = it }, Modifier.weight(1f))
            PBtn(tr("ثبت", "Save")) { game.allianceRename(newName); newName = "" }
        }
    }

    OBtn(tr("🚪 خروج از اتحاد", "🚪 Leave alliance"), Modifier.fillMaxWidth()) { confirmLeave = true }
    if (confirmLeave) Confirm(tr("از اتحاد خارج میشی؟", "Leave the alliance?"), { confirmLeave = false; game.allianceLeave() }, { confirmLeave = false })
}
