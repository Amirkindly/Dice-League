package com.diceoffline

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceoffline.game.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** نتیجه‌ی تیمی؛ برای لابی و نبرد اتحاد. */
@Composable
fun TeamResultCard(res: TeamRoll, rolling: Boolean, title: String) {
    val meInA = res.teamA.any { it.mid == ME }
    val tie = res.sumA == res.sumB
    val iWon = if (meInA) res.sumA > res.sumB else res.sumB > res.sumA
    AppCard {
        CardTitle(title)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TeamColumn(res.nameA, res.teamA, rolling, res.mvpA, Modifier.weight(1f))
            TeamColumn(res.nameB, res.teamB, rolling, res.mvpB, Modifier.weight(1f))
        }
        if (!rolling) {
            Txt("${res.sumA}  :  ${res.sumB}", size = 22, bold = true, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            Txt(
                when {
                    tie -> tr("⚖️ مساوی", "⚖️ Tie")
                    iWon -> tr("🏆 تیم تو برد!", "🏆 Your team won!")
                    else -> tr("❌ تیم تو باخت", "❌ Your team lost")
                },
                bold = true, size = 16, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center,
                color = if (tie) MaterialTheme.colorScheme.muted else if (iWon) MaterialTheme.colorScheme.good else MaterialTheme.colorScheme.bad,
            )
        }
    }
}

@Composable
private fun TeamColumn(name: String, team: List<Roller>, rolling: Boolean, mvp: Roller?, modifier: Modifier) {
    Surface(modifier, shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            team.forEach { r ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        (if (!rolling && r.mid == mvp?.mid) "⭐ " else "") + r.name,
                        Modifier.weight(1f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = if (r.mid == ME) FontWeight.Bold else FontWeight.Normal,
                        color = if (r.mid == ME) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Unspecified,
                    )
                    RollingDice(r.dice, rolling, 26.dp)
                }
            }
            if (!rolling) Txt("Σ ${team.sumOf { it.dice }}", size = 12, bold = true)
        }
    }
}

@Composable
fun LobbyScreen(game: Game) {
    val now by tickState()
    val scope = rememberCoroutineScope()
    var res by remember { mutableStateOf<TeamRoll?>(null) }
    var rolling by remember { mutableStateOf(false) }

    fun play(size: Int, dropId: Int?) {
        if (rolling) return
        val r = game.rollLobby(size) ?: return
        if (dropId != null) game.dropLobby(dropId)
        res = r
        rolling = true
        scope.launch {
            delay(1600)
            game.finishLobby(r)
            rolling = false
        }
    }

    LaunchedEffect(Unit) { game.refreshLobbies() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        res?.let { TeamResultCard(it, rolling, tr("👥 نتیجه‌ی لابی", "👥 Lobby result")) }

        AppCard {
            CardTitle(tr("⚡ لابی سریع", "⚡ Quick lobby"), tr("تیم Demon در برابر Angel؛ جایزه‌ی MVP دارد", "Demon vs Angel — MVP gets a bonus"))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LOBBY_SIZES.forEach { s ->
                    OutlinedButton({ play(s, null) }, Modifier.weight(1f), enabled = !rolling, contentPadding = PaddingValues(0.dp)) { Txt("$s") }
                }
            }
            Txt(tr("عدد = تعداد بازیکنان لابی", "Number = lobby size"), size = 11, color = MaterialTheme.colorScheme.muted)
        }

        Txt(tr("🌐 لابی‌های باز", "🌐 Open lobbies"), size = 17, bold = true)
        val list = game.lobbies
        if (list.isEmpty()) Txt(tr("لابی بازی نیست؛ چند لحظه‌ی دیگه نگاه کن.", "No open lobbies right now."), color = MaterialTheme.colorScheme.muted)
        list.forEach { c ->
            val left = (c.endsAt - now).coerceAtLeast(0)
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.host, 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.host, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Txt("👥 ${c.filled}/${c.size}   ⏳ ${dur(left)}", size = 12, color = MaterialTheme.colorScheme.muted)
                    }
                    PBtn(tr("ورود", "Join"), enabled = !rolling && left > 0) { play(c.size, c.id) }
                }
                LinearProgressIndicator(progress = { c.filled.toFloat() / c.size }, Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
