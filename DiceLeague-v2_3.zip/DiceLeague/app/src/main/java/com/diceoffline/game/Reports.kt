package com.diceoffline.game

// ----------------------------------------------------------------- رنک فاتح و نشان‌ها
/** ۵۰ نفر برتر لیگ که حداقل CONQUEROR_MIN_POINTS امتیاز دارند. */
fun Player.conquerors(): Set<String> =
    (listOf(ME to points) + npcs.filter { !it.banned }.map { npcMid(it.id) to it.points })
        .filter { it.second >= CONQUEROR_MIN_POINTS }
        .sortedByDescending { it.second }
        .take(CONQUEROR_SLOTS)
        .map { it.first }
        .toSet()

fun Player.rankOf(mid: String, con: Set<String> = conquerors()): Rank =
    if (mid in con) CONQUEROR else rankFor(pointsOf(mid))

/** نشان‌های من یا یک NPC (مالک اتحاد لول ۱۰ همیشه نشان Maxed Unity دارد). */
fun Player.badgesOf(mid: String): Set<String> {
    if (mid == ME) return badges
    val n = midToNpcId(mid)?.let { npc(it) } ?: return emptySet()
    val owner = alliances.any { it.owner == mid && it.level >= ALLY_MAX_LEVEL }
    return if (owner) n.badges + "maxed_unity" else n.badges
}

// ----------------------------------------------------------------- ثبت گزارش
fun Player.pushReports(list: List<Report>): Player {
    if (list.isEmpty()) return this
    var id = nextReportId
    val added = list.sortedBy { it.time }.map { it.copy(id = id++) }
    return copy(reports = (reports + added).sortedBy { it.time }.takeLast(repMax), nextReportId = id)
}

fun Rank.label(): String = tr(fa, name)

fun rankByKey(key: String): Rank = ALL_RANKS.firstOrNull { it.key == key } ?: RANKS[0]

// ----------------------------------------------------------------- ساخت گزارش‌ها
fun mkLevel(t: Long, mid: String, name: String, lv: Int) =
    Report(kind = "level", time = t, mine = mid == ME, names = listOf(name), mids = listOf(mid), a = lv)

fun mkRank(t: Long, mid: String, name: String, rankKey: String) =
    Report(kind = "rank", time = t, mine = mid == ME, names = listOf(name), mids = listOf(mid), text = rankKey)

/** گزارش دوئل؛ برنده اول. */
fun Player.mkDuel(t: Long, winner: String, loser: String, wDice: Int, lDice: Int) = Report(
    kind = "duel", time = t, mine = ME == winner || ME == loser,
    names = listOf(nameOf(winner), nameOf(loser)), mids = listOf(winner, loser), a = wDice, b = lDice,
    res = when (ME) { winner -> 1; loser -> 0; else -> -1 },
)

/** گزارش لابی؛ mvp اول، winnerTeam برابر «tie» یعنی مساوی. */
fun Player.mkLobby(t: Long, size: Int, winnerTeam: String, a: Int, b: Int, mvp: String, all: List<String>, myRes: Int) = Report(
    kind = "lobby", time = t, mine = ME in all, names = listOf(nameOf(mvp)),
    mids = (listOf(mvp) + all).distinct(), a = a, b = b, n = size, res = if (ME in all) myRes else -1, text = winnerTeam,
)

fun mkBattle(t: Long, nameA: String, nameB: String, a: Int, b: Int, mids: List<String>, myRes: Int) = Report(
    kind = "battle", time = t, mine = myRes != -1, names = listOf(nameA, nameB), mids = mids, a = a, b = b, res = myRes,
)

/** تغییر لول/رنک یک NPC → گزارش (لول فقط مضرب ۵ تا گزارش‌ها شلوغ نشوند). */
internal fun npcEvents(old: Npc, new: Npc, t: Long): List<Report> {
    val out = ArrayList<Report>(2)
    val l0 = levelFromXp(old.xp)
    val l1 = levelFromXp(new.xp)
    if (l1 > l0 && l1 % 5 == 0) out.add(mkLevel(t, npcMid(new.id), new.name, l1))
    val r0 = rankFor(old.points)
    val r1 = rankFor(new.points)
    if (r1.min > r0.min) out.add(mkRank(t, npcMid(new.id), new.name, r1.key))
    return out
}

/** گزارش‌ها را داخل برنامه ثبت می‌کند. */
internal fun Game.emit(pl: Player, list: List<Report>): Player =
    if (list.isEmpty()) pl else pl.pushReports(list)

// ----------------------------------------------------------------- متن گزارش داخل برنامه
private fun resMark(r: Report) = when (r.res) { 1 -> "✅ "; 0 -> "❌ "; 2 -> "⚖️ "; else -> "" }

fun Report.line(): String {
    val n0 = names.getOrNull(0) ?: "?"
    val n1 = names.getOrNull(1) ?: "?"
    return when (kind) {
        "duel" -> resMark(this) + tr("🎲 $n0 ($a) از $n1 ($b) برد", "🎲 $n0 ($a) beat $n1 ($b)")
        "lobby" ->
            if (text == "tie") resMark(this) + tr("👥 لابی $n نفره مساوی شد ($a–$b) · MVP: $n0", "👥 $n-player lobby tied ($a–$b) · MVP: $n0")
            else resMark(this) + tr("👥 لابی $n نفره: $text برد ($a–$b) · MVP: $n0", "👥 $n-player lobby: $text won ($a–$b) · MVP: $n0")
        "battle" -> resMark(this) + tr("⚔️ نبرد اتحاد: $n0 $a–$b $n1", "⚔️ Alliance war: $n0 $a–$b $n1")
        "level" -> tr("⬆️ $n0 به لول $a رسید", "⬆️ $n0 reached level $a")
        "rank" -> rankByKey(text).let { tr("${it.emoji} $n0 به رنک ${it.fa} رسید", "${it.emoji} $n0 reached ${it.name}") }
        "season" -> tr("🏁 فصل $a تموم شد: 🥇 $n0  🥈 $n1  🥉 ${names.getOrNull(2) ?: "?"}",
            "🏁 Season $a ended: 🥇 $n0  🥈 $n1  🥉 ${names.getOrNull(2) ?: "?"}")
        else -> text
    }
}

fun Report.icon(): String = when (kind) {
    "duel" -> "🎲"; "lobby" -> "👥"; "battle" -> "⚔️"; "level" -> "⬆️"; "rank" -> "🏅"; "season" -> "🏁"; else -> "•"
}
