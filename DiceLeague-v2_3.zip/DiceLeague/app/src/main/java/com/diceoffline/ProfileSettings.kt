package com.diceoffline

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceoffline.game.*

@Composable
fun ScreenBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Text(if (L.lang == "fa") "→" else "←", fontSize = 22.sp) }
        Txt(title, size = 18, bold = true)
    }
}

private fun honorText(s: String): String {
    val x = s.split(":")
    val season = x.getOrNull(0)?.removePrefix("S") ?: "?"
    return when (x.getOrNull(1)) {
        "league" -> tr("🏆 فصل $season: رتبه‌ی ${x.getOrNull(2)} لیگ", "🏆 Season $season: league #${x.getOrNull(2)}")
        "level" -> tr("📈 فصل $season: رتبه‌ی ${x.getOrNull(2)} لول", "📈 Season $season: level #${x.getOrNull(2)}")
        "prince" -> tr("🎲 فصل $season: پرنس تاس", "🎲 Season $season: Prince of Dice")
        "ally" -> tr("🛡 فصل $season: اتحاد رتبه‌ی ${x.getOrNull(2)}", "🛡 Season $season: alliance #${x.getOrNull(2)}")
        else -> s
    }
}

@Composable
fun ProfileScreen(game: Game, onBack: () -> Unit, onRanks: () -> Unit = {}) {
    val p = game.p
    val (lv, cur, need) = levelProgress(p.xp)
    val rk = p.rankOf(ME)
    val nr = if (rk.key == "conqueror") null else nextRank(p.points)
    var editName by remember { mutableStateOf(false) }
    var nameText by remember { mutableStateOf(p.name) }
    var pickAvatar by remember { mutableStateOf(false) }
    val total = p.wins + p.losses

    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("پروفایل", "Profile"), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GradientHeader {
                Box(Modifier.clickable { pickAvatar = true }, contentAlignment = Alignment.BottomEnd) {
                    ProfilePic(p.avatar, 112.dp, animated = true)
                    Text("✏️", fontSize = 16.sp)
                }
                Txt(tr("برای عوض کردن پروفایل روی تصویر بزن", "Tap the picture to change your profile"), size = 11, color = MaterialTheme.colorScheme.muted)
                Spacer(Modifier.height(6.dp))
                LevelRing(lv, cur, need, 96.dp)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { nameText = p.name; editName = true }) {
                    Text(p.name, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("✏️", fontSize = 14.sp)
                }
                Row(
                    Modifier.clickable { onRanks() },
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    RankEmblem(rk, 56.dp)
                    Column {
                        Txt(tr(rk.fa, rk.name), size = 18, bold = true, color = Color(rk.color))
                        Txt("${rk.emoji} ${rk.name}", size = 11, color = MaterialTheme.colorScheme.muted)
                    }
                }
                if (nr != null) Txt(
                    tr("${fmt(nr.second)} امتیاز تا ${nr.first.fa}", "${fmt(nr.second)} points to ${nr.first.name}"),
                    size = 11, color = MaterialTheme.colorScheme.muted,
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox(fmt(p.coins), "🪙 " + tr("سکه", "Coins"), Modifier.weight(1f))
                StatBox(fmt(p.points), "⭐ " + tr("امتیاز", "Points"), Modifier.weight(1f))
                StatBox("${p.honors}", "🏅 " + tr("افتخار", "Honors"), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${p.wins}", tr("برد", "Wins"), Modifier.weight(1f))
                StatBox("${p.losses}", tr("باخت", "Losses"), Modifier.weight(1f))
                StatBox(if (total == 0) "—" else "${p.wins * 100 / total}%", tr("درصد برد", "Win rate"), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${p.seasonWins}", tr("برد این فصل", "Season wins"), Modifier.weight(1f))
                StatBox("${p.openStreak}", "🔥 " + tr("روز پیاپی", "Day streak"), Modifier.weight(1f))
                StatBox("S${p.seasonNo}", tr("فصل", "Season"), Modifier.weight(1f))
            }

            p.myAlly()?.let { a ->
                AppCard {
                    CardTitle(tr("🛡 اتحاد", "🛡 Alliance"))
                    Text(a.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Txt("Lv ${a.level}  ·  👥 ${a.members.size}  ·  ⭐ ${fmt(p.allyPoints(a))}", size = 12, color = MaterialTheme.colorScheme.muted)
                }
            }

            AppCard {
                CardTitle(tr("🎖 نشان‌ها", "🎖 Badges"))
                if (p.badges.isEmpty()) Txt(tr("هنوز نشانی نداری.", "No badges yet."), color = MaterialTheme.colorScheme.muted)
                BADGES.forEach { (k, b) ->
                    val has = k in p.badges
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (has) b.emoji else "🔒", fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(b.name, fontWeight = FontWeight.Bold, color = if (has) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.muted)
                            Txt(tr(b.fa, b.en), size = 11, color = MaterialTheme.colorScheme.muted)
                        }
                    }
                }
            }

            TrophyShelf(p.trophies, mine = true)

            RecentGamesCard(p, ME)
            OBtn(tr("🏅 راهنمای رنک‌ها", "🏅 Rank guide"), Modifier.fillMaxWidth()) { onRanks() }

            if (p.honorLog.isNotEmpty()) AppCard {
                CardTitle(tr("🏅 تاریخچه‌ی افتخارات", "🏅 Honor history"))
                p.honorLog.reversed().take(20).forEach { Txt(honorText(it), size = 13) }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (pickAvatar) AvatarPickerDialog(game) { pickAvatar = false }

    if (editName) AlertDialog(
        onDismissRequest = { editName = false },
        title = { Txt(tr("اسم نمایشی", "Display name"), bold = true) },
        text = { TextF(tr("اسم", "Name"), nameText, { nameText = it.take(20) }, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton({ game.setName(nameText); editName = false }) { Txt(tr("ذخیره", "Save"), bold = true) } },
        dismissButton = { TextButton({ editName = false }) { Txt(tr("انصراف", "Cancel")) } },
    )
}

@Composable
fun SettingsScreen(game: Game, onBack: () -> Unit, onAdmin: () -> Unit, onReports: () -> Unit = {}, onRanks: () -> Unit = {}) {
    val p = game.p
    var code by remember { mutableStateOf("") }
    var help by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var pasted by remember { mutableStateOf("") }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(game.exportAccount().toByteArray()) } != null
            } catch (e: Exception) { false }
            if (ok) game.toast("حساب ذخیره شد ✅ فایل را جای امنی نگه دار.", "Account saved ✅ Keep the file somewhere safe.")
            else game.toast("ذخیره نشد.", "Could not save.")
        }
    }
    val loader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = try { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } } catch (e: Exception) { null }
            if (txt == null) game.toast("فایل خوانده نشد.", "Could not read the file.") else game.importAccount(txt)
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("تنظیمات", "Settings"), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AppCard {
                CardTitle(tr("📋 گزارش‌ها و رنک‌ها", "📋 Reports & ranks"))
                OBtn(tr("📋 گزارش آخرین بازی‌ها", "📋 Latest game reports"), Modifier.fillMaxWidth()) { onReports() }
                OBtn(tr("🏅 راهنمای رنک‌ها", "🏅 Rank guide"), Modifier.fillMaxWidth()) { onRanks() }
            }
            AppCard {
                CardTitle(tr("💾 ذخیره و بازیابی حساب", "💾 Save & restore account"),
                    tr("قبل از حذف برنامه حسابت را ذخیره کن؛ بعد از نصب دوباره با همین فایل برمی‌گردد", "Save before uninstalling; restore after reinstalling"))
                PBtn(tr("💾 ذخیره‌ی حساب در فایل", "💾 Save account to a file"), Modifier.fillMaxWidth()) { saver.launch("DiceLeague-account.json") }
                OBtn(tr("📂 بازیابی از فایل", "📂 Restore from a file"), Modifier.fillMaxWidth()) { loader.launch(arrayOf("*/*")) }
                OBtn(tr("📋 کپی کد حساب", "📋 Copy account code"), Modifier.fillMaxWidth()) {
                    clip.setText(AnnotatedString(game.exportAccount()))
                    game.toast("کد حساب کپی شد؛ جایی امن ذخیره‌اش کن.", "Account code copied; store it somewhere safe.")
                }
                TextF(tr("چسباندن کد حساب", "Paste account code"), pasted, { pasted = it }, Modifier.fillMaxWidth(), single = false)
                OBtn(tr("♻️ بازیابی از کد", "♻️ Restore from code"), Modifier.fillMaxWidth()) { if (game.importAccount(pasted)) pasted = "" }
            }
            AppCard {
                CardTitle(tr("🌐 زبان", "🌐 Language"))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = p.lang == "fa", onClick = { game.adminEdit { it.copy(lang = "fa") } }, label = { Text("فارسی") })
                    FilterChip(selected = p.lang == "en", onClick = { game.adminEdit { it.copy(lang = "en") } }, label = { Text("English") })
                }
            }
            AppCard {
                CardTitle(tr("🎨 نمایش", "🎨 Appearance"))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to tr("🌗 سیستم", "🌗 System"), 1 to tr("☀️ روشن", "☀️ Light"), 2 to tr("🌙 تیره", "🌙 Dark")).forEach { (v, t) ->
                        FilterChip(selected = p.theme == v, onClick = { game.adminEdit { it.copy(theme = v) } }, label = { Txt(t) })
                    }
                }
                SwitchRow(tr("روشن ماندن صفحه", "Keep screen on"), p.keepScreen) { v -> game.adminEdit { it.copy(keepScreen = v) } }
            }
            AppCard {
                CardTitle(tr("❓ راهنما", "❓ Help"))
                OBtn(if (help) tr("بستن راهنما", "Hide help") else tr("نمایش راهنما", "Show help"), Modifier.fillMaxWidth()) {
                    help = !help
                    if (help) game.markHelpSeen()
                }
                if (help) Txt(
                    tr(
                        "• دوئل: با حریف تاس بنداز؛ عدد بزرگ‌تر برنده است.\n• لابی: دو تیم Demon و Angel؛ جمع تاس‌ها تعیین‌کننده است و MVP جایزه می‌گیرد.\n• اتحاد: بساز یا عضو شو؛ شرایط ورود (لول و امتیاز) دست رهبر و معاون‌هاست. با دونیت بانک اتحاد را پر کن و ارتقا بده.\n• نبرد اتحاد: با یک اتحاد دیگر مسابقه بده.\n• لیگ: هر فصل ${p.seasonDays} روز است؛ ۳ نفر برتر جایزه و افتخار می‌گیرند.\n• بانک از لول $BANK_MIN_LEVEL و کازینو از لول $CASINO_MIN_LEVEL باز می‌شود.\n• بازیکن‌های دیگر شبیه‌سازی شده‌اند و برنامه کاملاً آفلاین است.",
                        "• Duel: roll against an opponent; the higher number wins.\n• Lobby: Demon vs Angel; team totals decide and the MVP gets a bonus.\n• Alliance: create or join; leaders and deputies set entry requirements (level and points). Donate to the bank and upgrade.\n• Alliance war: fight another alliance.\n• League: seasons last ${p.seasonDays} days; the top 3 get rewards and honors.\n• Bank unlocks at level $BANK_MIN_LEVEL, casino at level $CASINO_MIN_LEVEL.\n• Other players are simulated and the app is fully offline.",
                    ), size = 13,
                )
            }
            AppCard {
                CardTitle(tr("🛡 پنل ادمین", "🛡 Admin panel"))
                if (p.admin) {
                    PBtn(tr("باز کردن پنل ادمین", "Open admin panel"), Modifier.fillMaxWidth()) { onAdmin() }
                } else {
                    TextF(tr("کد ادمین", "Admin code"), code, { code = it }, Modifier.fillMaxWidth())
                    PBtn(tr("فعال‌سازی", "Activate"), Modifier.fillMaxWidth()) {
                        if (game.adminLogin(code.trim())) { code = ""; onAdmin() }
                    }
                }
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Txt("Dice League  ·  v2.3  ·  ${tr("آفلاین", "Offline")}", size = 11, color = MaterialTheme.colorScheme.muted)
            }
        }
    }
}
