package com.diceoffline.game

import kotlin.random.Random

private fun Player.activeMember(mid: String): Boolean =
    mid == ME || (midToNpcId(mid)?.let { npc(it) }?.let { isActiveNpc(it) } ?: false)

// ----------------------------------------------------------------- لیست لابی‌ها (لابی‌های لیستی Fake Play)
fun Game.refreshLobbies() {
    val pl = p
    val t = now()
    if (!pl.llOn || !pl.fpEnabled) {
        if (lobbies.isNotEmpty()) lobbies = emptyList()
        return
    }
    val hosts = pl.npcs.filter { pl.isActiveNpc(it) }
    if (hosts.isEmpty()) return
    val list = lobbies.filter { it.endsAt > t }.toMutableList()
    val need = when {
        list.size < FP_LL_MIN -> Random.nextInt(FP_LL_MIN, FP_LL_MAX + 1) - list.size
        list.size < FP_LL_MAX && Random.nextDouble() < 0.2 -> 1
        else -> 0
    }
    repeat(need) {
        val size = LOBBY_SIZES.random()
        val life = (pl.llTimer * 60_000L * (0.6 + Random.nextDouble() * 0.8)).toLong()
        list.add(LobbyCard(lobbySeq++, hosts.random().name, size, Random.nextInt(1, size), t + life))
    }
    lobbies = list
}

fun Game.dropLobby(id: Int) {
    lobbies = lobbies.filter { it.id != id }
}

// ----------------------------------------------------------------- لابی
fun Game.rollLobby(size: Int): TeamRoll? {
    val pl = p
    val pool = pl.npcs.filter { pl.isActiveNpc(it) }.shuffled()
    if (pool.size < size - 1) {
        toast("NPC کافی برای این لابی نیست.", "Not enough NPCs for this lobby.")
        return null
    }
    val ids = (listOf(ME) + pool.take(size - 1).map { npcMid(it.id) }).shuffled()
    val rollers = ids.map { Roller(it, pl.nameOf(it), Random.nextInt(1, 7)) }
    return TeamRoll("lobby", rollers.take(size / 2), rollers.drop(size / 2), "Demon", "Angel")
}

fun Game.finishLobby(res: TeamRoll) {
    val notes = mutableListOf<String>()
    var pl = p
    val sa = res.sumA
    val sb = res.sumB
    val mvpA = res.mvpA?.mid
    val mvpB = res.mvpB?.mid
    var myWon: Boolean? = null
    val dummy = mutableListOf<String>()

    if (sa == sb) {
        for (m in listOfNotNull(mvpA, mvpB)) {
            pl = applyMember(pl, m, 10, XP_TIE_MVP, 10, null, if (m == ME) notes else dummy)
            if (m == ME) notes.add(tr("⚖️ مساوی شد؛ به‌عنوان MVP +10 امتیاز و +10 سکه گرفتی.", "⚖️ Tie — as MVP you got +10 points and +10 coins."))
        }
    } else {
        val aWin = sa > sb
        val win = if (aWin) res.teamA else res.teamB
        val lose = if (aWin) res.teamB else res.teamA
        val mvpW = if (aWin) mvpA else mvpB
        win.forEach { r ->
            val m = r.mid == mvpW
            val pts = 20 + if (m) 20 else 0
            val coins = COIN_WIN + if (m) COIN_MVP else 0
            pl = applyMember(pl, r.mid, coins, XP_WIN + if (m) XP_MVP else 0, pts, true, if (r.mid == ME) notes else dummy)
            if (r.mid == ME) {
                myWon = true
                notes.add(tr("🏆 بردی! +$pts امتیاز و +$coins سکه" + if (m) " (MVP)" else "", "🏆 You won! +$pts points and +$coins coins" + if (m) " (MVP)" else ""))
            }
        }
        lose.forEach { r ->
            pl = applyMember(pl, r.mid, COIN_LOSS, XP_LOSS, -15, false, if (r.mid == ME) notes else dummy)
            if (r.mid == ME) {
                myWon = false
                notes.add(tr("❌ باختی. -15 امتیاز و $COIN_LOSS سکه", "❌ You lost. -15 points and $COIN_LOSS coins"))
            }
        }
    }
    run {
        val all = (res.teamA + res.teamB).map { it.mid }
        val tie = sa == sb
        val mvpMid = (if (sa >= sb) mvpA else mvpB) ?: all.firstOrNull()
        if (mvpMid != null) {
            val winnerName = if (tie) "tie" else if (sa > sb) res.nameA else res.nameB
            val myRes = when {
                ME !in all -> -1
                tie -> 2
                myWon == true -> 1
                else -> 0
            }
            pl = emit(pl, listOf(pl.mkLobby(now(), all.size, winnerName, maxOf(sa, sb), minOf(sa, sb), mvpMid, all, myRes)))
        }
    }
    pl = missionTrack(pl, "play", notes)
    pl = missionTrack(pl, "group_game", notes)
    pl = starterTrack(pl, "first_game", notes)
    if (myWon == true) {
        pl = missionTrack(pl, "win", notes)
        pl = starterTrack(pl, "first_win", notes)
        pl = princeCheck(pl, notes)
    }
    commit(pl)
    say(notes)
}

// ----------------------------------------------------------------- نبرد اتحاد
fun Game.rollBattle(): TeamRoll? {
    val pl = p
    val mine = pl.myAlly() ?: run {
        toast("اول عضو یه اتحاد شو.", "Join an alliance first.")
        return null
    }
    val myPool = mine.members.filter { pl.activeMember(it) }
    val enemies = pl.alliances.filter { e -> e.id != mine.id && e.members.any { it != ME && pl.activeMember(it) } }
    if (enemies.isEmpty()) {
        toast("حریفی برای نبرد پیدا نشد.", "No opposing alliance found.")
        return null
    }
    val enemy = enemies.random()
    val enemyPool = enemy.members.filter { pl.activeMember(it) }.shuffled()
    val n = minOf(ALLY_BATTLE_TEAM, myPool.size, enemyPool.size)
    val mineTeam = (listOf(ME) + myPool.filter { it != ME }.shuffled()).take(n)
    val enemyTeam = enemyPool.take(n)
    fun roll(ids: List<String>) = ids.map { Roller(it, pl.nameOf(it), Random.nextInt(1, 7)) }
    return TeamRoll("battle", roll(mineTeam), roll(enemyTeam), mine.name, enemy.name, mine.id, enemy.id)
}

fun Game.finishBattle(res: TeamRoll) {
    val notes = mutableListOf<String>()
    var pl = p
    val dummy = mutableListOf<String>()
    val sa = res.sumA
    val sb = res.sumB
    var myWon: Boolean? = null

    if (sa == sb) {
        notes.add(tr("⚖️ نبرد مساوی شد؛ نتیجه‌ای ثبت نشد.", "⚖️ The battle was a tie — nothing recorded."))
    } else {
        val aWin = sa > sb
        val win = if (aWin) res.teamA else res.teamB
        val lose = if (aWin) res.teamB else res.teamA
        val winId = if (aWin) res.allyA else res.allyB
        val loseId = if (aWin) res.allyB else res.allyA
        pl = pl.withAlly(winId) { it.copy(bank = it.bank + ALLY_BATTLE_REWARD, won = it.won + 1) }
        pl = pl.withAlly(loseId) { it.copy(lost = it.lost + 1) }
        win.forEach { r ->
            pl = applyMember(pl, r.mid, COIN_WIN, XP_WIN, 20, true, if (r.mid == ME) notes else dummy)
            if (r.mid == ME) {
                myWon = true
                notes.add(tr("🏆 اتحادت برد! +20 امتیاز و +$COIN_WIN سکه، +$ALLY_BATTLE_REWARD به بانک اتحاد",
                    "🏆 Your alliance won! +20 points, +$COIN_WIN coins, +$ALLY_BATTLE_REWARD to the alliance bank"))
            }
        }
        lose.forEach { r ->
            pl = applyMember(pl, r.mid, COIN_LOSS, XP_LOSS, -15, false, if (r.mid == ME) notes else dummy)
            if (r.mid == ME) {
                myWon = false
                notes.add(tr("❌ اتحادت باخت. -15 امتیاز و $COIN_LOSS سکه", "❌ Your alliance lost. -15 points and $COIN_LOSS coins"))
            }
        }
        val mw = (if (aWin) res.mvpA else res.mvpB)?.mid
        pl = emit(
            pl,
            listOf(mkBattle(now(), res.nameA, res.nameB, sa, sb, listOfNotNull(mw) + (res.teamA + res.teamB).map { it.mid }, if (aWin) 1 else 0)),
        )
    }
    pl = missionTrack(pl, "play", notes)
    pl = starterTrack(pl, "first_game", notes)
    if (myWon == true) {
        pl = missionTrack(pl, "win", notes)
        pl = starterTrack(pl, "first_win", notes)
    }
    commit(pl)
    say(notes)
}
