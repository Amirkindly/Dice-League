package com.diceoffline

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.diceoffline.game.*

private val GAME_KINDS = setOf("duel", "lobby", "battle")
private val EVENT_KINDS = setOf("level", "rank", "season")

/** منوی گزارش‌ها: آخرین بازی‌های بازیکن‌ها (NPC)، بازی‌های خودم، و رویدادهای لول/رنک/فصل. */
@Composable
fun ReportsScreen(game: Game, onBack: () -> Unit) {
    val p = game.p
    val open = LocalOpenProfile.current
    var tabSel by remember { mutableIntStateOf(0) }
    val tickNow by tickState(30_000)

    // تب‌هایی که ادمین فعال گذاشته: 0 بازی‌های NPC، 1 بازی‌های من، 2 رنک و لول
    val enabled = listOfNotNull(
        if (p.repNpc) 0 else null, if (p.repMine) 1 else null, if (p.repEvents) 2 else null,
    )
    val tab = if (tabSel in enabled) tabSel else (enabled.firstOrNull() ?: -1)

    val list = remember(p.reports, tab) {
        p.reports.filter { r ->
            when (tab) {
                0 -> !r.mine && r.kind in GAME_KINDS
                1 -> r.mine && r.kind in GAME_KINDS
                2 -> r.kind in EVENT_KINDS
                else -> false
            }
        }.takeLast(120).reversed()
    }

    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("📋 گزارش‌ها", "📋 Reports"), onBack)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (p.repNpc) FilterChip(selected = tab == 0, onClick = { tabSel = 0 }, label = { Txt(tr("🤖 بازی‌های NPC", "🤖 NPC games")) })
            if (p.repMine) FilterChip(selected = tab == 1, onClick = { tabSel = 1 }, label = { Txt(tr("👤 بازی‌های من", "👤 My games")) })
            if (p.repEvents) FilterChip(selected = tab == 2, onClick = { tabSel = 2 }, label = { Txt(tr("🏅 رنک و لول", "🏅 Ranks & levels")) })
        }
        LazyColumn(
            Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (tab == -1) item {
                Txt(
                    tr("گزارش‌ها فعلاً توسط ادمین غیرفعال شده‌اند.", "Reports are currently turned off by the admin."),
                    color = MaterialTheme.colorScheme.muted,
                )
            } else if (list.isEmpty()) item {
                Txt(
                    tr("هنوز گزارشی ثبت نشده؛ چند لحظه‌ی دیگر دوباره نگاه کن.", "Nothing recorded yet; check again in a moment."),
                    color = MaterialTheme.colorScheme.muted,
                )
            }
            items(list, key = { it.id }) { r ->
                val target = r.mids.firstOrNull { it != "" }
                Surface(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .clickable(enabled = target != null) { target?.let { open(it) } },
                    shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Txt(r.line(), size = 13)
                            Txt(ago(tickNow - r.time), size = 10, color = MaterialTheme.colorScheme.muted)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}
