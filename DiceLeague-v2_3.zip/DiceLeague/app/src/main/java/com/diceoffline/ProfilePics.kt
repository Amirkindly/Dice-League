package com.diceoffline

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceoffline.game.*

// ------------------------------------------------------------------ تصویر آماده‌ی فصل‌های Conquer
private val CONQ_RES = intArrayOf(
    R.drawable.conq_s1, R.drawable.conq_s2, R.drawable.conq_s3, R.drawable.conq_s4, R.drawable.conq_s5,
    R.drawable.conq_s6, R.drawable.conq_s7, R.drawable.conq_s8, R.drawable.conq_s9, R.drawable.conq_s10,
    R.drawable.conq_s11, R.drawable.conq_s12, R.drawable.conq_s13, R.drawable.conq_s14, R.drawable.conq_s15,
    R.drawable.conq_s16, R.drawable.conq_s17, R.drawable.conq_s18, R.drawable.conq_s19, R.drawable.conq_s20,
)

/** نشان تصویری Conquer یک فصل؛ برای فصل‌های بعد از ۲۰ یک نشان طراحی‌شده با کد نشان داده می‌شود. */
@Composable
fun ConquerArt(season: Int, width: Dp, modifier: Modifier = Modifier) {
    val h = width * 0.83f
    val shape = RoundedCornerShape(width * 0.08f)
    if (season in 1..CONQ_ART_MAX) {
        Image(
            painterResource(CONQ_RES[season - 1]), "Conquer S$season",
            modifier.size(width, h).clip(shape), contentScale = ContentScale.Crop,
        )
    } else {
        Box(
            modifier.size(width, h).clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF7A0F1B), Color(0xFF1A0408))), shape),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🐉", fontSize = (width.value * 0.3f).sp)
                Text("Conquer", fontWeight = FontWeight.Bold, color = Color(0xFFFFD86B), fontSize = (width.value * 0.13f).sp)
                Text("S$season", fontWeight = FontWeight.Bold, color = Color(0xFFFF6B4D), fontSize = (width.value * 0.12f).sp)
            }
        }
    }
}

// ------------------------------------------------------------------ تصویر پروفایل
/** تصویر پروفایل: یکی از ۱۰ طرح داخلی یا نشان Conquer یک فصل (کلید conq:S). */
@Composable
fun ProfilePic(key: String, sz: Dp, modifier: Modifier = Modifier, locked: Boolean = false, lockLevel: Int = 0, animated: Boolean = false) {
    if (isConqKey(key)) {
        Box(modifier.size(sz), contentAlignment = Alignment.Center) { ConquerArt(conqSeasonOf(key), sz) }
        return
    }
    val a = avatarOf(key)
    val ring = Color(a.ring)
    val fs = with(LocalDensity.current) { (sz * 0.5f).toSp() }
    val spin = if (animated && a.level >= 30) {
        val t = rememberInfiniteTransition(label = "avatarSpin")
        t.animateFloat(
            0f, 360f,
            infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart), label = "spin",
        ).value
    } else 0f

    Box(modifier.size(sz), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            val c = center
            val inner = r * 0.86f
            // هاله
            drawCircle(
                Brush.radialGradient(listOf(ring.copy(alpha = 0.50f), Color.Transparent), center = c, radius = r),
                radius = r, center = c,
            )
            // زمینه
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(a.c1), Color(a.c2)),
                    center = Offset(c.x, c.y - inner * 0.25f), radius = inner * 1.25f,
                ),
                radius = inner, center = c,
            )
            // پرتوها
            for (i in 0 until 12) {
                rotate(i * 30f + spin * 0.3f, c) {
                    drawLine(
                        ring.copy(alpha = 0.09f), Offset(c.x, c.y), Offset(c.x, c.y - inner * 0.98f),
                        strokeWidth = inner * 0.16f,
                    )
                }
            }
            // حلقه‌ی فلزی
            rotate(spin, c) {
                drawCircle(
                    Brush.sweepGradient(
                        listOf(ring, Color.White.copy(alpha = 0.95f), ring, ring.copy(alpha = 0.45f), ring), center = c,
                    ),
                    radius = r * 0.93f, center = c, style = Stroke(r * 0.085f),
                )
            }
            drawCircle(Color.White.copy(alpha = 0.22f), radius = inner * 0.97f, center = c, style = Stroke(r * 0.02f))
        }
        Text(a.emoji, fontSize = fs, textAlign = TextAlign.Center)
        if (locked) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.62f), CircleShape), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔒", fontSize = (sz.value * 0.26f).sp)
                    if (lockLevel > 0) Text("Lv $lockLevel", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (sz.value * 0.17f).sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ انتخاب پروفایل
@Composable
fun AvatarPickerDialog(game: Game, onDismiss: () -> Unit) {
    val p = game.p
    val myLv = levelFromXp(p.xp)
    val conq = p.trophies.seasons("conq")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Txt(tr("🖼 انتخاب پروفایل", "🖼 Choose profile"), bold = true) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Txt(
                    tr("لول فعلی تو: $myLv — پروفایل‌های قفل‌شده با بالا رفتن لول باز می‌شوند.", "Your level: $myLv — locked profiles open as you level up."),
                    size = 12, color = MaterialTheme.colorScheme.muted,
                )
                AVATARS.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { a ->
                            val open = p.avatarUnlocked(a)
                            val sel = p.avatar == a.key
                            Column(
                                Modifier.width(84.dp).clip(RoundedCornerShape(14.dp))
                                    .background(if (sel) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                    .clickable { game.setAvatar(a.key); if (open) onDismiss() }
                                    .padding(vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                ProfilePic(a.key, 64.dp, locked = !open, lockLevel = a.level)
                                Spacer(Modifier.height(4.dp))
                                Txt(tr(a.fa, a.en), size = 11, bold = sel, align = TextAlign.Center, maxLines = 1)
                                Txt(
                                    if (a.level <= 1) tr("رایگان", "Free") else "Lv ${a.level}",
                                    size = 10, color = if (open) MaterialTheme.colorScheme.good else MaterialTheme.colorScheme.muted,
                                )
                            }
                        }
                    }
                }
                if (conq.isNotEmpty()) {
                    Txt(tr("🐉 پروفایل‌های ویژه‌ی Conquer", "🐉 Special Conquer profiles"), bold = true)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        conq.forEach { s ->
                            val key = "conq:$s"
                            Box(
                                Modifier.clip(RoundedCornerShape(10.dp))
                                    .background(if (p.avatar == key) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .padding(3.dp)
                                    .clickable { game.setAvatar(key); onDismiss() },
                            ) { ConquerArt(s, 96.dp) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Txt(tr("بستن", "Close"), bold = true) } },
    )
}

// ------------------------------------------------------------------ قفسه‌ی افتخارات فصلی
/** افتخارات فصلی با همان قالب ربات: Conquer، King of level، Prince of Dice، Ranking 1st/2nd/3rd. */
@Composable
fun TrophyShelf(trophies: List<String>, mine: Boolean) {
    val conq = trophies.seasons("conq")
    val king = trophies.seasons("king")
    val prince = trophies.seasons("prince")
    val ranks = trophies.rankHonors()
    AppCard {
        CardTitle(tr("🏆 افتخارات فصلی", "🏆 Season honors"))
        if (conq.isEmpty() && king.isEmpty() && prince.isEmpty() && ranks.isEmpty()) {
            Txt(
                if (mine) tr("هنوز افتخار فصلی نداری؛ در پایان فصل‌ها با رتبه‌ی خوب این‌جا پر می‌شود.", "No season honors yet; finish seasons high to fill this shelf.")
                else tr("هنوز افتخار فصلی ندارد.", "No season honors yet."),
                color = MaterialTheme.colorScheme.muted, size = 13,
            )
            return@AppCard
        }
        if (conq.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                conq.forEach { ConquerArt(it, 120.dp) }
            }
            Txt(conquerLabel(conq), size = 13, bold = true)
        }
        if (king.isNotEmpty()) Txt(kingLabel(king), size = 13, bold = true)
        if (prince.isNotEmpty()) Txt(princeLabel(prince), size = 13, bold = true)
        ranks.forEach { (s, pos) -> Txt(rankHonorLabel(s, pos), size = 13) }
    }
}
