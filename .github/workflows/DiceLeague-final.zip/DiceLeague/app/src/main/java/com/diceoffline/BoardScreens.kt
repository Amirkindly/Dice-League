package com.diceoffline

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.diceoffline.game.*

private fun medal(r: Int) = when (r) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "$r" }

@Composable
private fun EntryRow(e: BoardEntry, mode: Int) {
    val me = e.me
    Surface(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        color = if (me) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (me) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Txt(medal(e.rank), Modifier.width(38.dp), size = if (e.rank <= 3) 20 else 14, bold = true, maxLines = 1)
            Avatar(e.name, 34.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(e.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val rk = rankFor(e.points)
                Txt(
                    when (mode) {
                        0 -> "${rk.emoji} ${rk.name}  ·  ${fmt(e.xp)} XP"
                        1 -> "Lv ${e.level}  ·  ${rk.emoji} ${rk.name}"
                        else -> "Lv ${e.level}  ·  🏅 ${e.honors}"
                    }, size = 11, color = MaterialTheme.colorScheme.muted, maxLines = 1,
                )
            }
            Txt(
                when (mode) { 0 -> "Lv ${e.level}"; 1 -> "🏅 ${e.honors}"; else -> "⭐ ${fmt(e.points)}" },
                bold = true, color = MaterialTheme.colorScheme.primary, maxLines = 1,
            )
        }
    }
}

/** mode: 0 رتبه‌بندی لول، 1 رتبه‌بندی کلی (افتخارات)، 2 لیگ */
@Composable
fun BoardList(entries: List<BoardEntry>, mode: Int, header: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = header) }
        items(entries, key = { it.rank }) { EntryRow(it, mode) }
    }
}

@Composable
private fun MyRankCard(entries: List<BoardEntry>, title: String, sub: String) {
    val me = entries.firstOrNull { it.me }
    GradientHeader {
        Txt(title, size = 18, bold = true)
        Txt(sub, size = 12, color = MaterialTheme.colorScheme.muted, align = androidx.compose.ui.text.style.TextAlign.Center)
        if (me != null) Txt(tr("رتبه‌ی تو: ${me.rank} از ${entries.size}", "Your rank: ${me.rank} of ${entries.size}"), size = 20, bold = true, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun BoardScreen(game: Game, mode: Int) {
    val p = game.p
    val entries = remember(p, mode) { if (mode == 0) game.levelBoard() else game.honorBoard() }
    BoardList(entries, mode) {
        if (mode == 0) MyRankCard(
            entries, tr("📈 رتبه‌بندی لول", "📈 Level ranking"),
            tr("پاداش پایان فصل: ${fmt(LEVEL_SEASON_REWARDS[1] ?: 0)} / ${fmt(LEVEL_SEASON_REWARDS[2] ?: 0)} / ${fmt(LEVEL_SEASON_REWARDS[3] ?: 0)} 🪙  +  افتخار",
                "Season rewards: ${fmt(LEVEL_SEASON_REWARDS[1] ?: 0)} / ${fmt(LEVEL_SEASON_REWARDS[2] ?: 0)} / ${fmt(LEVEL_SEASON_REWARDS[3] ?: 0)} 🪙 + honors"),
        ) else MyRankCard(
            entries, tr("🏅 رتبه‌بندی کلی", "🏅 Overall ranking"),
            tr("بر اساس مجموع افتخارات: لیگ، لول، پرنس تاس و اتحاد برتر", "By total honors: league, level, Prince of Dice, top alliance"),
        )
    }
}

@Composable
fun LeagueScreen(game: Game) {
    val p = game.p
    val now by tickState()
    var sub by remember { mutableIntStateOf(0) }
    val players = remember(p) { game.leagueBoard() }
    val allies = remember(p) { game.allianceBoard() }
    if (sub == 0) {
        BoardList(players, 2) { LeagueHeader(game, players, sub, now) { sub = it } }
    } else {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { LeagueHeader(game, players, sub, now) { sub = it } } }
            items(allies.size) { i ->
                val a = allies[i]
                val mine = ME in a.members
                Surface(
                    Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
                    color = if (mine) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Txt(medal(i + 1), Modifier.width(38.dp), size = if (i < 3) 20 else 14, bold = true)
                        Avatar(a.name, 34.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Txt("Lv ${a.level}  ·  👥 ${a.members.size}  ·  ${a.won}W ${a.lost}L", size = 11, color = MaterialTheme.colorScheme.muted)
                        }
                        Txt("⭐ ${fmt(p.allyPoints(a))}", bold = true, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun LeagueHeader(game: Game, players: List<BoardEntry>, sub: Int, now: Long, onSub: (Int) -> Unit) {
    val p = game.p
    val me = players.firstOrNull { it.me }
    GradientHeader {
        Txt(tr("🏆 لیگ فصل ${p.seasonNo}", "🏆 League — Season ${p.seasonNo}"), size = 18, bold = true)
        Txt(tr("⏳ ${dur(game.seasonTimeLeftMs())} تا پایان فصل", "⏳ ${dur(game.seasonTimeLeftMs())} until the season ends"), size = 12, color = MaterialTheme.colorScheme.muted)
        if (me != null) Txt(tr("رتبه‌ی تو: ${me.rank}  ·  ⭐ ${fmt(me.points)}", "Your rank: ${me.rank}  ·  ⭐ ${fmt(me.points)}"), size = 18, bold = true, color = MaterialTheme.colorScheme.primary)
        Txt(
            tr("جایزه‌ی ۳ نفر اول: ${fmt(SEASON_USER_REWARDS[1] ?: 0)} / ${fmt(SEASON_USER_REWARDS[2] ?: 0)} / ${fmt(SEASON_USER_REWARDS[3] ?: 0)} 🪙",
                "Top 3 rewards: ${fmt(SEASON_USER_REWARDS[1] ?: 0)} / ${fmt(SEASON_USER_REWARDS[2] ?: 0)} / ${fmt(SEASON_USER_REWARDS[3] ?: 0)} 🪙"),
            size = 11, color = MaterialTheme.colorScheme.muted,
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = sub == 0, onClick = { onSub(0) }, label = { Txt(tr("👤 بازیکن‌ها", "👤 Players")) })
        FilterChip(selected = sub == 1, onClick = { onSub(1) }, label = { Txt(tr("🛡 اتحادها", "🛡 Alliances")) })
    }
}
