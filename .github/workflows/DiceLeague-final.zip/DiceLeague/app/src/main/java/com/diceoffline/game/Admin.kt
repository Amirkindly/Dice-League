package com.diceoffline.game

import org.json.JSONObject
import kotlin.math.max

/** ویرایش مستقیم هر فیلدی (برای تنظیمات Fake Play و غیره). */
fun Game.adminEdit(f: (Player) -> Player) = commit(f(p))

// ---------------------------------------------------------------- خودم
fun Game.adminGive(coins: Int, xp: Int, points: Int) {
    val notes = mutableListOf<String>()
    commit(grant(p, coins, xp, points, notes))
    toast("انجام شد ✅", "Done ✅")
    say(notes)
}

fun Game.adminSetLevel(level: Int) {
    commit(p.copy(xp = xpForLevel(level.coerceIn(1, MAX_LEVEL))))
}

fun Game.adminSetPoints(points: Int) = commit(p.copy(points = max(0, points)))

fun Game.adminToggleBadge(key: String) {
    commit(p.copy(badges = if (key in p.badges) p.badges - key else p.badges + key))
}

fun Game.adminSetHonors(v: Int) = commit(p.copy(honors = max(0, v)))

// ---------------------------------------------------------------- NPCها
fun Game.adminNpc(id: Int, f: (Npc) -> Npc) = commit(p.withNpc(id, f))

fun Game.adminNpcPoints(id: Int, delta: Int) =
    adminNpc(id) { it.copy(points = max(0, it.points + delta)) }

fun Game.adminNpcLevel(id: Int, delta: Int) =
    adminNpc(id) { it.copy(xp = xpForLevel((levelFromXp(it.xp) + delta).coerceIn(1, MAX_LEVEL))) }

fun Game.adminNpcDelete(id: Int) {
    val pl = removeMember(p, npcMid(id))
    commit(pl.copy(npcs = pl.npcs.filter { it.id != id }, npcCount = max(FP_MIN_COUNT, pl.npcCount.coerceAtMost(pl.npcs.size - 1))))
    toast("NPC حذف شد.", "NPC deleted.")
}

fun Game.adminNpcAdd(name0: String) {
    val name = name0.trim().take(24)
    if (name.isEmpty()) return
    if (p.npcs.any { it.name.equals(name, true) } || name.equals(p.name, true)) { toast("این اسم قبلاً هست.", "That name already exists."); return }
    commit(p.copy(
        npcs = p.npcs + Npc(p.nextNpcId, name, 0, 0, 1000),
        nextNpcId = p.nextNpcId + 1, npcCount = max(p.npcCount, p.npcs.size + 1),
    ))
}

fun Game.adminSetNpcCount(n: Int) {
    val target = n.coerceIn(FP_MIN_COUNT, FP_MAX_COUNT)
    var pl = p.copy(npcCount = target)
    pl = if (pl.npcs.size < target) growNpcs(pl, target - pl.npcs.size) else shrinkNpcs(pl, target)
    commit(pl)
}

fun Game.adminRegenNpcs() {
    var pl = p.copy(npcs = emptyList(), alliances = emptyList())
    pl = ensureWorld(pl)
    commit(pl)
    toast("NPCها از نو ساخته شدن.", "NPCs regenerated.")
}

fun Game.adminSimulate(minutes: Double) {
    commit(simulate(p, minutes, now()))
    toast("شبیه‌سازی انجام شد (${minutes.toInt()} دقیقه).", "Simulated ${minutes.toInt()} minutes.")
}

// ---------------------------------------------------------------- اتحادها
fun Game.adminAlly(id: Int, f: (Alliance) -> Alliance) = commit(p.withAlly(id, f))

fun Game.adminAllyDelete(id: Int) = commit(p.copy(alliances = p.alliances.filter { it.id != id }))

fun Game.adminAllyCreate(name0: String) {
    val name = name0.trim().take(20)
    if (name.length < 3 || p.alliances.any { it.name.equals(name, true) }) { toast("اسم نامعتبر یا تکراریه.", "Invalid or duplicate name."); return }
    val free = p.npcs.filter { p.isActiveNpc(it) && p.allyOf(npcMid(it.id)) == null }
    if (free.isEmpty()) { toast("NPC آزاد نیست.", "No free NPC."); return }
    commit(createAlliance(p, npcMid(free.random().id), name))
}

fun Game.adminAllyAddNpc(aid: Int, npcId: Int) {
    val a = p.ally(aid) ?: return
    if (a.members.size >= ALLY_MAX_MEMBERS) { toast("ظرفیت پره.", "Full."); return }
    commit(addMember(p, aid, npcMid(npcId)))
}

fun Game.adminAllyRemove(mid: String) = commit(removeMember(p, mid))

// ---------------------------------------------------------------- کد هدیه
fun Game.adminGiftCreate(code0: String, coins: Int, xp: Int, points: Int, maxUses: Int, days: Int) {
    val code = code0.trim().uppercase().filter { it.isLetterOrDigit() || it == '_' || it == '-' }
    if (code.length < 3) { toast("کد باید حداقل ۳ حرف باشه.", "Code needs at least 3 characters."); return }
    if (p.gifts.any { it.code == code }) { toast("این کد هست.", "Code already exists."); return }
    val exp = if (days > 0) now() + days * 86_400_000L else 0L
    commit(p.copy(gifts = p.gifts + Gift(code, coins, xp, points, max(1, maxUses), 0, exp)))
    toast("کد $code ساخته شد.", "Code $code created.")
}

fun Game.adminGiftDelete(code: String) = commit(p.copy(gifts = p.gifts.filter { it.code != code }))

// ---------------------------------------------------------------- فصل و همگانی
fun Game.adminEndSeasonNow() {
    val notes = mutableListOf<String>()
    commit(endSeason(p, false, notes))
    say(notes)
}

fun Game.adminXpAll(xp: Int) {
    val notes = mutableListOf<String>()
    var pl = grant(p, 0, xp, 0, notes)
    pl = pl.copy(npcs = pl.npcs.map { it.copy(xp = max(0, it.xp + xp)) })
    commit(pl)
    toast("به همه $xp XP داده شد.", "Gave $xp XP to everyone.")
}

// ---------------------------------------------------------------- سیستم
fun Game.adminExport(): String = playerToJson(p).toString()

fun Game.adminImport(raw: String): Boolean = try {
    val pl = playerFromJson(JSONObject(raw.trim()))
    commit(pl.copy(admin = true))
    toast("بکاپ بازیابی شد ✅", "Backup restored ✅")
    true
} catch (e: Exception) {
    toast("متن بکاپ معتبر نیست.", "Invalid backup text.")
    false
}

fun Game.adminResetAll() {
    val fresh = Player(
        lang = p.lang, theme = p.theme, keepScreen = p.keepScreen, admin = true, seasonStart = now(),
    )
    commit(ensureWorld(fresh).copy(lastSimMs = now()))
    toast("همه‌چیز از نو شروع شد.", "Everything was reset.")
}
