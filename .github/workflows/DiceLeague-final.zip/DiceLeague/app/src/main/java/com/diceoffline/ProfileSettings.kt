package com.diceoffline

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceoffline.game.*

@Composable
fun ScreenBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Text(if (L.lang == "fa") "→" else "←", fontSize = 22.sp) }
        Txt(title, size = 18, bold = true)
    }
}

private fun honorText(s: String): String {
    val x = s.split(":")
    val season = x.getOrNull(0)?.removePrefix("S") ?: "?"
    return when (x.getOrNull(1)) {
        "league" -> tr("🏆 فصل $season: رتبه‌ی ${x.getOrNull(2)} لیگ", "🏆 Season $season: league #${x.getOrNull(2)}")
        "level" -> tr("📈 فصل $season: رتبه‌ی ${x.getOrNull(2)} لول", "📈 Season $season: level #${x.getOrNull(2)}")
        "prince" -> tr("🎲 فصل $season: پرنس تاس", "🎲 Season $season: Prince of Dice")
        "ally" -> tr("🛡 فصل $season: اتحاد رتبه‌ی ${x.getOrNull(2)}", "🛡 Season $season: alliance #${x.getOrNull(2)}")
        else -> s
    }
}

@Composable
fun ProfileScreen(game: Game, onBack: () -> Unit) {
    val p = game.p
    val (lv, cur, need) = levelProgress(p.xp)
    val rk = rankFor(p.points)
    val ring = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.outline
    var editName by remember { mutableStateOf(false) }
    var nameText by remember { mutableStateOf(p.name) }
    val total = p.wins + p.losses

    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("پروفایل", "Profile"), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GradientHeader {
                Logo(92.dp)
                Text("Dice League", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 30.sp, color = MaterialTheme.colorScheme.primary)
                Txt(tr("یکی از ۸ میلیارد؛ یه تاس، یه شانس", "One in 8 billion — one die, one chance"), size = 12, color = MaterialTheme.colorScheme.muted)
                Spacer(Modifier.height(6.dp))
                Box(contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(96.dp)) {
                        val sw = 9.dp.toPx()
                        drawArc(track, 0f, 360f, false, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), style = Stroke(sw))
                        val f = if (need > 0) cur.toFloat() / need else 1f
                        drawArc(ring, -90f, 360f * f.coerceIn(0f, 1f), false, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), style = Stroke(sw, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Txt("$lv", size = 28, bold = true)
                        Txt("LEVEL", size = 10, color = MaterialTheme.colorScheme.muted)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { nameText = p.name; editName = true }) {
                    Text(p.name, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("✏️", fontSize = 14.sp)
                }
                Pill("${rk.emoji} ${rk.name}", color = MaterialTheme.colorScheme.secondaryContainer)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox(fmt(p.coins), "🪙 " + tr("سکه", "Coins"), Modifier.weight(1f))
                StatBox(fmt(p.points), "⭐ " + tr("امتیاز", "Points"), Modifier.weight(1f))
                StatBox("${p.honors}", "🏅 " + tr("افتخار", "Honors"), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${p.wins}", tr("برد", "Wins"), Modifier.weight(1f))
                StatBox("${p.losses}", tr("باخت", "Losses"), Modifier.weight(1f))
                StatBox(if (total == 0) "—" else "${p.wins * 100 / total}%", tr("درصد برد", "Win rate"), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${p.seasonWins}", tr("برد این فصل", "Season wins"), Modifier.weight(1f))
                StatBox("${p.openStreak}", "🔥 " + tr("روز پیاپی", "Day streak"), Modifier.weight(1f))
                StatBox("S${p.seasonNo}", tr("فصل", "Season"), Modifier.weight(1f))
            }

            p.myAlly()?.let { a ->
                AppCard {
                    CardTitle(tr("🛡 اتحاد", "🛡 Alliance"))
                    Text(a.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Txt("Lv ${a.level}  ·  👥 ${a.members.size}  ·  ⭐ ${fmt(p.allyPoints(a))}", size = 12, color = MaterialTheme.colorScheme.muted)
                }
            }

            AppCard {
                CardTitle(tr("🎖 نشان‌ها", "🎖 Badges"))
                if (p.badges.isEmpty()) Txt(tr("هنوز نشانی نداری.", "No badges yet."), color = MaterialTheme.colorScheme.muted)
                BADGES.forEach { (k, b) ->
                    val has = k in p.badges
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (has) b.emoji else "🔒", fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(b.name, fontWeight = FontWeight.Bold, color = if (has) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.muted)
                            Txt(tr(b.fa, b.en), size = 11, color = MaterialTheme.colorScheme.muted)
                        }
                    }
                }
            }

            if (p.honorLog.isNotEmpty()) AppCard {
                CardTitle(tr("🏅 تاریخچه‌ی افتخارات", "🏅 Honor history"))
                p.honorLog.reversed().take(20).forEach { Txt(honorText(it), size = 13) }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (editName) AlertDialog(
        onDismissRequest = { editName = false },
        title = { Txt(tr("اسم نمایشی", "Display name"), bold = true) },
        text = { TextF(tr("اسم", "Name"), nameText, { nameText = it.take(20) }, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton({ game.setName(nameText); editName = false }) { Txt(tr("ذخیره", "Save"), bold = true) } },
        dismissButton = { TextButton({ editName = false }) { Txt(tr("انصراف", "Cancel")) } },
    )
}

@Composable
fun SettingsScreen(game: Game, onBack: () -> Unit, onAdmin: () -> Unit) {
    val p = game.p
    var code by remember { mutableStateOf("") }
    var help by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenBar(tr("تنظیمات", "Settings"), onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AppCard {
                CardTitle(tr("🌐 زبان", "🌐 Language"))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = p.lang == "fa", onClick = { game.adminEdit { it.copy(lang = "fa") } }, label = { Text("فارسی") })
                    FilterChip(selected = p.lang == "en", onClick = { game.adminEdit { it.copy(lang = "en") } }, label = { Text("English") })
                }
            }
            AppCard {
                CardTitle(tr("🎨 نمایش", "🎨 Appearance"))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to tr("🌗 سیستم", "🌗 System"), 1 to tr("☀️ روشن", "☀️ Light"), 2 to tr("🌙 تیره", "🌙 Dark")).forEach { (v, t) ->
                        FilterChip(selected = p.theme == v, onClick = { game.adminEdit { it.copy(theme = v) } }, label = { Txt(t) })
                    }
                }
                SwitchRow(tr("روشن ماندن صفحه", "Keep screen on"), p.keepScreen) { v -> game.adminEdit { it.copy(keepScreen = v) } }
            }
            AppCard {
                CardTitle(tr("❓ راهنما", "❓ Help"))
                OBtn(if (help) tr("بستن راهنما", "Hide help") else tr("نمایش راهنما", "Show help"), Modifier.fillMaxWidth()) {
                    help = !help
                    if (help) game.markHelpSeen()
                }
                if (help) Txt(
                    tr(
                        "• دوئل: با حریف تاس بنداز؛ عدد بزرگ‌تر برنده است.\n• لابی: دو تیم Demon و Angel؛ جمع تاس‌ها تعیین‌کننده است و MVP جایزه می‌گیرد.\n• اتحاد: بساز یا عضو شو؛ شرایط ورود (لول و امتیاز) دست رهبر و معاون‌هاست. با دونیت بانک اتحاد را پر کن و ارتقا بده.\n• نبرد اتحاد: با یک اتحاد دیگر مسابقه بده.\n• لیگ: هر فصل $SEASON_DAYS روز است؛ ۳ نفر برتر جایزه و افتخار می‌گیرند.\n• بانک از لول $BANK_MIN_LEVEL و کازینو از لول $CASINO_MIN_LEVEL باز می‌شود.\n• بازیکن‌های دیگر شبیه‌سازی شده‌اند و برنامه کاملاً آفلاین است.",
                        "• Duel: roll against an opponent; the higher number wins.\n• Lobby: Demon vs Angel; team totals decide and the MVP gets a bonus.\n• Alliance: create or join; leaders and deputies set entry requirements (level and points). Donate to the bank and upgrade.\n• Alliance war: fight another alliance.\n• League: seasons last $SEASON_DAYS days; the top 3 get rewards and honors.\n• Bank unlocks at level $BANK_MIN_LEVEL, casino at level $CASINO_MIN_LEVEL.\n• Other players are simulated and the app is fully offline.",
                    ), size = 13,
                )
            }
            AppCard {
                CardTitle(tr("🛡 پنل ادمین", "🛡 Admin panel"))
                if (p.admin) {
                    PBtn(tr("باز کردن پنل ادمین", "Open admin panel"), Modifier.fillMaxWidth()) { onAdmin() }
                } else {
                    TextF(tr("کد ادمین", "Admin code"), code, { code = it }, Modifier.fillMaxWidth())
                    PBtn(tr("فعال‌سازی", "Activate"), Modifier.fillMaxWidth()) {
                        if (game.adminLogin(code.trim())) { code = ""; onAdmin() }
                    }
                }
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Txt("Dice League  ·  v2.0  ·  ${tr("آفلاین", "Offline")}", size = 11, color = MaterialTheme.colorScheme.muted)
            }
        }
    }
}
