package com.diceoffline.game

import kotlin.math.max
import kotlin.math.min

// ===== سکه =====
const val COIN_START = 50
const val COIN_DUEL_WIN = 10
const val COIN_DUEL_LOSS = -5
const val DUEL_MIN_COINS = 10

// ===== XP / لول =====
const val MAX_LEVEL = 100
const val XP_DUEL_WIN = 60
const val XP_DUEL_LOSS = 40
const val XP_DAILY = 20

// ===== امتیاز (کاپ) =====
const val POINTS_DUEL_WIN = 20
const val POINTS_DUEL_LOSS = -10

fun xpNeeded(level: Int): Int = 100 + (level - 1) * 25

fun levelFromXp(xp: Int): Int {
    var level = 1
    var remaining = max(0, xp)
    while (level < MAX_LEVEL) {
        val need = xpNeeded(level)
        if (remaining < need) break
        remaining -= need
        level++
    }
    return level
}

/** (لول، XP داخل لول، XP لازم برای لول بعد) */
fun levelProgress(xp: Int): Triple<Int, Int, Int> {
    val level = levelFromXp(xp)
    if (level >= MAX_LEVEL) return Triple(level, 0, 0)
    var spent = 0
    for (lv in 1 until level) spent += xpNeeded(lv)
    return Triple(level, max(0, xp - spent), xpNeeded(level))
}

// ===== رنک =====
data class Rank(val name: String, val emoji: String, val min: Int)

val RANKS = listOf(
    Rank("Bronze", "🥉", 0),
    Rank("Silver", "🥈", 200),
    Rank("Gold", "🥇", 500),
    Rank("Platinum", "💠", 1000),
    Rank("Diamond", "💎", 1800),
    Rank("Master", "👑", 3000),
    Rank("OsTaD", "🏆", 4500),
    Rank("Champion", "⭐", 6500),
    Rank("Legend", "🔥", 9000),
)

fun rankFor(points: Int): Rank = RANKS.lastOrNull { points >= it.min } ?: RANKS[0]

/** رنک بعدی و امتیاز باقی‌مانده؛ null اگر در بالاترین رنک است */
fun nextRank(points: Int): Pair<Rank, Int>? =
    RANKS.firstOrNull { points < it.min }?.let { it to (it.min - points) }

// ===== جایزه‌ی روزانه =====
val DAILY_REWARDS = mapOf(1 to 10, 2 to 10, 3 to 15, 4 to 15, 5 to 20, 6 to 20, 7 to 30)
const val DAILY_MAX_STREAK = 7

// ===== فصل =====
const val SEASON_DAYS = 15
const val SEASON_RESET_CAP = 3500
const val SEASON_RESET_DROP = 300
const val SEASON_RESET_FLOOR = 1500
const val SEASON_OFFLINE_DAYS = 3
const val SEASON_OFFLINE_PENALTY = 500
val SEASON_USER_REWARDS = mapOf(1 to 5000, 2 to 4000, 3 to 3000)
const val PRINCE_OF_DICE_WINS = 100

fun seasonReset(points: Int, offline: Boolean): Int = when {
    points >= SEASON_RESET_CAP -> SEASON_RESET_CAP - (if (offline) SEASON_OFFLINE_PENALTY else 0)
    points > SEASON_RESET_FLOOR -> max(points - SEASON_RESET_DROP, SEASON_RESET_FLOOR)
    else -> points
}

// ===== بانک =====
const val BANK_MIN_LEVEL = 15
const val BANK_MAX_LEVEL = 10
val BANK_CAPACITY: List<Long?> = listOf(5000, 7000, 9700, 13500, 19000, null, null, null, null, null)
const val BANK_MAX_RATE = 5.0
val BANK_RATE = listOf(3.0, 3.2, 3.4, 3.7, 3.9, 4.1, 4.3, 4.6, 4.8, 5.0)
val BANK_UPGRADE_COST = listOf(2800, 3900, 5400, 7600, 10400, 14800, 20400, 28800, 40000)
const val BANK_WITHDRAW_FEE = 0.05
const val BANK_PERIOD_DAYS = 2
const val BANK_PERIOD_MS = BANK_PERIOD_DAYS * 86_400_000L

fun bankCap(level: Int): Long? = BANK_CAPACITY[level - 1]
fun bankRate(level: Int): Double = min(BANK_MAX_RATE, BANK_RATE[level - 1])

/** (موجودی جدید، زمان جدید، سود) — اگر سود کمتر از ۱ سکه است زمان جلو نمی‌رود. */
fun bankAccrue(balance: Long, level: Int, last: Long, now: Long): Triple<Long, Long, Long> {
    if (balance <= 0) return Triple(0L, now, 0L)
    val elapsed = max(0L, now - last)
    val interest = (balance * bankRate(level) / 100.0 * elapsed / BANK_PERIOD_MS).toLong()
    if (interest < 1) return Triple(balance, last, 0L)
    val cap = bankCap(level)
    val nb = if (cap == null) balance + interest else min(cap, balance + interest)
    return Triple(nb, now, max(0L, nb - balance))
}

// ===== کازینو (اسلات) =====
const val CASINO_MIN_LEVEL = 10
const val CASINO_MIN_BET = 50
val CASINO_BET_STEPS = listOf(50, 100, 250, 500, 1000, 2500, 5000, 10000)
const val CASINO_COOLDOWN_MS = 60_000L
val SLOT_SYMBOLS = listOf("BAR", "🍇", "🍋", "7️⃣")

fun casinoMaxBet(level: Int): Int = min(10000, 1000 + max(0, level - CASINO_MIN_LEVEL) * 250)

/** مقدار ۱..۶۴ -> سه نماد */
fun slotDecode(value: Int): Triple<Int, Int, Int> {
    val v = value - 1
    return Triple(v % 4, (v / 4) % 4, v / 16)
}

fun slotMultiplier(value: Int): Double {
    val (a, b, c) = slotDecode(value)
    if (a == b && b == c) return if (a == 3) 3.0 else 2.0
    if (a == b || b == c || a == c) {
        val pair = if (a == b || a == c) a else b
        return if (pair == 3) 1.5 else 1.0
    }
    return if (a == 3 || b == 3 || c == 3) 0.5 else 0.0
}

// ===== ماموریت‌های روزانه =====
data class Mission(val key: String, val fa: String, val en: String, val target: Int, val coins: Int, val xp: Int)

val DAILY_MISSIONS = listOf(
    Mission("play", "🎮 ۳ بازی انجام بده", "🎮 Play 3 games", 3, 40, 30),
    Mission("win", "🏆 ۱ بازی ببر", "🏆 Win 1 game", 1, 50, 40),
    Mission("group_game", "🎲 در یک لابی شرکت کن", "🎲 Play one lobby game", 1, 20, 15),
    Mission("daily", "🎁 جایزه روزانه رو بگیر", "🎁 Claim the daily reward", 1, 15, 10),
    Mission("coin_word", "🪙 دکمه‌ی سکه‌ی لابی رو بزن", "🪙 Tap the lobby coin button", 1, 15, 10),
)
const val MISSION_BONUS_NEEDED = 4
const val MISSION_BONUS_COINS = 100
const val MISSION_BONUS_XP = 60

// ===== مسیر مبتدی =====
data class StarterTask(val key: String, val fa: String, val en: String, val coins: Int)

val STARTER_TASKS = listOf(
    StarterTask("first_game", "🎮 اولین بازیت رو انجام بده", "🎮 Play your first game", 30),
    StarterTask("first_win", "🏆 اولین بردت رو بگیر", "🏆 Get your first win", 40),
    StarterTask("daily", "🎁 جایزه روزانه رو بگیر", "🎁 Claim the daily reward", 20),
    StarterTask("mission", "📋 یک ماموریت روزانه رو کامل کن", "📋 Complete a daily mission", 30),
    StarterTask("help", "❓ بخش راهنما رو ببین", "❓ Open the help section", 10),
)
const val STARTER_ALL_COINS = 150

// ===== نشان‌ها =====
const val ACTIVITY_STAR_DAYS = 30
data class Badge(val emoji: String, val name: String, val fa: String, val en: String)

val BADGES = mapOf(
    "activity_star" to Badge("🌟", "Activity Star", "$ACTIVITY_STAR_DAYS روز پشت‌سرهم بازی کن", "Play $ACTIVITY_STAR_DAYS days in a row"),
    "prince_of_dice" to Badge("🎲", "Prince of Dice", "$PRINCE_OF_DICE_WINS برد در یک فصل", "$PRINCE_OF_DICE_WINS wins in one season"),
    "maxed_unity" to Badge("✴️", "Maxed LvL Unity", "مالک اتحاد لول $ALLY_MAX_LEVEL", "Owner of a level-$ALLY_MAX_LEVEL alliance"),
    "gm" to Badge("🛡", "GM", "اهدا توسط ادمین", "Granted by admin"),
)

// ===== اتحاد =====
const val ALLY_CREATE_COST = 1000
const val ALLY_RENAME_COST = 5000
const val ALLY_RENAME_COOLDOWN_DAYS = 7
const val ALLY_MAX_LEVEL = 10
const val ALLY_MAX_MEMBERS = 25
const val ALLY_MAX_DEPUTIES = 3
const val ALLY_BATTLE_REWARD = 100
const val ALLY_BATTLE_TEAM = 5
val ALLY_SEASON_REWARDS = mapOf(1 to 5000, 2 to 3000, 3 to 1000)
val ALLY_UPGRADE_COST = mapOf(2 to 500, 3 to 1000, 4 to 2000, 5 to 4000, 6 to 6000, 7 to 8000, 8 to 10000, 9 to 12500, 10 to 15000)
val ALLY_MIN_LEVEL_STEPS = listOf(0, 3, 5, 8, 10, 15, 20, 30, 50)
val ALLY_MIN_POINTS_STEPS = listOf(0, 100, 200, 500, 1000, 1800, 3000)

// ===== لابی =====
val LOBBY_SIZES = listOf(4, 6, 8, 10, 12)
const val COIN_WIN = 15
const val COIN_MVP = 30
const val COIN_LOSS = -5
const val XP_WIN = 70
const val XP_LOSS = 50
const val XP_MVP = 20
const val XP_TIE_MVP = 10
const val COIN_CHAT_MIN = 10
const val COIN_CHAT_MAX = 50
const val COIN_CHAT_COOLDOWN_MS = 600_000L

// ===== رتبه‌بندی لول / افتخارات =====
val LEVEL_SEASON_REWARDS = mapOf(1 to 10000, 2 to 5000, 3 to 4000)
val HONOR_LEAGUE = mapOf(1 to 30, 2 to 20, 3 to 10)
val HONOR_LEVEL = mapOf(1 to 20, 2 to 10, 3 to 5)
const val HONOR_PRINCE = 15
const val HONOR_ALLY_TOP = 10

// ===== Fake Play (رفتار NPCها) =====
const val FP_MIN_COUNT = 20
const val FP_MAX_COUNT = 300
const val FP_DEFAULT_COUNT = 100
val FP_DUEL_STEPS = listOf(1, 2, 3, 5, 8, 10, 15, 20, 30, 45, 60, 90, 120)
val FP_LOBBY_STEPS = listOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180)
val FP_LOBBY_TIMER_STEPS = listOf(1, 2, 3, 5, 7, 10, 15, 20, 30)
val FP_LL_EVERY_STEPS = listOf(1, 2, 3, 5, 10, 15, 20, 30, 45, 60)
const val FP_LL_MIN = 5
const val FP_LL_MAX = 25
const val FP_NPC_POINTS_CAP = 5000

// ===== ادمین =====
const val ADMIN_CODE_SHA256 = "55d505e6987863f3750a6653c0adfaa8ee0ad3102c1ea192fd94a703b0cc8dbf"

fun xpForLevel(level: Int): Int {
    var t = 0
    for (l in 1 until level.coerceIn(1, MAX_LEVEL)) t += xpNeeded(l)
    return t
}

fun fmt(n: Number): String = "%,d".format(n.toLong())
