package com.diceoffline

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.diceoffline.game.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun GameScreen(game: Game) {
    val now by tickState()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        HeroCard(game, now)
        DuelCard(game)
        DailyCard(game, now)
        MissionsCard(game)
        StarterCard(game)
        BankCard(game)
        CasinoCard(game, now)
        GiftCard(game)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun HeroCard(game: Game, now: Long) {
    val p = game.p
    val (lv, cur, need) = levelProgress(p.xp)
    val rk = rankFor(p.points)
    val nr = nextRank(p.points)
    GradientHeader {
        Txt(tr("فصل ${p.seasonNo}  ·  ${dur(game.seasonTimeLeftMs())} مانده", "Season ${p.seasonNo}  ·  ${dur(game.seasonTimeLeftMs())} left"), size = 12, color = MaterialTheme.colorScheme.muted)
        Txt("${rk.emoji} ${rk.name}", size = 26, bold = true, color = MaterialTheme.colorScheme.primary)
        Txt(tr("${fmt(p.points)} امتیاز", "${fmt(p.points)} points"), size = 14)
        if (nr != null) Txt(tr("${nr.second} امتیاز تا ${nr.first.emoji} ${nr.first.name}", "${nr.second} pts to ${nr.first.emoji} ${nr.first.name}"), size = 11, color = MaterialTheme.colorScheme.muted)
        Spacer(Modifier.height(2.dp))
        Txt("Lv $lv", bold = true)
        if (need > 0) {
            LinearProgressIndicator(progress = { (cur.toFloat() / need).coerceIn(0f, 1f) }, Modifier.fillMaxWidth().height(8.dp))
            Txt("$cur / $need XP", size = 11, color = MaterialTheme.colorScheme.muted)
        } else Txt("MAX", size = 12, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun DuelCard(game: Game) {
    val scope = rememberCoroutineScope()
    var duel by remember { mutableStateOf<DuelRoll?>(null) }
    var rolling by remember { mutableStateOf(false) }
    AppCard {
        CardTitle(tr("🎲 دوئل ۱ به ۱", "🎲 1v1 Duel"), tr("با یک حریف هم‌سطح تاس بنداز", "Roll against a player of similar rank"))
        val r = duel
        if (r != null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    RollingDice(r.mine, rolling, 72.dp)
                    Spacer(Modifier.height(4.dp))
                    Text(game.p.name, maxLines = 1)
                }
                Txt("VS", bold = true, color = MaterialTheme.colorScheme.muted)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    RollingDice(r.theirs, rolling, 72.dp, MaterialTheme.colorScheme.muted)
                    Spacer(Modifier.height(4.dp))
                    Text(r.opponent.name, maxLines = 1)
                }
            }
            if (!rolling) {
                Txt(
                    if (r.won) tr("🏆 بردی!  +$COIN_DUEL_WIN 🪙  +$POINTS_DUEL_WIN", "🏆 You won!  +$COIN_DUEL_WIN 🪙  +$POINTS_DUEL_WIN")
                    else tr("❌ باختی  $COIN_DUEL_LOSS 🪙  $POINTS_DUEL_LOSS", "❌ You lost  $COIN_DUEL_LOSS 🪙  $POINTS_DUEL_LOSS"),
                    bold = true, size = 16, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center,
                    color = if (r.won) MaterialTheme.colorScheme.good else MaterialTheme.colorScheme.bad,
                )
            }
        }
        PBtn(tr("🎲 تاس بنداز", "🎲 Roll the dice"), Modifier.fillMaxWidth(), enabled = !rolling) {
            val roll = game.rollDuel() ?: return@PBtn
            duel = roll
            rolling = true
            scope.launch {
                delay(1300)
                game.finishDuel(roll)
                rolling = false
            }
        }
        Txt(tr("حداقل $DUEL_MIN_COINS سکه لازمه.", "Minimum $DUEL_MIN_COINS coins required."), size = 11, color = MaterialTheme.colorScheme.muted)
    }
}

@Composable
private fun DailyCard(game: Game, now: Long) {
    val p = game.p
    val left = game.chatCoinLeftMs()
    AppCard {
        CardTitle(tr("🎁 جایزه‌ها", "🎁 Rewards"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PBtn(
                if (game.dailyAvailable()) tr("جایزه روزانه (روز ${(if (p.lastDailyDay == game.today() - 1) minOf(p.dailyStreak + 1, DAILY_MAX_STREAK) else 1)})", "Daily reward")
                else tr("گرفته شد ✅", "Claimed ✅"),
                Modifier.weight(1f), enabled = game.dailyAvailable(),
            ) { game.claimDaily() }
            OBtn(
                if (left > 0) "🪙 ${dur(left)}" else tr("🪙 سکه رایگان", "🪙 Free coins"),
                Modifier.weight(1f), enabled = left <= 0,
            ) { game.claimChatCoin() }
        }
        Txt(tr("🔥 رکورد پشت‌سرهم: ${p.dailyStreak} روز  ·  حضور: ${p.openStreak} روز", "🔥 Daily streak: ${p.dailyStreak}  ·  Active days: ${p.openStreak}"), size = 12, color = MaterialTheme.colorScheme.muted)
    }
}

@Composable
private fun MissionsCard(game: Game) {
    val p = game.p
    val fresh = p.missionDay == game.today()
    val prog = if (fresh) p.missionProg else emptyMap()
    val done = if (fresh) p.missionDone else emptySet()
    AppCard {
        CardTitle(tr("📋 ماموریت‌های امروز", "📋 Today's missions"), tr("${done.size} / ${DAILY_MISSIONS.size} انجام شده — با $MISSION_BONUS_NEEDED تا جایزه‌ی ویژه (+$MISSION_BONUS_COINS 🪙)", "${done.size} / ${DAILY_MISSIONS.size} done — $MISSION_BONUS_NEEDED for the bonus (+$MISSION_BONUS_COINS 🪙)"))
        DAILY_MISSIONS.forEach { m ->
            val ok = m.key in done
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt(tr(m.fa, m.en), Modifier.weight(1f), size = 13, color = if (ok) MaterialTheme.colorScheme.good else androidx.compose.ui.graphics.Color.Unspecified)
                Txt(if (ok) "✅" else "${prog[m.key] ?: 0}/${m.target}  ·  +${m.coins}🪙", size = 12, color = MaterialTheme.colorScheme.muted)
            }
        }
    }
}

@Composable
private fun StarterCard(game: Game) {
    val p = game.p
    if ("_all" in p.starter) return
    AppCard {
        CardTitle(tr("🎓 مسیر مبتدی", "🎓 Starter path"), tr("همه رو کامل کن: +$STARTER_ALL_COINS 🪙", "Finish all: +$STARTER_ALL_COINS 🪙"))
        STARTER_TASKS.forEach { t ->
            val ok = t.key in p.starter
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt(tr(t.fa, t.en), Modifier.weight(1f), size = 13, color = if (ok) MaterialTheme.colorScheme.good else androidx.compose.ui.graphics.Color.Unspecified)
                Txt(if (ok) "✅" else "+${t.coins}🪙", size = 12, color = MaterialTheme.colorScheme.muted)
            }
        }
    }
}

@Composable
private fun BankCard(game: Game) {
    val p = game.p
    val lv = levelFromXp(p.xp)
    var amount by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { game.refreshBank() }
    AppCard {
        CardTitle(tr("🏦 بانک", "🏦 Bank"), tr("سود هر $BANK_PERIOD_DAYS روز؛ کارمزد برداشت ${(BANK_WITHDRAW_FEE * 100).toInt()}٪", "Interest every $BANK_PERIOD_DAYS days; ${(BANK_WITHDRAW_FEE * 100).toInt()}% withdraw fee"))
        when {
            lv < BANK_MIN_LEVEL -> Txt(tr("🔒 از لول $BANK_MIN_LEVEL باز میشه.", "🔒 Unlocks at level $BANK_MIN_LEVEL."), color = MaterialTheme.colorScheme.muted)
            p.bankLevel == 0 -> PBtn(tr("باز کردن حساب بانکی", "Open a bank account"), Modifier.fillMaxWidth()) { game.openBank() }
            else -> {
                val cap = bankCap(p.bankLevel)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatBox(fmt(p.bankBalance), tr("موجودی", "Balance"), Modifier.weight(1f))
                    StatBox("${bankRate(p.bankLevel)}%", tr("سود", "Rate"), Modifier.weight(1f))
                    StatBox(cap?.let { fmt(it) } ?: "∞", tr("ظرفیت", "Capacity"), Modifier.weight(1f))
                }
                NumField(tr("مقدار", "Amount"), amount, { amount = it }, Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PBtn(tr("واریز", "Deposit"), Modifier.weight(1f)) { game.bankDeposit(parseAmount(amount)) }
                    OBtn(tr("برداشت", "Withdraw"), Modifier.weight(1f)) { game.bankWithdraw(parseAmount(amount)) }
                }
                if (p.bankLevel < BANK_MAX_LEVEL)
                    OBtn(tr("⬆️ ارتقا به سطح ${p.bankLevel + 1}  (${fmt(BANK_UPGRADE_COST[p.bankLevel - 1])} 🪙)", "⬆️ Upgrade to level ${p.bankLevel + 1}  (${fmt(BANK_UPGRADE_COST[p.bankLevel - 1])} 🪙)"), Modifier.fillMaxWidth()) { game.bankUpgrade() }
            }
        }
    }
}

@Composable
private fun CasinoCard(game: Game, now: Long) {
    val p = game.p
    val lv = levelFromXp(p.xp)
    val scope = rememberCoroutineScope()
    var bet by remember { mutableIntStateOf(CASINO_MIN_BET) }
    var res by remember { mutableStateOf<SlotResult?>(null) }
    var spinning by remember { mutableStateOf(false) }
    var reel by remember { mutableStateOf(Triple(0, 1, 2)) }
    val cd = game.casinoCooldownLeft()
    AppCard {
        CardTitle(tr("🎰 کازینو", "🎰 Casino"), tr("اسلات؛ سه تا مثل هم = جایزه‌ی بزرگ", "Slots — match three for the jackpot"))
        if (lv < CASINO_MIN_LEVEL) {
            Txt(tr("🔒 از لول $CASINO_MIN_LEVEL باز میشه.", "🔒 Unlocks at level $CASINO_MIN_LEVEL."), color = MaterialTheme.colorScheme.muted)
        } else {
            LaunchedEffect(spinning) {
                while (spinning) {
                    reel = Triple(Random.nextInt(4), Random.nextInt(4), Random.nextInt(4))
                    delay(80)
                }
            }
            val shown = res?.let { if (spinning) reel else slotDecode(it.value) } ?: reel
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                listOf(shown.first, shown.second, shown.third).forEach { s ->
                    Surface(Modifier.padding(4.dp).size(64.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Box(contentAlignment = Alignment.Center) { Text(SLOT_SYMBOLS[s], style = MaterialTheme.typography.titleLarge) }
                    }
                }
            }
            val r = res
            if (r != null && !spinning) Txt(
                if (r.net > 0) tr("🎉 +${fmt(r.net)} 🪙", "🎉 +${fmt(r.net)} 🪙") else if (r.net == 0) tr("مساوی ➖", "Even ➖") else tr("باختی ${fmt(r.net)} 🪙", "Lost ${fmt(r.net)} 🪙"),
                bold = true, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center,
                color = if (r.net >= 0) MaterialTheme.colorScheme.good else MaterialTheme.colorScheme.bad,
            )
            val maxBet = casinoMaxBet(lv)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CASINO_BET_STEPS.filter { it <= maxBet }.forEach { b ->
                    FilterChip(selected = bet == b, onClick = { bet = b }, label = { Txt(fmt(b)) })
                }
            }
            PBtn(if (cd > 0) "⏳ ${dur(cd)}" else tr("🎰 بچرخون  (${fmt(bet)} 🪙)", "🎰 Spin  (${fmt(bet)} 🪙)"), Modifier.fillMaxWidth(), enabled = cd <= 0 && !spinning) {
                val r = game.spinSlot(bet) ?: return@PBtn
                res = r
                spinning = true
                scope.launch { delay(900); spinning = false }
            }
        }
    }
}

@Composable
private fun GiftCard(game: Game) {
    var code by remember { mutableStateOf("") }
    AppCard {
        CardTitle(tr("🎟 کد هدیه", "🎟 Gift code"))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextF(tr("کد", "Code"), code, { code = it }, Modifier.weight(1f))
            PBtn(tr("ثبت", "Redeem")) { game.redeemGift(code); code = "" }
        }
    }
}
