package com.diceoffline

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.diceoffline.game.L
import com.diceoffline.game.tr
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

// ------------------------------------------------------------------ رنگ‌ها
val Pink = Color(0xFFE8809F)
val Gold = Color(0xFFFFD54A)

val ColorScheme.muted: Color get() = onSurface.copy(alpha = 0.62f)
val ColorScheme.good: Color get() = Color(0xFF4CAF7A)
val ColorScheme.bad: Color get() = Color(0xFFE5575F)

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Pink, onPrimary = Color(0xFF2B0A16),
        background = Color(0xFF1B1216), onBackground = Color(0xFFF6E9EE),
        surface = Color(0xFF2A1B22), onSurface = Color(0xFFF6E9EE),
        surfaceVariant = Color(0xFF3A2631), onSurfaceVariant = Color(0xFFD9BFCA),
        outline = Color(0xFF4A3340), secondaryContainer = Color(0xFF4A2A38),
        onSecondaryContainer = Color(0xFFFFD9E4), error = Color(0xFFE5575F),
    ) else lightColorScheme(
        primary = Color(0xFFC2456E), onPrimary = Color.White,
        background = Color(0xFFFFF4F7), onBackground = Color(0xFF2B1620),
        surface = Color.White, onSurface = Color(0xFF2B1620),
        surfaceVariant = Color(0xFFFBE4EC), onSurfaceVariant = Color(0xFF6B4455),
        outline = Color(0xFFEBC9D5), secondaryContainer = Color(0xFFFFD9E4),
        onSecondaryContainer = Color(0xFF5A1630), error = Color(0xFFC73A42),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

// ------------------------------------------------------------------ متن و ارقام
fun d(s: String): String =
    if (L.lang != "fa") s else buildString { for (c in s) append(if (c in '0'..'9') '۰' + (c - '0') else c) }

fun parseSigned(s: String): Int {
    val neg = s.trim().startsWith("-") || s.trim().startsWith("−")
    val v = parseAmount(s)
    return if (neg) -v else v
}

fun parseAmount(s: String): Int {
    val t = s.map { c ->
        when (c) {
            in '۰'..'۹' -> '0' + (c - '۰')
            in '٠'..'٩' -> '0' + (c - '٠')
            else -> c
        }
    }.filter { it.isDigit() }.joinToString("")
    return t.toLongOrNull()?.coerceAtMost(2_000_000_000L)?.toInt() ?: 0
}

fun dur(ms: Long): String {
    val s = ms / 1000
    val dd = s / 86400
    val h = (s % 86400) / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return when {
        dd > 0 -> tr("$dd روز و $h ساعت", "${dd}d ${h}h")
        h > 0 -> tr("$h ساعت و $m دقیقه", "${h}h ${m}m")
        else -> "%d:%02d".format(m, sec)
    }
}

@Composable
fun Txt(
    s: String, modifier: Modifier = Modifier, size: Int = 14, bold: Boolean = false,
    color: Color = Color.Unspecified, align: TextAlign? = null, maxLines: Int = Int.MAX_VALUE,
) {
    Text(
        d(s), modifier, color = color, fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = align, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun tickState(periodMs: Long = 1000): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        delay(periodMs)
        value = System.currentTimeMillis()
    }
}

// ------------------------------------------------------------------ اجزای پایه
@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun CardTitle(s: String, sub: String? = null) {
    Column {
        Txt(s, size = 17, bold = true)
        if (sub != null) Txt(sub, size = 12, color = MaterialTheme.colorScheme.muted)
    }
}

@Composable
fun PBtn(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick, modifier, enabled, shape = RoundedCornerShape(16.dp)) { Txt(text, bold = true) }
}

@Composable
fun OBtn(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(onClick, modifier, enabled, shape = RoundedCornerShape(16.dp)) { Txt(text) }
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.surfaceVariant) {
    Surface(modifier, shape = RoundedCornerShape(50), color = color) {
        Box(Modifier.padding(horizontal = 12.dp, vertical = 5.dp)) { Txt(text, size = 12, bold = true, maxLines = 1) }
    }
}

@Composable
fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Txt(value, size = 18, bold = true, color = MaterialTheme.colorScheme.primary, maxLines = 1)
            Txt(label, size = 11, color = MaterialTheme.colorScheme.muted, maxLines = 1)
        }
    }
}

@Composable
fun NumField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value, onValue, modifier, label = { Txt(label, size = 12) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(14.dp),
    )
}

@Composable
fun TextF(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, single: Boolean = true) {
    OutlinedTextField(
        value, onValue, modifier, label = { Txt(label, size = 12) }, singleLine = single,
        shape = RoundedCornerShape(14.dp),
    )
}

@Composable
fun Stepper(label: String, value: Int, steps: List<Int>, suffix: String = "", onChange: (Int) -> Unit) {
    val idx = steps.indices.minByOrNull { abs(steps[it] - value) } ?: 0
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, Modifier.weight(1f), size = 13)
        FilledTonalIconButton(onClick = { onChange(steps[(idx - 1).coerceAtLeast(0)]) }, Modifier.size(34.dp)) { Text("−") }
        Txt("$value$suffix", Modifier.widthIn(min = 56.dp), bold = true, align = TextAlign.Center)
        FilledTonalIconButton(onClick = { onChange(steps[(idx + 1).coerceAtMost(steps.lastIndex)]) }, Modifier.size(34.dp)) { Text("+") }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, Modifier.weight(1f), size = 14)
        Switch(checked, onChange)
    }
}

@Composable
fun Confirm(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Txt(text) },
        confirmButton = { TextButton(onYes) { Txt(tr("تأیید", "Confirm"), bold = true) } },
        dismissButton = { TextButton(onNo) { Txt(tr("انصراف", "Cancel")) } },
    )
}

// ------------------------------------------------------------------ تاس و لوگو
private val PIPS = mapOf(
    1 to listOf(1 to 1),
    2 to listOf(0 to 0, 2 to 2),
    3 to listOf(0 to 0, 1 to 1, 2 to 2),
    4 to listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2),
    5 to listOf(0 to 0, 2 to 0, 1 to 1, 0 to 2, 2 to 2),
    6 to listOf(0 to 0, 0 to 1, 0 to 2, 2 to 0, 2 to 1, 2 to 2),
)

@Composable
fun DiceFace(v: Int, sz: Dp = 64.dp, tint: Color = MaterialTheme.colorScheme.primary) {
    val pip = MaterialTheme.colorScheme.background
    val light = lerp(tint, Color.White, 0.28f)
    val dark = lerp(tint, Color.Black, 0.18f)
    Canvas(Modifier.size(sz)) {
        val w = this.size.width
        drawRoundRect(
            Brush.linearGradient(listOf(light, tint, dark), Offset(0f, 0f), Offset(w, w)),
            cornerRadius = CornerRadius(w * 0.22f),
        )
        drawRoundRect(
            Color.White.copy(alpha = 0.35f), topLeft = Offset(w * 0.03f, w * 0.03f),
            size = Size(w * 0.94f, w * 0.94f), cornerRadius = CornerRadius(w * 0.2f), style = Stroke(w * 0.025f),
        )
        val pos = listOf(0.27f, 0.5f, 0.73f)
        PIPS[v.coerceIn(1, 6)]?.forEach { (cx, cy) ->
            val c = Offset(w * pos[cx], w * pos[cy])
            drawCircle(Color.Black.copy(alpha = 0.25f), radius = w * 0.09f, center = Offset(c.x, c.y + w * 0.012f))
            drawCircle(pip, radius = w * 0.085f, center = c)
        }
    }
}

/** تاس سه‌بعدی: می‌پرد، می‌چرخد، وجه‌ها عوض می‌شوند و آخرش با فنر روی عدد نهایی می‌نشیند. */
@Composable
fun RollingDice(final: Int, rolling: Boolean, sz: Dp = 64.dp, tint: Color = MaterialTheme.colorScheme.primary) {
    var shown by remember { mutableIntStateOf(final) }
    var wasRolling by remember { mutableStateOf(false) }
    val rotX = remember { Animatable(0f) }
    val rotY = remember { Animatable(0f) }
    val rotZ = remember { Animatable(0f) }
    val lift = remember { Animatable(0f) }
    val scale = remember { Animatable(1f) }
    val density = LocalDensity.current.density

    LaunchedEffect(rolling, final) {
        if (rolling) {
            wasRolling = true
            coroutineScope {
                launch { while (true) { shown = Random.nextInt(1, 7); delay(75) } }
                launch { while (true) rotX.animateTo(rotX.value + 360f, tween(540, easing = LinearEasing)) }
                launch { while (true) rotY.animateTo(rotY.value + 360f, tween(430, easing = LinearEasing)) }
                launch { while (true) rotZ.animateTo(rotZ.value + 360f, tween(760, easing = LinearEasing)) }
                launch {
                    while (true) {
                        lift.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
                        lift.animateTo(0f, tween(240, easing = FastOutLinearInEasing))
                    }
                }
            }
        } else {
            shown = final
            if (!wasRolling) return@LaunchedEffect
            wasRolling = false
            suspend fun settle(a: Animatable<Float, AnimationVector1D>) {
                val t = if (a.value % 360f > 180f) 360f else 0f
                a.snapTo(a.value % 360f)
                a.animateTo(t, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium))
                a.snapTo(0f)
            }
            coroutineScope {
                launch { settle(rotX) }
                launch { settle(rotY) }
                launch { settle(rotZ) }
                launch { lift.animateTo(0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }
                launch {
                    scale.animateTo(1.2f, tween(90))
                    scale.animateTo(1f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessLow))
                }
            }
        }
    }

    Box(Modifier.size(sz)) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val k = 1f - 0.45f * lift.value
            drawOval(
                Color.Black.copy(alpha = 0.22f * k),
                topLeft = Offset(w * (0.5f - 0.38f * k), w * 0.98f),
                size = Size(w * 0.76f * k, w * 0.12f * k),
            )
        }
        Box(
            Modifier.matchParentSize().graphicsLayer {
                rotationX = rotX.value
                rotationY = rotY.value
                rotationZ = rotZ.value * 0.5f
                translationY = -lift.value * size.height * 0.32f
                val sc = scale.value * (1f + 0.12f * lift.value)
                scaleX = sc
                scaleY = sc
                cameraDistance = 16f * density
            }
        ) { DiceFace(shown, sz, tint) }
    }
}

@Composable
fun Logo(sz: Dp) {
    val bg = MaterialTheme.colorScheme.surface
    val ring = MaterialTheme.colorScheme.outline
    Canvas(Modifier.size(sz)) {
        val r = size.minDimension / 2
        val c = Offset(r, r)
        drawCircle(bg, r, c)
        drawCircle(ring, r - 1.5f, c, style = Stroke(3f))
        val n = 11
        val step = (r * 1.7f) / n
        for (i in 0 until n) for (j in 0 until n) {
            val dx = (i - (n - 1) / 2f) * step
            val dy = (j - (n - 1) / 2f) * step
            if (sqrt(dx * dx + dy * dy) < r * 0.82f) drawCircle(Pink, step * 0.14f, Offset(c.x + dx, c.y + dy))
        }
        val g = Offset(c.x + r * 0.32f, c.y - r * 0.32f)
        drawCircle(bg, r * 0.22f, g)
        drawCircle(Gold, r * 0.2f, g, style = Stroke(r * 0.07f))
        drawCircle(Gold, r * 0.07f, g)
    }
}

@Composable
fun GradientHeader(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val a = MaterialTheme.colorScheme.primary.copy(alpha = 0.32f)
    val b = MaterialTheme.colorScheme.surface
    Box(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(a, b)), RoundedCornerShape(26.dp))
            .padding(18.dp)
    ) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp), content = content, modifier = Modifier.fillMaxWidth()) }
}

@Composable
fun Avatar(name: String, sz: Dp = 40.dp) {
    Box(
        Modifier.size(sz).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text(name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = (sz.value * 0.45f).sp) }
}
