package com.diceoffline

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat
import com.diceoffline.game.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull

class MainActivity : ComponentActivity() {
    private var game: Game? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val g = Game(applicationContext)
        game = g
        setContent { App(g) }
    }

    override fun onResume() {
        super.onResume()
        game?.liveTick()
    }
}

@Composable
fun App(game: Game) {
    val p = game.p
    val dark = when (p.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    AppTheme(dark) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (L.lang == "fa") LayoutDirection.Rtl else LayoutDirection.Ltr
        ) { Root(game, dark) }
    }
}

private data class NavTab(val emoji: String, val fa: String, val en: String)

private val TABS = listOf(
    NavTab("🎲", "بازی", "Play"),
    NavTab("🛡", "اتحاد", "Alliance"),
    NavTab("👥", "لابی", "Lobby"),
    NavTab("📈", "لول", "Levels"),
    NavTab("🏅", "کلی", "Overall"),
    NavTab("🏆", "لیگ", "League"),
)

@Composable
private fun Root(game: Game, dark: Boolean) {
    val p = game.p
    val ctx = LocalContext.current
    val bg = MaterialTheme.colorScheme.background
    var tab by remember { mutableIntStateOf(0) }
    var overlay by remember { mutableIntStateOf(0) }   // 0 هیچ، 1 پروفایل، 2 تنظیمات، 3 ادمین
    val snack = remember { SnackbarHostState() }

    // نوار وضعیت و روشن ماندن صفحه
    SideEffect {
        val act = ctx as? Activity ?: return@SideEffect
        act.window.statusBarColor = bg.toArgb()
        act.window.navigationBarColor = bg.toArgb()
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
        if (p.keepScreen) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // زنده نگه داشتن NPCها
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            game.liveTick()
        }
    }
    // پیام‌ها
    LaunchedEffect(Unit) {
        snapshotFlow { game.message }.filterNotNull().collect {
            game.message = null
            snack.showSnackbar(d(it), duration = SnackbarDuration.Long)
        }
    }

    BackHandler(overlay != 0) { overlay = 0 }

    Scaffold(
        containerColor = bg,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            if (overlay == 0) TopBar(game, onProfile = { overlay = 1 }, onSettings = { overlay = 2 })
        },
        bottomBar = {
            if (overlay == 0) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(t.emoji, fontSize = 20.sp) },
                        label = { Text(tr(t.fa, t.en), fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedTextColor = MaterialTheme.colorScheme.muted,
                            indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (overlay) {
                1 -> ProfileScreen(game, onBack = { overlay = 0 })
                2 -> SettingsScreen(game, onBack = { overlay = 0 }, onAdmin = { overlay = 3 })
                3 -> AdminScreen(game, onBack = { overlay = 2 })
                else -> when (tab) {
                    0 -> GameScreen(game)
                    1 -> AllianceScreen(game)
                    2 -> LobbyScreen(game)
                    3 -> BoardScreen(game, 0)
                    4 -> BoardScreen(game, 1)
                    else -> LeagueScreen(game)
                }
            }
        }
    }
}

@Composable
private fun TopBar(game: Game, onProfile: () -> Unit, onSettings: () -> Unit) {
    val p = game.p
    val lv = levelFromXp(p.xp)
    val rk = rankFor(p.points)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.clip(CircleShape).clickable { onProfile() }) { Logo(42.dp) }
        Column(Modifier.weight(1f).clickable { onProfile() }) {
            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Txt("Lv $lv  ·  ${rk.emoji} ${rk.name}", size = 11, color = MaterialTheme.colorScheme.muted, maxLines = 1)
        }
        Pill("🪙 ${fmt(p.coins)}", color = MaterialTheme.colorScheme.secondaryContainer)
        IconButton(onSettings) { Text("⚙️", fontSize = 20.sp) }
    }
}
