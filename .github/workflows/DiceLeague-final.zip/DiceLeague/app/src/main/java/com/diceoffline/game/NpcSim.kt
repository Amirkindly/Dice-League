package com.diceoffline.game

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

// ----------------------------------------------------------------- نام‌ها
private val FIRST_EN = listOf(
    "Ali", "Sara", "Reza", "Mina", "Arman", "Nika", "Hamid", "Parisa", "Kian", "Neda", "Omid", "Yasi", "Sina",
    "Roya", "Babak", "Elham", "Farid", "Shiva", "Amir", "Maryam", "Milad", "Atefeh", "Pouya", "Zahra", "Navid",
    "Leila", "Behnam", "Sepideh", "Kaveh", "Tara", "Alex", "Max", "Luna", "Leo", "Zoe", "Ryan", "Emma", "Noah",
    "Mia", "Liam", "Ava", "Jack", "Eva", "Adam", "Nora", "Ethan", "Lily", "Daniel", "Sofia", "Victor",
)
private val LAST_EN = listOf(
    "Moore", "Khan", "Stone", "Wolf", "Hunter", "Knight", "Frost", "Black", "Storm", "Rose", "King", "Fox",
    "Reed", "Cole", "Hayes", "Shah", "Rad", "Noor", "Vale", "Hart",
)
private val TAGS = listOf("gamer", "pro", "king", "xd", "dice", "fa", "x", "ir", "lucky", "official", "boss")
private val NUMS = listOf("77", "01", "99", "2000", "13", "21", "666", "123", "7", "88", "_1", "_x")
private val FIRST_FA = listOf(
    "علی", "سارا", "رضا", "مینا", "آرمان", "نیکا", "حمید", "پریسا", "کیان", "ندا", "امید", "یاسمن", "سینا",
    "رویا", "بابک", "الهام", "فرید", "شیوا", "امیر", "مریم", "میلاد", "عاطفه", "پویا", "زهرا", "نوید", "لیلا",
)
private val LAST_FA = listOf("رادمنش", "نوری", "کاظمی", "احمدی", "شاهی", "زارع", "موسوی", "رحیمی", "حیدری", "سلطانی")

private val ALLY_NAMES = listOf(
    "Phoenix", "Shadow Wolves", "Iron Legion", "Night Kings", "Royal Eagles", "Dark Storm", "Alpha Team",
    "Blood Moon", "Silent Hunters", "Black Dragons", "Ice Wolves", "Fire Lords", "Ghost Squad", "Storm Riders",
    "Lion Hearts", "Venom", "Titans", "Spartans", "گرگ‌های سیاه", "عقاب‌های شب", "شیران", "طوفان", "سایه‌ها",
    "نگهبانان", "شکارچیان", "اژدهایان", "امپراتوری", "پهلوانان",
)

fun stochRound(x: Double): Int {
    val f = floor(x).toInt()
    return f + if (Random.nextDouble() < x - f) 1 else 0
}

internal fun genName(used: Set<String>): String {
    repeat(30) {
        val k = Random.nextDouble()
        val n = when {
            k < 0.25 -> "${FIRST_EN.random()} ${LAST_EN.random()}"
            k < 0.45 -> "${FIRST_EN.random()}_${TAGS.random()}"
            k < 0.65 -> "${FIRST_EN.random()}${NUMS.random()}"
            k < 0.80 -> "${FIRST_FA.random()} ${LAST_FA.random()}"
            k < 0.90 -> FIRST_FA.random() + Random.nextInt(1, 100)
            else -> FIRST_EN.random()
        }
        if (n !in used) return n
    }
    return "Player" + Random.nextInt(1000, 99999)
}

internal fun genAllyName(used: Set<String>): String {
    repeat(40) {
        val base = ALLY_NAMES.random()
        val n = if (base !in used) base else base + " " + Random.nextInt(2, 99)
        if (n !in used) return n
    }
    return "Team" + Random.nextInt(100, 99999)
}

// ----------------------------------------------------------------- کمکی‌ها
fun Player.withNpc(id: Int, f: (Npc) -> Npc): Player =
    copy(npcs = npcs.map { if (it.id == id) f(it) else it })

fun Player.withAlly(id: Int, f: (Alliance) -> Alliance): Player =
    copy(alliances = alliances.map { if (it.id == id) f(it) else it })

fun Player.npc(id: Int): Npc? = npcs.firstOrNull { it.id == id }
fun Player.ally(id: Int): Alliance? = alliances.firstOrNull { it.id == id }
fun Player.allyOf(mid: String): Alliance? = alliances.firstOrNull { mid in it.members }
fun Player.myAlly(): Alliance? = allyOf(ME)

fun Player.nameOf(mid: String): String =
    if (mid == ME) name else midToNpcId(mid)?.let { npc(it)?.name } ?: "?"

fun Player.pointsOf(mid: String): Int =
    if (mid == ME) points else midToNpcId(mid)?.let { npc(it)?.points } ?: 0

fun Player.levelOf(mid: String): Int =
    levelFromXp(if (mid == ME) xp else midToNpcId(mid)?.let { npc(it)?.xp } ?: 0)

/** امتیاز اتحاد = جمع امتیاز اعضا (مثل ربات). */
fun Player.allyPoints(a: Alliance): Int = a.members.sumOf { pointsOf(it) }

fun Player.isActiveNpc(n: Npc) = !n.banned && !n.restricted

// ----------------------------------------------------------------- ساخت دنیا
internal fun newNpc(id: Int, used: MutableSet<String>, custom: MutableList<String>): Npc {
    val name = if (custom.isNotEmpty()) custom.removeAt(0) else genName(used)
    used.add(name)
    val pts = (Random.nextDouble().pow(2.2) * 4200).toInt()
    return Npc(id, name, pts, pts * 4 + Random.nextInt(0, 3000), Random.nextInt(300, 6000))
}

fun growNpcs(pl: Player, n: Int): Player {
    if (n <= 0) return pl
    val used = pl.npcs.map { it.name }.toMutableSet()
    val queue = pl.customNames.filter { it !in used }.toMutableList()
    var id = pl.nextNpcId
    val list = pl.npcs.toMutableList()
    repeat(n) { list.add(newNpc(id++, used, queue)) }
    return pl.copy(npcs = list, nextNpcId = id)
}

fun shrinkNpcs(pl: Player, target: Int): Player {
    var cur = pl
    val remove = cur.npcs.sortedByDescending { it.id }.take(max(0, cur.npcs.size - target))
    remove.forEach { cur = removeMember(cur, npcMid(it.id)) }
    val ids = remove.map { it.id }.toSet()
    return cur.copy(npcs = cur.npcs.filter { it.id !in ids })
}

internal fun createAlliance(pl: Player, owner: String, name: String, members: List<String> = emptyList()): Player {
    val mem = (listOf(owner) + members).distinct()
    val a = Alliance(
        id = pl.nextAllyId, name = name, owner = owner, members = mem,
        minLevel = ALLY_MIN_LEVEL_STEPS.take(4).random(), minPoints = ALLY_MIN_POINTS_STEPS.take(4).random(),
    )
    return pl.copy(alliances = pl.alliances + a, nextAllyId = pl.nextAllyId + 1)
}

fun seedAlliances(pl0: Player): Player {
    var pl = pl0
    val n = max(4, pl.npcs.size / 12)
    repeat(n) {
        val free = pl.npcs.filter { pl.isActiveNpc(it) && pl.allyOf(npcMid(it.id)) == null }.shuffled()
        if (free.size < 3) return pl
        val owner = free[0]
        val mem = free.drop(1).take(Random.nextInt(2, 9)).map { npcMid(it.id) }
        pl = createAlliance(pl, npcMid(owner.id), genAllyName(pl.alliances.map { it.name }.toSet()), mem)
    }
    return pl
}

fun ensureWorld(pl0: Player): Player {
    var pl = pl0
    if (pl.npcs.size < pl.npcCount) pl = growNpcs(pl, pl.npcCount - pl.npcs.size)
    if (pl.alliances.isEmpty() && pl.npcs.isNotEmpty()) pl = seedAlliances(pl)
    return pl
}

/** عضو را از هر اتحادی حذف می‌کند؛ اگر مالک بود به معاون/عضو بعدی می‌رسد و اگر اتحاد خالی شد منحل می‌شود. */
fun removeMember(pl: Player, mid: String): Player {
    val out = ArrayList<Alliance>()
    for (a in pl.alliances) {
        if (mid !in a.members && mid !in a.requests && a.owner != mid) {
            out.add(a)
            continue
        }
        val mem = a.members - mid
        if (mem.isEmpty()) continue
        var owner = a.owner
        if (owner == mid) owner = a.deputies.firstOrNull { it != mid && it in mem } ?: mem.first()
        out.add(
            a.copy(
                owner = owner, members = mem,
                deputies = a.deputies.filter { it != mid && it != owner && it in mem },
                requests = a.requests - mid,
            )
        )
    }
    return pl.copy(alliances = out)
}

fun addMember(pl: Player, aid: Int, mid: String): Player =
    removeMember(pl, mid).withAlly(aid) { it.copy(members = it.members + mid, requests = it.requests - mid) }

fun meetsReq(pl: Player, a: Alliance, mid: String): Boolean =
    pl.levelOf(mid) >= a.minLevel && pl.pointsOf(mid) >= a.minPoints

// ----------------------------------------------------------------- شبیه‌سازی Fake Play
private fun npcResult(arr: MutableList<Npc>, i: Int, won: Boolean, dp: Int, dc: Int, dx: Int) {
    val n = arr[i]
    arr[i] = n.copy(
        points = (n.points + dp).coerceIn(0, FP_NPC_POINTS_CAP),
        coins = max(0, n.coins + dc), xp = n.xp + dx,
        wins = n.wins + if (won) 1 else 0, losses = n.losses + if (won) 0 else 1,
        seasonWins = n.seasonWins + if (won) 1 else 0,
    )
}

/** «minutes» دقیقه از زندگی NPCها را شبیه‌سازی می‌کند: دوئل، لابی، عضویت/ساخت/دونیت اتحاد. */
fun simulate(pl0: Player, minutes: Double, now: Long): Player {
    var pl = pl0.copy(lastSimMs = now)
    if (!pl.fpEnabled || minutes <= 0 || pl.npcs.size < 2) return pl

    val arr = pl.npcs.toMutableList()
    val act = arr.indices.filter { !arr[it].banned && !arr[it].restricted }
    if (act.size >= 2) {
        repeat(min(400, stochRound(minutes / pl.duelEvery))) {
            val i = act.random()
            var j = act.random()
            var guard = 0
            while (j == i && guard++ < 6) j = act.random()
            if (i == j) return@repeat
            val a = Random.nextInt(1, 7)
            var b = Random.nextInt(1, 7)
            while (b == a) b = Random.nextInt(1, 7)
            val w = if (a > b) i else j
            val l = if (a > b) j else i
            npcResult(arr, w, true, Random.nextInt(8, 23), COIN_DUEL_WIN, XP_DUEL_WIN)
            npcResult(arr, l, false, -Random.nextInt(4, 15), COIN_DUEL_LOSS, XP_DUEL_LOSS)
        }
        repeat(min(100, stochRound(minutes / pl.lobbyEvery))) {
            val size = LOBBY_SIZES.random()
            if (act.size < size) return@repeat
            val pick = act.shuffled().take(size)
            val dice = pick.associateWith { Random.nextInt(1, 7) }
            val ta = pick.take(size / 2)
            val tb = pick.drop(size / 2)
            val sa = ta.sumOf { dice[it] ?: 0 }
            val sb = tb.sumOf { dice[it] ?: 0 }
            val mvpA = ta.maxByOrNull { dice[it] ?: 0 }!!
            val mvpB = tb.maxByOrNull { dice[it] ?: 0 }!!
            if (sa == sb) {
                npcResult(arr, mvpA, true, 10, 10, XP_TIE_MVP)
                npcResult(arr, mvpB, true, 10, 10, XP_TIE_MVP)
            } else {
                val win = if (sa > sb) ta else tb
                val lose = if (sa > sb) tb else ta
                val mw = if (sa > sb) mvpA else mvpB
                win.forEach {
                    val m = it == mw
                    npcResult(arr, it, true, 20 + if (m) 20 else 0, COIN_WIN + if (m) COIN_MVP else 0, XP_WIN + if (m) XP_MVP else 0)
                }
                lose.forEach { npcResult(arr, it, false, -15, COIN_LOSS, XP_LOSS) }
            }
        }
    }
    pl = pl.copy(npcs = arr)

    if (pl.allyAuto) {
        repeat(min(80, stochRound(minutes / 12.0))) { pl = allianceEvent(pl) }
        pl = autoUpgrade(pl)
    }
    return pl
}

private fun allianceEvent(pl: Player): Player {
    val act = pl.npcs.filter { pl.isActiveNpc(it) }
    if (act.isEmpty()) return pl
    val free = act.filter { pl.allyOf(npcMid(it.id)) == null }
    val r = Random.nextDouble()
    return when {
        r < 0.40 -> if (free.isEmpty()) pl else joinTry(pl, free.random())
        r < 0.50 -> createTry(pl, free)
        r < 0.88 -> donateTry(pl, act)
        r < 0.93 -> leaveTry(pl, act)
        else -> pl
    }
}

private fun joinTry(pl: Player, n: Npc): Player {
    val mid = npcMid(n.id)
    val cand = pl.alliances.filter {
        it.members.size < ALLY_MAX_MEMBERS && mid !in it.requests && meetsReq(pl, it, mid)
    }
    if (cand.isEmpty()) return pl
    val a = cand.random()
    return if (a.owner == ME && a.locked) {
        if (a.requests.size >= 30) pl else pl.withAlly(a.id) { it.copy(requests = it.requests + mid) }
    } else addMember(pl, a.id, mid)
}

private fun createTry(pl: Player, free: List<Npc>): Player {
    if (pl.alliances.size >= max(6, pl.npcs.size / 3)) return pl
    val c = free.filter { it.coins >= ALLY_CREATE_COST && levelFromXp(it.xp) >= 2 }
    if (c.isEmpty()) return pl
    val n = c.random()
    val name = genAllyName(pl.alliances.map { it.name }.toSet())
    return createAlliance(pl.withNpc(n.id) { it.copy(coins = it.coins - ALLY_CREATE_COST) }, npcMid(n.id), name)
}

private fun donateTry(pl: Player, act: List<Npc>): Player {
    val donors = act.filter { it.coins >= 100 && pl.allyOf(npcMid(it.id)) != null }
    if (donors.isEmpty()) return pl
    val n = donors.random()
    val a = pl.allyOf(npcMid(n.id)) ?: return pl
    val amt = min(n.coins, Random.nextInt(50, 501))
    return pl.withNpc(n.id) { it.copy(coins = it.coins - amt) }.withAlly(a.id) { it.copy(bank = it.bank + amt) }
}

private fun leaveTry(pl: Player, act: List<Npc>): Player {
    val c = act.filter {
        val a = pl.allyOf(npcMid(it.id))
        a != null && a.owner != ME && a.owner != npcMid(it.id)
    }
    if (c.isEmpty()) return pl
    return removeMember(pl, npcMid(c.random().id))
}

private fun autoUpgrade(pl: Player): Player = pl.copy(alliances = pl.alliances.map { a ->
    var x = a
    if (x.owner != ME) {
        while (x.level < ALLY_MAX_LEVEL) {
            val c = ALLY_UPGRADE_COST[x.level + 1] ?: break
            if (x.bank < c) break
            x = x.copy(level = x.level + 1, bank = x.bank - c)
        }
    }
    x
})
